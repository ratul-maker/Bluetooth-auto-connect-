import com.btearbuds.autoconnect.logic.BatteryAlertEngine;
import com.btearbuds.autoconnect.logic.DurationFormat;
import com.btearbuds.autoconnect.logic.ListenStats;
import com.btearbuds.autoconnect.logic.SessionTimeline;
import com.btearbuds.autoconnect.logic.WidgetModel;
import com.btearbuds.autoconnect.treble.TrebleMath;
import com.btearbuds.autoconnect.logic.InsightCalculator;
import com.btearbuds.autoconnect.logic.RetryPolicy;
import com.btearbuds.autoconnect.logic.VendorBatteryParser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Plain-Java checks of the pure logic (no Android needed).
 * Run with tools/run_logic_tests.sh
 */
public class LogicSelfTest {
    static int passed = 0;
    static int failed = 0;

    static void check(String name, boolean ok) {
        if (ok) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL: " + name);
        }
    }

    public static void main(String[] args) {
        // ---- RetryPolicy: bounded, growing, never infinite
        check("retry first delay 20s", RetryPolicy.delayAfterFailures(0) == 20000L);
        check("retry delays grow", RetryPolicy.delayAfterFailures(1) > RetryPolicy.delayAfterFailures(0)
                && RetryPolicy.delayAfterFailures(2) > RetryPolicy.delayAfterFailures(1)
                && RetryPolicy.delayAfterFailures(3) > RetryPolicy.delayAfterFailures(2));
        check("retry stops after max", RetryPolicy.delayAfterFailures(RetryPolicy.maxAttempts()) == -1L);
        check("retry stops far past max", RetryPolicy.delayAfterFailures(1000) == -1L);
        check("retry negative treated as 0", RetryPolicy.delayAfterFailures(-5) == 20000L);
        int n = 0;
        while (RetryPolicy.delayAfterFailures(n) >= 0) {
            n++;
            if (n > 100) break;
        }
        check("retry loop terminates", n == RetryPolicy.maxAttempts());

        // ---- BatteryAlertEngine
        BatteryAlertEngine e = new BatteryAlertEngine(null);
        check("no alert above threshold", !e.onReading("single", 50, 20, true, true));
        check("alert at threshold", e.onReading("single", 20, 20, true, true));
        check("no repeat alert", !e.onReading("single", 19, 20, true, true));
        check("no repeat alert 2", !e.onReading("single", 10, 20, true, true));
        check("no re-arm inside margin", !e.onReading("single", 22, 20, true, true));
        check("still no repeat after margin dip", !e.onReading("single", 18, 20, true, true));
        check("recover re-arms (no alert on recover)", !e.onReading("single", 40, 20, true, true));
        check("alert again after recover", e.onReading("single", 15, 20, true, true));

        BatteryAlertEngine e2 = new BatteryAlertEngine(null);
        check("invalid -1 ignored", !e2.onReading("single", -1, 20, true, true));
        check("invalid 101 ignored", !e2.onReading("single", 101, 20, true, true));
        check("invalid 255 ignored", !e2.onReading("single", 255, 20, true, true));
        check("disconnected ignored", !e2.onReading("single", 5, 20, true, false));
        check("alerts disabled -> no alert", !e2.onReading("single", 5, 20, false, true));
        check("alerts enabled later -> alert", e2.onReading("single", 5, 20, true, true));

        BatteryAlertEngine e3 = new BatteryAlertEngine(null);
        check("left alerts", e3.onReading("left", 10, 20, true, true));
        check("right alerts independently", e3.onReading("right", 12, 20, true, true));
        check("left does not repeat", !e3.onReading("left", 9, 20, true, true));
        check("snapshot has both", e3.snapshot().contains("left") && e3.snapshot().contains("right"));
        BatteryAlertEngine e4 = new BatteryAlertEngine(e3.snapshot());
        check("restored state suppresses repeat", !e4.onReading("left", 8, 20, true, true));
        e4.reset();
        check("reset clears", e4.snapshot().isEmpty());
        BatteryAlertEngine e5 = new BatteryAlertEngine(null);
        check("threshold 50 works", e5.onReading("single", 50, 50, true, true));
        check("high threshold re-arm capped at 100", !e5.onReading("single", 100, 99, true, true));

        // ---- VendorBatteryParser (+IPHONEACCEV)
        check("accev battery 9 -> 100", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{2, 1, 9, 2, 0}), 100));
        check("accev battery 4 -> 50", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{1, 1, 4}), 50));
        check("accev battery 0 -> 10", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{1, 1, 0}), 10));
        check("accev strings parse", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{"1", "1", "7"}), 80));
        check("accev dock only -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{1, 2, 1}) == null);
        check("accev out of range -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{1, 1, 12}) == null);
        check("accev negative -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{1, 1, -1}) == null);
        check("accev null -> null", VendorBatteryParser.parseIphoneAccev(null) == null);
        check("accev too short -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{1, 1}) == null);
        check("accev garbage -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{"x", "y", "z"}) == null);
        check("accev zero count -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{0, 1, 5}) == null);
        check("accev count larger than data ok", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{5, 1, 3}), 40)
                || VendorBatteryParser.parseIphoneAccev(new Object[]{5, 1, 3}) == null);
        check("accev second pair battery", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{2, 2, 0, 1, 5}), 60));

        // ---- InsightCalculator
        List<InsightCalculator.Point> none = new ArrayList<InsightCalculator.Point>();
        check("empty -> no sessions", InsightCalculator.split(none).isEmpty());

        long t0 = 1000000000000L;
        long min = 60000L;
        List<InsightCalculator.Point> one = Arrays.asList(new InsightCalculator.Point(t0, 80));
        List<InsightCalculator.Session> s1 = InsightCalculator.split(one);
        check("one point -> 1 session", s1.size() == 1);
        check("one point NOT sufficient", !s1.get(0).isSufficient());

        List<InsightCalculator.Point> two = Arrays.asList(
                new InsightCalculator.Point(t0, 80), new InsightCalculator.Point(t0 + 5 * min, 70));
        check("2 points 5 min NOT sufficient", !InsightCalculator.split(two).get(0).isSufficient());

        List<InsightCalculator.Point> good = Arrays.asList(
                new InsightCalculator.Point(t0, 90), new InsightCalculator.Point(t0 + 30 * min, 80),
                new InsightCalculator.Point(t0 + 110 * min, 60));
        List<InsightCalculator.Session> sg = InsightCalculator.split(good);
        check("good data 1 session", sg.size() == 1);
        check("good data sufficient", sg.get(0).isSufficient());
        check("good change -30", sg.get(0).change() == -30);
        check("good span 110 min", sg.get(0).spanMs() == 110 * min);
        List<InsightCalculator.Point> exactGap = Arrays.asList(
                new InsightCalculator.Point(t0, 90), new InsightCalculator.Point(t0 + 90 * min, 80));
        check("gap of exactly 90 min stays one session", InsightCalculator.split(exactGap).size() == 1);
        List<InsightCalculator.Point> overGap = Arrays.asList(
                new InsightCalculator.Point(t0, 90), new InsightCalculator.Point(t0 + 91 * min, 80));
        check("gap over 90 min splits", InsightCalculator.split(overGap).size() == 2);

        List<InsightCalculator.Point> gap = Arrays.asList(
                new InsightCalculator.Point(t0, 90), new InsightCalculator.Point(t0 + 20 * min, 80),
                new InsightCalculator.Point(t0 + 400 * min, 70), new InsightCalculator.Point(t0 + 430 * min, 60));
        check("gap splits sessions", InsightCalculator.split(gap).size() == 2);

        List<InsightCalculator.Point> charge = Arrays.asList(
                new InsightCalculator.Point(t0, 30), new InsightCalculator.Point(t0 + 20 * min, 20),
                new InsightCalculator.Point(t0 + 40 * min, 60), new InsightCalculator.Point(t0 + 70 * min, 55));
        check("charging jump splits sessions", InsightCalculator.split(charge).size() == 2);

        check("format <1 min", InsightCalculator.formatDuration(30000L).equals("under 1 min"));
        check("format 45 min", InsightCalculator.formatDuration(45 * min).equals("45 min"));
        check("format 2 h", InsightCalculator.formatDuration(120 * min).equals("2 h"));
        check("format 2 h 10 min", InsightCalculator.formatDuration(130 * min).equals("2 h 10 min"));


        // ---- DurationFormat
        check("clock 0", DurationFormat.clock(0L).equals("00:00:00"));
        check("clock negative is zero", DurationFormat.clock(-5000L).equals("00:00:00"));
        check("clock 59.9s floors", DurationFormat.clock(59999L).equals("00:00:59"));
        check("clock 1h02m03s", DurationFormat.clock(3723000L).equals("01:02:03"));
        check("clock 23:59:59", DurationFormat.clock(86399000L).equals("23:59:59"));
        check("clock 1 day", DurationFormat.clock(86400000L).equals("1d 00:00:00"));
        check("clock 2d 3h", DurationFormat.clock((2L * 86400L + 3L * 3600L + 5L) * 1000L).equals("2d 03:00:05"));

        // ---- SessionTimeline
        long h = 60L * min;
        long base = 1000000000000L;
        long now2 = base + 100 * h;
        SessionTimeline.Session sNew = new SessionTimeline.Session("Buds", base + 50 * h, base + 52 * h, true, true);
        SessionTimeline.Session sOld = new SessionTimeline.Session("Buds", base + 10 * h, base + 12 * h, true, false);
        check("session duration", sNew.durationMs(now2) == 2 * h);
        check("fully recorded", sNew.fullyRecorded());
        check("unobserved end not fully recorded", !sOld.fullyRecorded());
        SessionTimeline.Session openS = new SessionTimeline.Session("Buds", base + 90 * h, 0L, true, false);
        check("open session is open", openS.isOpen());
        check("open session duration uses now", openS.durationMs(now2) == 10 * h);
        check("open exact-start is fully recorded so far", openS.fullyRecorded());
        SessionTimeline.Session openFirstSeen = new SessionTimeline.Session("Buds", base + 90 * h, 0L, false, false);
        check("open first-seen is not fully recorded", !openFirstSeen.fullyRecorded());
        SessionTimeline.Session neg = new SessionTimeline.Session("Buds", base + 5 * h, base + 4 * h, true, true);
        check("negative duration clamps to 0", neg.durationMs(now2) == 0L);

        List<SessionTimeline.Window> wins = new ArrayList<SessionTimeline.Window>();
        wins.add(new SessionTimeline.Window(base + 12 * h, base + 20 * h));
        wins.add(new SessionTimeline.Window(base + 18 * h, base + 25 * h));
        wins.add(new SessionTimeline.Window(base + 40 * h, 0L));
        check("covered overlap not double counted",
                SessionTimeline.coveredMs(wins, base + 12 * h, base + 50 * h, now2) == (13L + 10L) * h);
        check("covered clipped to range",
                SessionTimeline.coveredMs(wins, base + 14 * h, base + 16 * h, now2) == 2 * h);
        check("covered nothing", SessionTimeline.coveredMs(wins, base + 30 * h, base + 35 * h, now2) == 0L);
        check("covered empty list", SessionTimeline.coveredMs(new ArrayList<SessionTimeline.Window>(),
                base, base + h, now2) == 0L);
        check("covered inverted range", SessionTimeline.coveredMs(wins, base + 20 * h, base + 12 * h, now2) == 0L);

        List<SessionTimeline.Session> news = new ArrayList<SessionTimeline.Session>();
        news.add(sNew);
        news.add(sOld);
        List<SessionTimeline.Item> items = SessionTimeline.build(news, wins, now2, 5 * min);
        check("timeline has 3 items (session, gap, session)", items.size() == 3);
        check("item0 is session", !items.get(0).isGap());
        check("item1 is gap", items.get(1).isGap());
        check("gap start is older end", items.get(1).gapStart == base + 12 * h);
        check("gap end is newer start", items.get(1).gapEnd == base + 50 * h);
        // gap 12h..50h = 38h; windows cover 12..25 (13h) + 40..50 (10h) = 23h -> 15h unobserved
        check("gap unobserved is 15h", items.get(1).unobservedMs == 15 * h);
        check("gap observed is 23h", items.get(1).observedMs() == 23 * h);
        List<SessionTimeline.Item> tiny = SessionTimeline.build(news, wins, now2, 100 * h);
        check("short gaps hidden", tiny.size() == 2);
        List<SessionTimeline.Item> noWin = SessionTimeline.build(news, new ArrayList<SessionTimeline.Window>(), now2, 5 * min);
        check("no windows means whole gap unobserved", noWin.get(1).unobservedMs == 38 * h);
        List<SessionTimeline.Session> oneS = new ArrayList<SessionTimeline.Session>();
        oneS.add(sNew);
        check("single session has no gap", SessionTimeline.build(oneS, wins, now2, 0L).size() == 1);
        check("empty list ok", SessionTimeline.build(new ArrayList<SessionTimeline.Session>(), wins, now2, 0L).isEmpty());
        // an open older session: gap measured from its start (it never ended)
        List<SessionTimeline.Session> mixed = new ArrayList<SessionTimeline.Session>();
        mixed.add(sNew);
        mixed.add(new SessionTimeline.Session("Buds", base + 10 * h, 0L, true, false));
        check("open older session gap from start", SessionTimeline.build(mixed, wins, now2, 0L).get(1).gapStart == base + 10 * h);

        // ---- WidgetModel
        WidgetModel noDev = WidgetModel.from(false, null, "x", 1, false, 0L, false, 80, null, true, 5L);
        check("no device mode", noDev.mode == WidgetModel.Mode.NO_DEVICE);
        check("no device shows nothing", !noDev.showElapsed() && !noDev.showBattery() && !noDev.showSince());
        check("no device battery text empty", noDev.batteryText().isEmpty());
        WidgetModel live = WidgetModel.from(true, "Buds", "Connected", WidgetModel.TONE_OK, true, base, true, 87, null, true, 5L);
        check("live shows elapsed", live.showElapsed());
        check("live shows battery", live.showBattery() && live.batteryText().equals("87%"));
        check("live shows since", live.showSince());
        WidgetModel liveNoBat = WidgetModel.from(true, "Buds", "Connected", WidgetModel.TONE_OK, true, base, true, -1, null, true, 5L);
        check("live without battery says so", !liveNoBat.showBattery() && liveNoBat.batteryText().equals("No battery data"));
        WidgetModel badBat = WidgetModel.from(true, "Buds", "Connected", WidgetModel.TONE_OK, true, base, true, 140, null, true, 5L);
        check("out-of-range battery rejected", !badBat.showBattery());
        WidgetModel stale = WidgetModel.from(true, "Buds", "Connected", WidgetModel.TONE_OK, true, base, true, 87, null, false, 5L);
        check("stale mode is last known", stale.mode == WidgetModel.Mode.LAST_KNOWN);
        check("stale never shows a running timer", !stale.showElapsed());
        check("stale never shows battery percent", !stale.showBattery() && stale.batteryText().equals("Battery --"));
        check("stale tone is idle", stale.tone == WidgetModel.TONE_IDLE);
        WidgetModel disc = WidgetModel.from(true, "Buds", "Not connected", WidgetModel.TONE_WARN, false, 0L, false, 50, null, true, 5L);
        check("disconnected shows no timer or battery", !disc.showElapsed() && !disc.showBattery() && disc.batteryText().isEmpty());
        WidgetModel lr = WidgetModel.from(true, "Buds", "Connected", WidgetModel.TONE_OK, true, base, true, -1, "L 80% \u00b7 R 75%", true, 5L);
        check("left/right text is shown", lr.showBattery() && lr.batteryText().equals("L 80% \u00b7 R 75%"));
        WidgetModel lrStale = WidgetModel.from(true, "Buds", "Connected", WidgetModel.TONE_OK, true, base, true, -1, "L 80% \u00b7 R 75%", false, 5L);
        check("stale hides left/right text", !lrStale.showBattery() && lrStale.batteryText().equals("Battery --"));
        WidgetModel lrDisc = WidgetModel.from(true, "Buds", "Not connected", WidgetModel.TONE_IDLE, false, 0L, false, -1, "L 80% \u00b7 R 75%", true, 5L);
        check("disconnected hides left/right text", !lrDisc.showBattery());
        WidgetModel noSince = WidgetModel.from(true, "Buds", "Connected", WidgetModel.TONE_OK, true, 0L, false, 60, null, true, 5L);
        check("unknown start shows no timer", !noSince.showElapsed() && !noSince.showSince());

        // ---- TrebleMath
        int[] range = TrebleMath.usableRangeDb(-1500, 1500);
        check("range full -12..12", range != null && range[0] == -12 && range[1] == 12);
        int[] narrow = TrebleMath.usableRangeDb(-1000, 1000);
        check("range limited by device -10..10", narrow != null && narrow[0] == -10 && narrow[1] == 10);
        int[] asym = TrebleMath.usableRangeDb(-1500, 300);
        check("range asymmetric -12..3", asym != null && asym[0] == -12 && asym[1] == 3);
        check("range too small is null", TrebleMath.usableRangeDb(-50, 50) == null);
        check("range cut-only is null", TrebleMath.usableRangeDb(-1500, 0) == null);
        check("snap to half dB", TrebleMath.snap(2.26) == 2.5 && TrebleMath.snap(2.2) == 2.0);
        check("clamp high", TrebleMath.clamp(20.0, range) == 12.0);
        check("clamp low narrow", TrebleMath.clamp(-12.0, narrow) == -10.0);
        check("clamp inside", TrebleMath.clamp(3.5, range) == 3.5);
        int[] centers5 = {60000, 230000, 910000, 3600000, 14000000}; // milliHertz as Android reports
        int[] hz5 = {60, 230, 910, 3600, 14000};
        check("has treble band", TrebleMath.hasTrebleBand(hz5));
        check("no treble band on low-only EQ", !TrebleMath.hasTrebleBand(new int[]{60, 230, 910}));
        check("null centers no treble", !TrebleMath.hasTrebleBand(null));
        double[] w = TrebleMath.shelfWeights(hz5);
        check("low bands untouched", w[0] == 0.0 && w[1] == 0.0 && w[2] == 0.0);
        check("top band full weight", Math.abs(w[4] - 1.0) < 1e-9);
        check("3.6k between 0 and 1", w[3] > 0.0 && w[3] < 1.0);
        int[] lv = TrebleMath.bandLevelsMb(hz5, 6.0, -1500, 1500);
        check("+6 dB top band 600 mB", lv[4] == 600);
        check("+6 dB low bands 0", lv[0] == 0 && lv[1] == 0 && lv[2] == 0);
        int[] lvNeg = TrebleMath.bandLevelsMb(hz5, -12.0, -1500, 1500);
        check("-12 dB top band -1200 mB", lvNeg[4] == -1200);
        int[] lvClamp = TrebleMath.bandLevelsMb(hz5, 12.0, -1000, 500);
        check("device max clamps band level", lvClamp[4] == 500);
        int[] lvFlat = TrebleMath.bandLevelsMb(hz5, 0.0, -1500, 1500);
        check("0 dB is flat", lvFlat[3] == 0 && lvFlat[4] == 0 && lvFlat[0] == 0);
        int[] lvLowOnly = TrebleMath.bandLevelsMb(new int[]{60, 230, 910}, 6.0, -1500, 1500);
        check("low-only EQ gets no gain", lvLowOnly[0] == 0 && lvLowOnly[1] == 0 && lvLowOnly[2] == 0);
        check("preset neutral", TrebleMath.presetFor(0.0) == TrebleMath.Preset.NEUTRAL);
        check("preset warm", TrebleMath.presetFor(-4.0) == TrebleMath.Preset.WARM);
        check("preset balanced", TrebleMath.presetFor(2.0) == TrebleMath.Preset.BALANCED);
        check("preset bright", TrebleMath.presetFor(6.0) == TrebleMath.Preset.BRIGHT);
        check("preset custom for other", TrebleMath.presetFor(3.5) == TrebleMath.Preset.CUSTOM);
        check("preset db values inside range", TrebleMath.Preset.WARM.db >= -12 && TrebleMath.Preset.BRIGHT.db <= 12);
        check("format +6", TrebleMath.formatDb(6.0).equals("+6.0 dB"));
        check("format -4.5", TrebleMath.formatDb(-4.5).equals("-4.5 dB"));
        check("format zero", TrebleMath.formatDb(0.0).equals("0.0 dB"));
        check("format tiny negative is zero", TrebleMath.formatDb(-0.01).equals("0.0 dB"));


        // ---- ListenStats: listening time = audio streaming to the earbuds, observed only
        final long M = 60000L;
        final long T0 = 1000L * M;                       // an arbitrary "day start"
        final long T1 = T0 + 24L * 60L * M;              // next day start
        List<ListenStats.Span> lsNone = new ArrayList<ListenStats.Span>();
        check("listen empty list is zero", ListenStats.total(lsNone, T0, T1, T1).ms == 0L);
        check("listen null list is zero", ListenStats.total(null, T0, T1, T1).ms == 0L);
        check("listen empty not partial", !ListenStats.total(lsNone, T0, T1, T1).partial);
        List<ListenStats.Span> lsOne = new ArrayList<ListenStats.Span>();
        lsOne.add(new ListenStats.Span(T0 + 10 * M, T0 + 40 * M, true, true));
        ListenStats.Total t1 = ListenStats.total(lsOne, T0, T1, T1);
        check("listen lsOne exact span 30 min", t1.ms == 30 * M);
        check("listen lsOne exact span not partial", !t1.partial);
        check("listen lsOne span counted once", t1.spans == 1);

        List<ListenStats.Span> lsTwo = new ArrayList<ListenStats.Span>(lsOne);
        lsTwo.add(new ListenStats.Span(T0 + 100 * M, T0 + 110 * M, true, true));
        check("listen lsTwo spans add up", ListenStats.total(lsTwo, T0, T1, T1).ms == 40 * M);

        List<ListenStats.Span> ovl = new ArrayList<ListenStats.Span>();
        ovl.add(new ListenStats.Span(T0 + 10 * M, T0 + 30 * M, true, true));
        ovl.add(new ListenStats.Span(T0 + 20 * M, T0 + 50 * M, true, true));
        check("listen overlap not double counted", ListenStats.total(ovl, T0, T1, T1).ms == 40 * M);
        List<ListenStats.Span> unsorted = new ArrayList<ListenStats.Span>();
        unsorted.add(new ListenStats.Span(T0 + 100 * M, T0 + 110 * M, true, true));
        unsorted.add(new ListenStats.Span(T0 + 10 * M, T0 + 20 * M, true, true));
        check("listen unsorted input fine", ListenStats.total(unsorted, T0, T1, T1).ms == 20 * M);

        // open span runs up to "now"
        List<ListenStats.Span> open = new ArrayList<ListenStats.Span>();
        open.add(new ListenStats.Span(T0 + 60 * M, 0L, true, false));
        check("listen open span grows with now", ListenStats.total(open, T0, T1, T0 + 90 * M).ms == 30 * M);
        check("listen open span later now", ListenStats.total(open, T0, T1, T0 + 120 * M).ms == 60 * M);
        check("listen open exact start is complete", !ListenStats.total(open, T0, T1, T0 + 90 * M).partial);
        check("listen streaming-now true", ListenStats.streamingNow(open));
        check("listen streaming-now false", !ListenStats.streamingNow(lsOne));
        check("listen streaming-now null", !ListenStats.streamingNow(null));

        // the range never reaches into the future
        check("listen range clipped to now", ListenStats.total(lsOne, T0, T1, T0 + 25 * M).ms == 15 * M);
        check("listen before now only", ListenStats.total(lsOne, T0, T1, T0 + 5 * M).ms == 0L);

        // partial flags: a start or end the app did not see makes the total "at least"
        List<ListenStats.Span> firstSeen = new ArrayList<ListenStats.Span>();
        firstSeen.add(new ListenStats.Span(T0 + 10 * M, T0 + 40 * M, false, true));
        check("listen first-seen start is partial", ListenStats.total(firstSeen, T0, T1, T1).partial);
        List<ListenStats.Span> lostEnd = new ArrayList<ListenStats.Span>();
        lostEnd.add(new ListenStats.Span(T0 + 10 * M, T0 + 40 * M, true, false));
        check("listen unobserved end is partial", ListenStats.total(lostEnd, T0, T1, T1).partial);
        check("listen value of partial span still counted", ListenStats.total(lostEnd, T0, T1, T1).ms == 30 * M);
        List<ListenStats.Span> lsOpenFirst = new ArrayList<ListenStats.Span>();
        lsOpenFirst.add(new ListenStats.Span(T0 + 60 * M, 0L, false, false));
        check("listen open first-seen is partial", ListenStats.total(lsOpenFirst, T0, T1, T0 + 90 * M).partial);

        // a span cut by the edge of the range is not "partial" because of that edge
        List<ListenStats.Span> cross = new ArrayList<ListenStats.Span>();
        cross.add(new ListenStats.Span(T0 - 30 * M, T0 + 30 * M, false, true)); // started before today
        ListenStats.Total tc = ListenStats.total(cross, T0, T1, T1);
        check("listen crossing midnight counts only today's part", tc.ms == 30 * M);
        check("listen crossing midnight: unseen start is outside the range", !tc.partial);
        List<ListenStats.Span> crossEnd = new ArrayList<ListenStats.Span>();
        crossEnd.add(new ListenStats.Span(T1 - 20 * M, T1 + 40 * M, true, false)); // ends after today
        ListenStats.Total te = ListenStats.total(crossEnd, T0, T1, T1 + 100 * M);
        check("listen crossing the end counts only inside part", te.ms == 20 * M);
        check("listen crossing the end: unseen end is outside the range", !te.partial);

        // per-session figure
        List<ListenStats.Span> sess = new ArrayList<ListenStats.Span>();
        sess.add(new ListenStats.Span(T0 + 5 * M, T0 + 15 * M, true, true));
        sess.add(new ListenStats.Span(T0 + 200 * M, T0 + 220 * M, true, true));
        check("listen during session only counts inside", ListenStats.duringSession(sess, T0, T0 + 100 * M, T1).ms == 10 * M);
        check("listen during open session uses now", ListenStats.duringSession(sess, T0, 0L, T0 + 210 * M).ms == 20 * M);
        check("listen during session with none", ListenStats.duringSession(sess, T0 + 20 * M, T0 + 100 * M, T1).ms == 0L);

        // zero-length and reversed spans never add time
        List<ListenStats.Span> odd = new ArrayList<ListenStats.Span>();
        odd.add(new ListenStats.Span(T0 + 10 * M, T0 + 10 * M + 0L, true, true));
        odd.add(new ListenStats.Span(T0 + 50 * M, T0 + 40 * M, true, true));
        check("listen zero or reversed spans add nothing", ListenStats.total(odd, T0, T1, T1).ms == 0L);
        // range edge cases
        check("listen empty range", ListenStats.total(lsOne, T0 + 10 * M, T0 + 10 * M, T1).ms == 0L);
        check("listen reversed range", ListenStats.total(lsOne, T1, T0, T1).ms == 0L);
        check("listen clock text for an hour twelve", DurationFormat.clock(72 * M + 5000L).equals("01:12:05"));

        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    static boolean eq(Integer a, int b) {
        return a != null && a.intValue() == b;
    }
}
