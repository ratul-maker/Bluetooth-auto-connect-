package com.btearbuds.autoconnect.logic;

/**
 * Bounded retry schedule for automatic connection attempts.
 *
 * After a disconnect the app makes at most {@link #maxAttempts()} automatic attempts,
 * with growing delays, and then stops. Attempts resume only when something relevant
 * happens (Bluetooth toggled, earbuds link up, user taps Connect Now).
 */
public final class RetryPolicy {

    private static final long[] DELAYS_MS = {20000L, 60000L, 180000L, 600000L};

    private RetryPolicy() {
    }

    public static int maxAttempts() {
        return DELAYS_MS.length;
    }

    /**
     * @param failedAttempts number of automatic attempts that have already failed in this episode
     * @return delay in ms before the next automatic attempt, or -1 when the app should stop retrying
     */
    public static long delayAfterFailures(int failedAttempts) {
        if (failedAttempts < 0) {
            failedAttempts = 0;
        }
        if (failedAttempts >= DELAYS_MS.length) {
            return -1L;
        }
        return DELAYS_MS[failedAttempts];
    }
}
