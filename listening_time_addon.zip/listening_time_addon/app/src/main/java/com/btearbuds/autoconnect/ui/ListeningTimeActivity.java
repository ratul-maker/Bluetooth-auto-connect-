package com.btearbuds.autoconnect.ui;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.provider.Settings.Secure;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;
import android.os.Looper;

import com.btearbuds.autoconnect.data.ListeningTimeStore;
import com.btearbuds.autoconnect.data.ListeningTimeStore.DayTotal;
import com.btearbuds.autoconnect.service.MediaSessionTrackerService;

import java.util.List;

/** Simple no-library screen for viewing recent estimated Bluetooth listening time. */
public final class ListeningTimeActivity extends Activity {
    private LinearLayout content;
    private TextView statusText;
    private TextView totalsText;
    private final Handler refreshHandler = new Handler(Looper.getMainLooper());
    private boolean screenVisible;

    private final Runnable refreshRunnable = new Runnable() {
        @Override public void run() {
            if (!screenVisible) return;
            refreshTotals();
            refreshHandler.postDelayed(this, 10000L);
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("Music listening time");

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        content.setPadding(pad, pad, pad, pad);
        scroll.addView(content);
        setContentView(scroll);

        TextView heading = new TextView(this);
        heading.setText("Bluetooth listening time");
        heading.setTextSize(23);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        content.addView(heading);

        statusText = new TextView(this);
        statusText.setTextSize(15);
        statusText.setPadding(0, pad / 2, 0, pad / 2);
        content.addView(statusText);

        Button accessButton = new Button(this);
        accessButton.setText("Enable / manage Notification Access");
        accessButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                } catch (RuntimeException ignored) {
                    Toast.makeText(ListeningTimeActivity.this,
                            "Could not open Notification Access settings. Open it manually in Android Settings.",
                            Toast.LENGTH_LONG).show();
                }
            }
        });
        content.addView(accessButton);

        Button refreshButton = new Button(this);
        refreshButton.setText("Refresh totals");
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { refreshTotals(); }
        });
        content.addView(refreshButton);

        totalsText = new TextView(this);
        totalsText.setTextSize(16);
        totalsText.setPadding(0, pad, 0, pad);
        content.addView(totalsText);

        TextView caveat = new TextView(this);
        caveat.setTextSize(13);
        caveat.setText("Estimate only: time is counted when Android reports an active media session " +
                "as playing and a Bluetooth media output is present. Android does not reliably " +
                "tell this app whether sound was audible or whether that output was the selected " +
                "earbuds. Notification Access is optional and can expose notification contents " +
                "to an app in general; this tracker does not save notification text or music metadata.");
        content.addView(caveat);
    }

    @Override
    protected void onResume() {
        super.onResume();
        screenVisible = true;
        refreshHandler.removeCallbacks(refreshRunnable);
        refreshHandler.post(refreshRunnable);
    }

    @Override
    protected void onPause() {
        screenVisible = false;
        refreshHandler.removeCallbacks(refreshRunnable);
        super.onPause();
    }

    private void refreshTotals() {
        boolean enabled = hasNotificationListenerAccess();
        statusText.setText(enabled
                ? "Tracking is enabled. Play music normally; totals update about every 10 seconds."
                : "Tracking is off. Tap the access button and enable Earbuds Auto-Connect in Android settings.");

        StringBuilder text = new StringBuilder();
        text.append("Today: ").append(formatDuration(ListeningTimeStore.getTodayMillis(this))).append("\n\n");
        text.append("Last 14 days\n");
        List<DayTotal> days = ListeningTimeStore.getLastDays(this, 14);
        for (DayTotal day : days) {
            text.append(day.date).append("   ")
                    .append(formatDuration(day.millis)).append('\n');
        }
        totalsText.setText(text.toString());
    }

    private boolean hasNotificationListenerAccess() {
        String enabled = Secure.getString(getContentResolver(), "enabled_notification_listeners");
        if (enabled == null) return false;
        ComponentName ourComponent = new ComponentName(this, MediaSessionTrackerService.class);
        for (String entry : enabled.split(":")) {
            ComponentName parsed = ComponentName.unflattenFromString(entry);
            if (ourComponent.equals(parsed)) return true;
        }
        return false;
    }

    private String formatDuration(long millis) {
        long totalMinutes = millis / 60000L;
        long hours = totalMinutes / 60L;
        long minutes = totalMinutes % 60L;
        if (hours > 0L) return hours + " h " + minutes + " min";
        if (totalMinutes > 0L) return totalMinutes + " min";
        return "Less than 1 min";
    }
}
