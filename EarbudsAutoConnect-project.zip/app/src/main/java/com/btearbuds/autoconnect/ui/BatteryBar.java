package com.btearbuds.autoconnect.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import com.btearbuds.autoconnect.R;

/** A rounded horizontal battery bar. Level -1 draws only the empty track. */
public final class BatteryBar extends View {

    private int level = -1;
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    public BatteryBar(Context c) {
        super(c);
        track.setColor(c.getColor(R.color.surface_variant));
        setLevel(-1);
    }

    public void setLevel(int l) {
        level = l;
        Context c = getContext();
        int colorRes = l <= 20 ? R.color.error : (l <= 40 ? R.color.warn : R.color.ok);
        fill.setColor(c.getColor(colorRes));
        setContentDescription(l < 0 ? "Battery unavailable" : "Battery " + l + " percent");
        invalidate();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int desiredH = Ui.dp(getContext(), 14);
        setMeasuredDimension(resolveSize(Ui.dp(getContext(), 100), widthSpec),
                resolveSize(desiredH, heightSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float h = getHeight();
        float w = getWidth();
        float r = h / 2f;
        rect.set(0, 0, w, h);
        canvas.drawRoundRect(rect, r, r, track);
        if (level >= 0) {
            float fw = Math.max(h, w * Math.min(level, 100) / 100f);
            rect.set(0, 0, fw, h);
            canvas.drawRoundRect(rect, r, r, fill);
        }
    }
}
