package com.btearbuds.autoconnect.ui;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.bt.StatusText;

/** Tiny helpers for building the screens in code (keeps the app small and dependency-free). */
public final class Ui {

    public static final int BTN_PRIMARY = 0;
    public static final int BTN_TONAL = 1;
    public static final int BTN_TEXT = 2;

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private Ui() {
    }

    public static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics()));
    }

    public static int col(Context c, int colorRes) {
        return c.getColor(colorRes);
    }

    public static GradientDrawable rect(Context c, int fill, int stroke, int strokeDp, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0) {
            g.setStroke(dp(c, strokeDp), stroke);
        }
        return g;
    }

    /**
     * A card background: dark fill, thin outline and a faint outer glow in the given colour. Built
     * from plain translucent strokes so it draws the same on every phone (no blur filters).
     */
    public static LayerDrawable glowRect(Context c, int fill, int outline, int glow, int radiusDp) {
        GradientDrawable halo = new GradientDrawable();
        halo.setColor(0x00000000);
        halo.setCornerRadius(dp(c, radiusDp));
        halo.setStroke(dp(c, 3), glow);
        GradientDrawable body = new GradientDrawable();
        body.setColor(fill);
        body.setCornerRadius(dp(c, radiusDp - 2));
        body.setStroke(dp(c, 1), outline);
        LayerDrawable ld = new LayerDrawable(new android.graphics.drawable.Drawable[]{halo, body});
        ld.setLayerInset(1, dp(c, 2), dp(c, 2), dp(c, 2), dp(c, 2));
        return ld;
    }

    public static Typeface medium() {
        return Typeface.create("sans-serif-medium", Typeface.NORMAL);
    }

    public static Typeface light() {
        return Typeface.create("sans-serif-light", Typeface.NORMAL);
    }

    public static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    /** A scrolling page: returns the content column to add cards to. */
    public static LinearLayout page(Activity a, String title) {
        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.setBackgroundColor(col(a, R.color.bg));
        LinearLayout content = column(a);
        content.setPadding(dp(a, 16), dp(a, 20), dp(a, 16), dp(a, 28));
        sv.addView(content, new ViewGroup.LayoutParams(MATCH, WRAP));
        a.setContentView(sv);
        a.setTitle(title);
        return content;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = column(c);
        l.setBackground(glowRect(c, col(c, R.color.surface), col(c, R.color.outline),
                0x0D00E5FF, 22));
        l.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 18));
        return l;
    }

    public static void addCard(LinearLayout parent, LinearLayout card) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(0, 0, 0, dp(parent.getContext(), 12));
        parent.addView(card, lp);
    }

    public static TextView text(Context c, CharSequence t, float sp, int colorRes, boolean bold) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(col(c, colorRes));
        if (bold) {
            v.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return v;
    }

    public static TextView title(Context c, String t) {
        TextView v = text(c, t, 28, R.color.text_primary, false);
        v.setTypeface(light());
        v.setLetterSpacing(0.04f);
        return v;
    }

    public static TextView heading(Context c, String t) {
        TextView v = text(c, t, 12, R.color.text_secondary, true);
        v.setTypeface(medium());
        v.setLetterSpacing(0.14f);
        return v;
    }

    public static TextView body(Context c, CharSequence t) {
        TextView v = text(c, t, 15, R.color.text_primary, false);
        v.setLineSpacing(0f, 1.15f);
        return v;
    }

    public static TextView small(Context c, CharSequence t) {
        TextView v = text(c, t, 13, R.color.text_secondary, false);
        v.setLineSpacing(0f, 1.1f);
        return v;
    }

    /** Add a child with a top margin (dp). */
    public static void add(LinearLayout parent, View child, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(0, dp(parent.getContext(), topDp), 0, 0);
        parent.addView(child, lp);
    }

    public static Button button(Context c, String label, int style, View.OnClickListener l) {
        Button b = new Button(c);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTypeface(medium());
        b.setMinHeight(dp(c, 48));
        b.setMinimumHeight(dp(c, 48));
        b.setStateListAnimator(null);
        int textColor;
        android.graphics.drawable.Drawable shape;
        if (style == BTN_PRIMARY) {
            textColor = col(c, R.color.on_primary);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{col(c, R.color.primary), col(c, R.color.accent)});
            g.setCornerRadius(dp(c, 26));
            shape = g;
        } else if (style == BTN_TONAL) {
            textColor = col(c, R.color.on_primary_container);
            shape = rect(c, col(c, R.color.primary_container), 0x6600E5FF, 1, 26);
        } else {
            textColor = col(c, R.color.primary);
            shape = rect(c, 0x00000000, 0, 0, 26);
        }
        b.setTextColor(textColor);
        int ripple = (col(c, R.color.primary) & 0x00FFFFFF) | 0x33000000;
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(ripple), shape, null));
        b.setOnClickListener(l);
        return b;
    }

    /** A small pill button for navigation rows and presets. */
    public static Button chip(Context c, String label, boolean selected, View.OnClickListener l) {
        Button b = new Button(c);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        b.setTypeface(medium());
        b.setMinHeight(dp(c, 40));
        b.setMinimumHeight(dp(c, 40));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(c, 6), 0, dp(c, 6), 0);
        b.setStateListAnimator(null);
        setChipSelected(c, b, selected);
        b.setOnClickListener(l);
        return b;
    }

    public static void setChipSelected(Context c, Button b, boolean selected) {
        android.graphics.drawable.Drawable shape;
        if (selected) {
            shape = rect(c, col(c, R.color.accent_container), col(c, R.color.accent), 1, 20);
            b.setTextColor(col(c, R.color.on_accent_container));
        } else {
            shape = rect(c, col(c, R.color.surface_variant), col(c, R.color.outline), 1, 20);
            b.setTextColor(col(c, R.color.text_secondary));
        }
        int ripple = (col(c, R.color.primary) & 0x00FFFFFF) | 0x33000000;
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(ripple), shape, null));
        b.setSelected(selected);
    }

    /** Cyan/violet look for a SeekBar. */
    public static void styleSeekBar(Context c, SeekBar bar) {
        bar.setProgressTintList(ColorStateList.valueOf(col(c, R.color.primary)));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(col(c, R.color.surface_high)));
        bar.setThumbTintList(ColorStateList.valueOf(col(c, R.color.accent)));
    }

    public static void setEnabledLook(Button b, boolean enabled) {
        b.setEnabled(enabled);
        b.setAlpha(enabled ? 1f : 0.5f);
    }

    public static View dot(Context c, int color) {
        View v = new View(c);
        setDotColor(v, color);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(c, 14), dp(c, 14));
        lp.setMargins(0, 0, dp(c, 8), 0);
        v.setLayoutParams(lp);
        return v;
    }

    /** A solid dot with a soft halo ring in the same colour. */
    public static void setDotColor(View dot, int color) {
        Context c = dot.getContext();
        GradientDrawable halo = new GradientDrawable();
        halo.setShape(GradientDrawable.OVAL);
        halo.setColor((color & 0x00FFFFFF) | 0x40000000);
        GradientDrawable core = new GradientDrawable();
        core.setShape(GradientDrawable.OVAL);
        core.setColor(color);
        LayerDrawable ld = new LayerDrawable(new android.graphics.drawable.Drawable[]{halo, core});
        ld.setLayerInset(1, dp(c, 3), dp(c, 3), dp(c, 3), dp(c, 3));
        dot.setBackground(ld);
    }

    public static void toast(Context c, String msg) {
        Toast.makeText(c, msg, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------ switch row

    public interface OnToggle {
        void onToggle(boolean checked);
    }

    public static final class SwitchRow {
        public final LinearLayout view;
        public final Switch toggle;
        public final TextView sub;
        private boolean quiet;

        SwitchRow(Context c, String title, String subtitle, final OnToggle cb) {
            view = row(c);
            view.setPadding(0, dp(c, 8), 0, dp(c, 8));
            LinearLayout left = column(c);
            TextView t = text(c, title, 16, R.color.text_primary, false);
            t.setTypeface(medium());
            left.addView(t);
            sub = small(c, subtitle);
            left.addView(sub);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
            lp.setMargins(0, 0, dp(c, 12), 0);
            view.addView(left, lp);
            toggle = new Switch(c);
            toggle.setContentDescription(title);
            int[][] states = new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}};
            toggle.setThumbTintList(new ColorStateList(states, new int[]{
                    col(c, R.color.primary), col(c, R.color.text_secondary)}));
            toggle.setTrackTintList(new ColorStateList(states, new int[]{
                    (col(c, R.color.primary) & 0x00FFFFFF) | 0x66000000, col(c, R.color.surface_high)}));
            view.addView(toggle, new LinearLayout.LayoutParams(WRAP, WRAP));
            toggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (!quiet) {
                    cb.onToggle(isChecked);
                }
            });
            view.setOnClickListener(v -> toggle.toggle());
        }

        /** Sets the switch without calling the listener. */
        public void set(boolean checked) {
            quiet = true;
            toggle.setChecked(checked);
            quiet = false;
        }
    }

    public static SwitchRow switchRow(Context c, String title, String subtitle, OnToggle cb) {
        return new SwitchRow(c, title, subtitle, cb);
    }

    // ------------------------------------------------------------------ navigation helpers

    public static void openBluetoothSettings(Context c) {
        try {
            c.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        } catch (ActivityNotFoundException e) {
            toast(c, "Open Settings > Connected devices > Bluetooth.");
        }
    }

    public static void openAppInfo(Context c) {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.fromParts("package", c.getPackageName(), null));
            c.startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast(c, "Open Settings > Apps > Earbuds Auto-Connect.");
        }
    }

    public static void openBatteryOptimization(Context c) {
        try {
            c.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        } catch (ActivityNotFoundException e) {
            openAppInfo(c);
        }
    }

    public static void requestEnableBluetooth(Context c) {
        try {
            c.startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
        } catch (ActivityNotFoundException e) {
            openBluetoothSettings(c);
        } catch (SecurityException e) {
            openBluetoothSettings(c);
        }
    }

    public static void perform(Context c, StatusText.Action a) {
        switch (a) {
            case PICK_DEVICE:
                c.startActivity(new Intent(c, PickDeviceActivity.class));
                break;
            case OPEN_BT_SETTINGS:
                openBluetoothSettings(c);
                break;
            case ENABLE_BT:
                requestEnableBluetooth(c);
                break;
            case APP_INFO:
                openAppInfo(c);
                break;
            default:
                break;
        }
    }
}
