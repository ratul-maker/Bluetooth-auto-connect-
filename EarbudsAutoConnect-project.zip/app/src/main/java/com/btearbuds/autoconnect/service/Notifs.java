package com.btearbuds.autoconnect.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.bt.Snapshot;
import com.btearbuds.autoconnect.bt.StatusText;
import com.btearbuds.autoconnect.treble.TrebleEngine;
import com.btearbuds.autoconnect.treble.TrebleMath;
import com.btearbuds.autoconnect.treble.TrebleService;
import com.btearbuds.autoconnect.ui.MainActivity;
import com.btearbuds.autoconnect.ui.TrebleLabActivity;

/**
 * All notifications. Only four kinds exist: the ongoing monitoring notification (updated in
 * place), an occasional low-battery alert, an optional connection event, and the ongoing Treble Lab
 * notification (only while Treble Lab is on). Android 11 needs no notification permission, so none
 * is requested.
 */
public final class Notifs {

    public static final String CH_MONITOR = "monitor";
    public static final String CH_ALERT = "alerts";
    public static final String CH_EVENTS = "events";
    public static final String CH_TREBLE = "treble";

    public static final int ID_MONITOR = 1001;
    public static final int ID_EVENT = 3001;
    public static final int ID_TREBLE = 4001;
    private static final int ID_ALERT_BASE = 2000;

    private Notifs() {
    }

    public static void ensureChannels(Context ctx) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) {
            return;
        }
        NotificationChannel monitor = new NotificationChannel(CH_MONITOR, "Monitoring",
                NotificationManager.IMPORTANCE_LOW);
        monitor.setDescription("Shows that the app is watching your earbuds, with their status.");
        monitor.setShowBadge(false);
        nm.createNotificationChannel(monitor);

        NotificationChannel alert = new NotificationChannel(CH_ALERT, "Low battery alerts",
                NotificationManager.IMPORTANCE_DEFAULT);
        alert.setDescription("A single alert when an earbud battery falls below your limit.");
        nm.createNotificationChannel(alert);

        NotificationChannel events = new NotificationChannel(CH_EVENTS, "Connection events",
                NotificationManager.IMPORTANCE_LOW);
        events.setDescription("Optional: tells you when your earbuds connect or disconnect.");
        events.setShowBadge(false);
        nm.createNotificationChannel(events);

        NotificationChannel treble = new NotificationChannel(CH_TREBLE, "Treble Lab",
                NotificationManager.IMPORTANCE_LOW);
        treble.setDescription("Shown only while Treble Lab is on. It keeps the equalizer effect alive.");
        treble.setShowBadge(false);
        nm.createNotificationChannel(treble);
    }

    private static PendingIntent openApp(Context ctx) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(ctx, 10, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent serviceAction(Context ctx, String action, int requestCode) {
        Intent i = new Intent(ctx, MonitorService.class);
        i.setAction(action);
        return PendingIntent.getService(ctx, requestCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static Icon icon(Context ctx) {
        return Icon.createWithResource(ctx, R.drawable.ic_stat_bluetooth);
    }

    public static Notification placeholder(Context ctx) {
        return new Notification.Builder(ctx, CH_MONITOR)
                .setSmallIcon(R.drawable.ic_stat_bluetooth)
                .setContentTitle("Earbuds Auto-Connect")
                .setContentText("Starting...")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openApp(ctx))
                .build();
    }

    public static String monitorTitle(Snapshot s) {
        return s.deviceName != null ? s.deviceName : "Earbuds Auto-Connect";
    }

    public static String monitorText(Snapshot s) {
        StringBuilder b = new StringBuilder(StatusText.label(s));
        String bat = StatusText.batteryLine(s);
        if (bat != null) {
            b.append(" · ").append(bat);
        }
        return b.toString();
    }

    public static Notification monitorNotification(Context ctx, Snapshot s, boolean oneShot) {
        String title = monitorTitle(s);
        String text = monitorText(s);
        String sub = oneShot ? "Trying to connect" : "Monitoring is on";
        Notification.Builder b = new Notification.Builder(ctx, CH_MONITOR)
                .setSmallIcon(R.drawable.ic_stat_bluetooth)
                .setContentTitle(title)
                .setContentText(text)
                .setSubText(sub)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(openApp(ctx));
        if (s.deviceAddress != null && s.adapterOn && !s.isConnected()) {
            b.addAction(new Notification.Action.Builder(icon(ctx), "Connect now",
                    serviceAction(ctx, MonitorService.ACTION_CONNECT, 11)).build());
        }
        b.addAction(new Notification.Action.Builder(icon(ctx), "Open app", openApp(ctx)).build());
        if (!oneShot) {
            b.addAction(new Notification.Action.Builder(icon(ctx), "Stop monitoring",
                    serviceAction(ctx, MonitorService.ACTION_STOP, 12)).build());
        }
        return b.build();
    }

    // ------------------------------------------------------------------ Treble Lab

    private static PendingIntent openTreble(Context ctx) {
        Intent i = new Intent(ctx, TrebleLabActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(ctx, 30, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent trebleStop(Context ctx) {
        Intent i = new Intent(ctx, TrebleService.class);
        i.setAction(TrebleService.ACTION_STOP);
        return PendingIntent.getService(ctx, 31, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static Notification treblePlaceholder(Context ctx) {
        return new Notification.Builder(ctx, CH_TREBLE)
                .setSmallIcon(R.drawable.ic_stat_bluetooth)
                .setContentTitle("Treble Lab")
                .setContentText("Starting...")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openTreble(ctx))
                .build();
    }

    /** Never says "on" unless Android accepted the settings; never claims what the user hears. */
    public static Notification trebleNotification(Context ctx, TrebleEngine.Status s) {
        String title = "Treble Lab \u00b7 " + TrebleMath.formatDb(s.db);
        String text;
        if (s.applied()) {
            text = "Accepted by Android. What you hear depends on your phone and app.";
        } else if (s.running) {
            text = "Not applied yet. Open Treble Lab for details.";
        } else {
            text = "Off";
        }
        return new Notification.Builder(ctx, CH_TREBLE)
                .setSmallIcon(R.drawable.ic_stat_bluetooth)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(openTreble(ctx))
                .addAction(new Notification.Action.Builder(icon(ctx), "Open",
                        openTreble(ctx)).build())
                .addAction(new Notification.Action.Builder(icon(ctx), "Turn off",
                        trebleStop(ctx)).build())
                .build();
    }

    public static void lowBattery(Context ctx, String deviceName, String kind, int level) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) {
            return;
        }
        String which;
        if ("left".equals(kind)) {
            which = "Left earbud";
        } else if ("right".equals(kind)) {
            which = "Right earbud";
        } else {
            which = "Battery";
        }
        Notification n = new Notification.Builder(ctx, CH_ALERT)
                .setSmallIcon(R.drawable.ic_stat_bluetooth)
                .setContentTitle(deviceName + " battery low")
                .setContentText(which + " is at " + level + "%. Charge soon.")
                .setAutoCancel(true)
                .setContentIntent(openApp(ctx))
                .build();
        int id = ID_ALERT_BASE + ("left".equals(kind) ? 1 : "right".equals(kind) ? 2 : 0);
        nm.notify(id, n);
    }

    public static void connectionEvent(Context ctx, String title, String text) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) {
            return;
        }
        Notification n = new Notification.Builder(ctx, CH_EVENTS)
                .setSmallIcon(R.drawable.ic_stat_bluetooth)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setTimeoutAfter(60L * 1000L)
                .setContentIntent(openApp(ctx))
                .build();
        nm.notify(ID_EVENT, n);
    }
}
