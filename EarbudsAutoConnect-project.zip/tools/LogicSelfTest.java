import com.btearbuds.autoconnect.logic.BatteryAlertEngine;
import com.btearbuds.autoconnect.logic.InsightCalculator;
import com.btearbuds.autoconnect.logic.RetryPolicy;
import com.btearbuds.autoconnect.logic.VendorBatteryParser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Plain-Java checks of the pure logic (no Android needed).
 * Run with tools/run_logic_tests.sh
 */
public class LogicSelfTest {
    static int passed = 0;
    static int failed = 0;

    static void check(String name, boolean ok) {
        if (ok) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL: " + name);
        }
    }

    public static void main(String[] args) {
        // ---- RetryPolicy: bounded, growing, never infinite
        check("retry first delay 20s", RetryPolicy.delayAfterFailures(0) == 20000L);
        check("retry delays grow", RetryPolicy.delayAfterFailures(1) > RetryPolicy.delayAfterFailures(0)
                && RetryPolicy.delayAfterFailures(2) > RetryPolicy.delayAfterFailures(1)
                && RetryPolicy.delayAfterFailures(3) > RetryPolicy.delayAfterFailures(2));
        check("retry stops after max", RetryPolicy.delayAfterFailures(RetryPolicy.maxAttempts()) == -1L);
        check("retry stops far past max", RetryPolicy.delayAfterFailures(1000) == -1L);
        check("retry negative treated as 0", RetryPolicy.delayAfterFailures(-5) == 20000L);
        int n = 0;
        while (RetryPolicy.delayAfterFailures(n) >= 0) {
            n++;
            if (n > 100) break;
        }
        check("retry loop terminates", n == RetryPolicy.maxAttempts());

        // ---- BatteryAlertEngine
        BatteryAlertEngine e = new BatteryAlertEngine(null);
        check("no alert above threshold", !e.onReading("single", 50, 20, true, true));
        check("alert at threshold", e.onReading("single", 20, 20, true, true));
        check("no repeat alert", !e.onReading("single", 19, 20, true, true));
        check("no repeat alert 2", !e.onReading("single", 10, 20, true, true));
        check("no re-arm inside margin", !e.onReading("single", 22, 20, true, true));
        check("still no repeat after margin dip", !e.onReading("single", 18, 20, true, true));
        check("recover re-arms (no alert on recover)", !e.onReading("single", 40, 20, true, true));
        check("alert again after recover", e.onReading("single", 15, 20, true, true));

        BatteryAlertEngine e2 = new BatteryAlertEngine(null);
        check("invalid -1 ignored", !e2.onReading("single", -1, 20, true, true));
        check("invalid 101 ignored", !e2.onReading("single", 101, 20, true, true));
        check("invalid 255 ignored", !e2.onReading("single", 255, 20, true, true));
        check("disconnected ignored", !e2.onReading("single", 5, 20, true, false));
        check("alerts disabled -> no alert", !e2.onReading("single", 5, 20, false, true));
        check("alerts enabled later -> alert", e2.onReading("single", 5, 20, true, true));

        BatteryAlertEngine e3 = new BatteryAlertEngine(null);
        check("left alerts", e3.onReading("left", 10, 20, true, true));
        check("right alerts independently", e3.onReading("right", 12, 20, true, true));
        check("left does not repeat", !e3.onReading("left", 9, 20, true, true));
        check("snapshot has both", e3.snapshot().contains("left") && e3.snapshot().contains("right"));
        BatteryAlertEngine e4 = new BatteryAlertEngine(e3.snapshot());
        check("restored state suppresses repeat", !e4.onReading("left", 8, 20, true, true));
        e4.reset();
        check("reset clears", e4.snapshot().isEmpty());
        BatteryAlertEngine e5 = new BatteryAlertEngine(null);
        check("threshold 50 works", e5.onReading("single", 50, 50, true, true));
        check("high threshold re-arm capped at 100", !e5.onReading("single", 100, 99, true, true));

        // ---- VendorBatteryParser (+IPHONEACCEV)
        check("accev battery 9 -> 100", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{2, 1, 9, 2, 0}), 100));
        check("accev battery 4 -> 50", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{1, 1, 4}), 50));
        check("accev battery 0 -> 10", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{1, 1, 0}), 10));
        check("accev strings parse", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{"1", "1", "7"}), 80));
        check("accev dock only -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{1, 2, 1}) == null);
        check("accev out of range -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{1, 1, 12}) == null);
        check("accev negative -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{1, 1, -1}) == null);
        check("accev null -> null", VendorBatteryParser.parseIphoneAccev(null) == null);
        check("accev too short -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{1, 1}) == null);
        check("accev garbage -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{"x", "y", "z"}) == null);
        check("accev zero count -> null", VendorBatteryParser.parseIphoneAccev(new Object[]{0, 1, 5}) == null);
        check("accev count larger than data ok", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{5, 1, 3}), 40)
                || VendorBatteryParser.parseIphoneAccev(new Object[]{5, 1, 3}) == null);
        check("accev second pair battery", eq(VendorBatteryParser.parseIphoneAccev(new Object[]{2, 2, 0, 1, 5}), 60));

        // ---- InsightCalculator
        List<InsightCalculator.Point> none = new ArrayList<InsightCalculator.Point>();
        check("empty -> no sessions", InsightCalculator.split(none).isEmpty());

        long t0 = 1000000000000L;
        long min = 60000L;
        List<InsightCalculator.Point> one = Arrays.asList(new InsightCalculator.Point(t0, 80));
        List<InsightCalculator.Session> s1 = InsightCalculator.split(one);
        check("one point -> 1 session", s1.size() == 1);
        check("one point NOT sufficient", !s1.get(0).isSufficient());

        List<InsightCalculator.Point> two = Arrays.asList(
                new InsightCalculator.Point(t0, 80), new InsightCalculator.Point(t0 + 5 * min, 70));
        check("2 points 5 min NOT sufficient", !InsightCalculator.split(two).get(0).isSufficient());

        List<InsightCalculator.Point> good = Arrays.asList(
                new InsightCalculator.Point(t0, 90), new InsightCalculator.Point(t0 + 30 * min, 80),
                new InsightCalculator.Point(t0 + 110 * min, 60));
        List<InsightCalculator.Session> sg = InsightCalculator.split(good);
        check("good data 1 session", sg.size() == 1);
        check("good data sufficient", sg.get(0).isSufficient());
        check("good change -30", sg.get(0).change() == -30);
        check("good span 110 min", sg.get(0).spanMs() == 110 * min);
        List<InsightCalculator.Point> exactGap = Arrays.asList(
                new InsightCalculator.Point(t0, 90), new InsightCalculator.Point(t0 + 90 * min, 80));
        check("gap of exactly 90 min stays one session", InsightCalculator.split(exactGap).size() == 1);
        List<InsightCalculator.Point> overGap = Arrays.asList(
                new InsightCalculator.Point(t0, 90), new InsightCalculator.Point(t0 + 91 * min, 80));
        check("gap over 90 min splits", InsightCalculator.split(overGap).size() == 2);

        List<InsightCalculator.Point> gap = Arrays.asList(
                new InsightCalculator.Point(t0, 90), new InsightCalculator.Point(t0 + 20 * min, 80),
                new InsightCalculator.Point(t0 + 400 * min, 70), new InsightCalculator.Point(t0 + 430 * min, 60));
        check("gap splits sessions", InsightCalculator.split(gap).size() == 2);

        List<InsightCalculator.Point> charge = Arrays.asList(
                new InsightCalculator.Point(t0, 30), new InsightCalculator.Point(t0 + 20 * min, 20),
                new InsightCalculator.Point(t0 + 40 * min, 60), new InsightCalculator.Point(t0 + 70 * min, 55));
        check("charging jump splits sessions", InsightCalculator.split(charge).size() == 2);

        check("format <1 min", InsightCalculator.formatDuration(30000L).equals("under 1 min"));
        check("format 45 min", InsightCalculator.formatDuration(45 * min).equals("45 min"));
        check("format 2 h", InsightCalculator.formatDuration(120 * min).equals("2 h"));
        check("format 2 h 10 min", InsightCalculator.formatDuration(130 * min).equals("2 h 10 min"));

        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    static boolean eq(Integer a, int b) {
        return a != null && a.intValue() == b;
    }
}
