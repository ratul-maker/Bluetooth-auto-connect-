package com.btearbuds.autoconnect.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.bt.StatusText;
import com.btearbuds.autoconnect.data.Db;
import com.btearbuds.autoconnect.data.Prefs;
import com.btearbuds.autoconnect.logic.InsightCalculator;

import java.util.ArrayList;
import java.util.List;

/** Local-only history: stored battery readings with observed changes, and a connection log. */
public final class HistoryActivity extends Activity {

    private static final long WINDOW_MS = 14L * 24L * 60L * 60L * 1000L;
    private static final int MAX_SESSIONS_SHOWN = 6;

    private Db db;
    private Prefs prefs;
    private LinearLayout page;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = Db.get(this);
        prefs = new Prefs(this);
        page = Ui.page(this, "History");
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        page.removeAllViews();
        page.addView(Ui.title(this, "History"));
        Ui.add(page, Ui.small(this, "Stored only on this phone. Nothing is sent anywhere."), 4);

        renderBattery();
        renderLog();
    }

    // ------------------------------------------------------------------ battery

    private void renderBattery() {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.heading(this, "BATTERY HISTORY"));

        if (!prefs.batteryHistory()) {
            Ui.add(card, Ui.body(this, "Battery history is turned off. You can turn it on in "
                    + "Settings."), 6);
            Ui.addCard(page, card);
            return;
        }

        long now = System.currentTimeMillis();
        List<Db.BatteryRow> rows = db.batterySince(now - WINDOW_MS);
        List<InsightCalculator.Point> points = new ArrayList<InsightCalculator.Point>();
        boolean coarse = false;
        for (Db.BatteryRow r : rows) {
            if ("single".equals(r.kind)) {
                points.add(new InsightCalculator.Point(r.time, r.level));
                if (r.source != null && r.source.contains("10%")) {
                    coarse = true;
                }
            }
        }
        List<InsightCalculator.Session> sessions = InsightCalculator.split(points);
        List<InsightCalculator.Session> good = new ArrayList<InsightCalculator.Session>();
        for (InsightCalculator.Session s : sessions) {
            if (s.isSufficient()) {
                good.add(s);
            }
        }

        if (good.isEmpty()) {
            String msg = points.isEmpty()
                    ? "No battery readings have been stored yet. Readings are saved only when your "
                    + "earbuds actually report a battery level."
                    : "Not enough real data yet: " + points.size() + " reading(s) stored. A trend "
                    + "needs at least two readings about 10 minutes apart in the same session.";
            Ui.add(card, Ui.body(this, msg), 6);
        } else {
            InsightCalculator.Session latest = good.get(good.size() - 1);
            long[] t = new long[latest.points.size()];
            int[] v = new int[latest.points.size()];
            for (int i = 0; i < t.length; i++) {
                t[i] = latest.points.get(i).time;
                v[i] = latest.points.get(i).level;
            }
            LineChartView chart = new LineChartView(this);
            chart.setData(t, v);
            chart.setContentDescription("Battery went from " + latest.startLevel() + " to "
                    + latest.endLevel() + " percent");
            Ui.add(card, chart, 8);

            Ui.add(card, Ui.body(this, "Latest session: " + latest.startLevel() + "% to "
                    + latest.endLevel() + "% over "
                    + InsightCalculator.formatDuration(latest.spanMs()) + " ("
                    + signed(latest.change()) + " points)."), 8);

            StringBuilder list = new StringBuilder();
            int shown = 0;
            for (int i = good.size() - 1; i >= 0 && shown < MAX_SESSIONS_SHOWN; i--, shown++) {
                InsightCalculator.Session s = good.get(i);
                if (list.length() > 0) {
                    list.append("\n");
                }
                list.append(StatusText.when(this, s.startTime())).append(": ")
                        .append(s.startLevel()).append("% → ").append(s.endLevel()).append("% (")
                        .append(InsightCalculator.formatDuration(s.spanMs())).append(")");
            }
            Ui.add(card, Ui.heading(this, "RECENT SESSIONS"), 14);
            Ui.add(card, Ui.body(this, list.toString()), 4);
        }

        String caveat = "This only shows what was actually recorded. It is not a prediction of "
                + "remaining playtime.";
        if (coarse) {
            caveat += " Your earbuds report in 10% steps, so small changes can't be seen.";
        }
        Ui.add(card, Ui.small(this, caveat), 10);

        if (!points.isEmpty()) {
            Ui.add(card, Ui.button(this, "Clear battery history", Ui.BTN_TEXT, v -> confirm(
                    "Clear battery history?", "All stored battery readings will be deleted.",
                    () -> {
                        db.clearBattery();
                        render();
                    })), 6);
        }
        Ui.addCard(page, card);
    }

    private static String signed(int v) {
        return v > 0 ? "+" + v : String.valueOf(v);
    }

    // ------------------------------------------------------------------ connection log

    private void renderLog() {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.heading(this, "CONNECTION LOG"));

        List<Db.LogRow> logs = db.recentLogs(200);
        if (logs.isEmpty()) {
            Ui.add(card, Ui.body(this, "Nothing logged yet. Connections, disconnections and failed "
                    + "attempts will appear here."), 6);
        } else {
            for (Db.LogRow r : logs) {
                LinearLayout row = Ui.column(this);
                TextView head = Ui.text(this, label(r.type) + "  ·  "
                        + StatusText.when(this, r.time), 13, colorFor(r.type), true);
                row.addView(head);
                if (r.detail != null && r.detail.length() > 0) {
                    row.addView(Ui.small(this, r.detail));
                }
                Ui.add(card, row, 10);
            }
            Ui.add(card, Ui.button(this, "Clear connection history", Ui.BTN_TEXT, v -> confirm(
                    "Clear connection history?", "The log of connections and attempts will be deleted.",
                    () -> {
                        db.clearLogs();
                        render();
                    })), 12);
        }
        Ui.addCard(page, card);
    }

    private static String label(String type) {
        if (type == null) {
            return "Event";
        }
        switch (type) {
            case "CONNECTED":
                return "Connected";
            case "DISCONNECTED":
                return "Disconnected";
            case "ATTEMPT":
                return "Attempt";
            case "ATTEMPT_FAILED":
                return "Attempt failed";
            case "GAVE_UP":
                return "Retries paused";
            case "SKIPPED":
                return "Skipped";
            case "CANNOT_REQUEST":
                return "Can't request";
            case "LINK_UP":
                return "Link up";
            case "LINK_DOWN":
                return "Link down";
            case "LINKED_NO_AUDIO":
                return "Nearby, no audio";
            case "BT_ON":
                return "Bluetooth on";
            case "BT_OFF":
                return "Bluetooth off";
            case "UNPAIRED":
                return "Unpaired";
            case "DEVICE_SELECTED":
                return "Device selected";
            default:
                return type;
        }
    }

    private static int colorFor(String type) {
        if (type == null) {
            return R.color.text_secondary;
        }
        switch (type) {
            case "CONNECTED":
                return R.color.ok;
            case "ATTEMPT_FAILED":
            case "UNPAIRED":
                return R.color.error;
            case "GAVE_UP":
            case "LINKED_NO_AUDIO":
            case "CANNOT_REQUEST":
            case "SKIPPED":
                return R.color.warn;
            default:
                return R.color.text_secondary;
        }
    }

    private void confirm(String title, String message, final Runnable onYes) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear", (d, w) -> onYes.run())
                .show();
    }
}
