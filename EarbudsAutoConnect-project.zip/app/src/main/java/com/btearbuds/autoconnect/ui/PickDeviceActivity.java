package com.btearbuds.autoconnect.ui;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.LinearLayout;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.bt.BtController;
import com.btearbuds.autoconnect.bt.BtUtil;
import com.btearbuds.autoconnect.bt.Snapshot;
import com.btearbuds.autoconnect.data.Prefs;

import java.util.List;
import java.util.Set;

/**
 * Lists devices that are ALREADY paired with the phone (audio devices first). It never scans and
 * never pairs. Selecting one stores only its address and name.
 */
public final class PickDeviceActivity extends Activity implements BtController.Listener {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private BtController controller;
    private Prefs prefs;
    private boolean holding;
    private boolean showOthers;

    private LinearLayout list;
    private Ui.SwitchRow othersRow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        controller = BtController.get(this);

        LinearLayout page = Ui.page(this, "Choose earbuds");
        page.addView(Ui.title(this, "Choose earbuds"));
        Ui.add(page, Ui.body(this, "These are the Bluetooth audio devices already paired with this "
                + "phone. Pick the one this app should look after. The app never scans for or pairs "
                + "new devices."), 8);

        othersRow = Ui.switchRow(this, "Show other paired devices",
                "Include paired devices that Android doesn't list as audio devices.", checked -> {
                    showOthers = checked;
                    render();
                });
        Ui.add(page, othersRow.view, 8);

        list = Ui.column(this);
        Ui.add(page, list, 8);

        Ui.add(page, Ui.button(this, "Open Bluetooth settings (to pair new earbuds)", Ui.BTN_TONAL,
                v -> Ui.openBluetoothSettings(this)), 8);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!holding) {
            holding = true;
            controller.addListener(this);
            controller.acquire(false);
        }
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        render(); // the list may have changed while the user was in Bluetooth settings
    }

    @Override
    protected void onStop() {
        handler.removeCallbacksAndMessages(null);
        if (holding) {
            holding = false;
            controller.removeListener(this);
            controller.release(false);
        }
        super.onStop();
    }

    @Override
    public void onSnapshot(Snapshot s) {
        handler.removeCallbacks(renderRunnable);
        handler.postDelayed(renderRunnable, 250L);
    }

    private final Runnable renderRunnable = new Runnable() {
        @Override
        public void run() {
            render();
        }
    };

    private void render() {
        list.removeAllViews();
        Snapshot s = controller.snapshot();
        othersRow.set(showOthers);

        if (!s.adapterPresent) {
            list.addView(messageCard("Bluetooth isn't available on this phone right now.", null, null));
            return;
        }
        if (!s.permissionOk) {
            list.addView(messageCard("Bluetooth permission is missing. Open App info, then "
                    + "Permissions, and allow it.", "Open App info", () -> Ui.openAppInfo(this)));
            return;
        }
        if (!s.adapterOn) {
            list.addView(messageCard("Bluetooth is off. Turn it on to see your paired devices.",
                    "Turn on Bluetooth", () -> Ui.requestEnableBluetooth(this)));
            return;
        }

        List<BluetoothDevice> devices = BtUtil.pairedDevices(this, showOthers);
        if (devices.isEmpty()) {
            list.addView(messageCard("No paired audio devices found.\n\nTo pair earbuds: open "
                    + "Bluetooth settings, put the earbuds in pairing mode (usually open the case or "
                    + "hold the button until a light blinks), tap them under \"Available devices\", "
                    + "then come back here.\n\nIf your earbuds are already paired but missing, turn "
                    + "on \"Show other paired devices\" above.", "Open Bluetooth settings",
                    () -> Ui.openBluetoothSettings(this)));
            return;
        }

        Set<String> connected = controller.connectedAudioAddresses();
        boolean known = controller.connectionStateKnown();
        String current = prefs.preferredAddress();
        for (BluetoothDevice d : devices) {
            list.addView(deviceCard(d, connected, known, current));
        }

        if (current != null) {
            Ui.add(list, Ui.button(this, "Clear selected earbuds", Ui.BTN_TEXT, v -> {
                prefs.clearPreferred();
                prefs.setMonitoring(false);
                com.btearbuds.autoconnect.service.MonitorService.stop(this);
                controller.onPreferredDeviceChanged();
                render();
            }), 0);
        }
    }

    private LinearLayout messageCard(String message, String actionLabel, final Runnable action) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.body(this, message));
        if (actionLabel != null) {
            Ui.add(card, Ui.button(this, actionLabel, Ui.BTN_TONAL, v -> action.run()), 10);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, Ui.dp(this, 12));
        card.setLayoutParams(lp);
        return card;
    }

    private LinearLayout deviceCard(final BluetoothDevice d, Set<String> connected, boolean known,
                                    String current) {
        final String address = d.getAddress();
        final String name = BtUtil.safeName(d);
        boolean isCurrent = address != null && address.equalsIgnoreCase(current);

        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, name, 18, R.color.text_primary, true));

        StringBuilder meta = new StringBuilder(BtUtil.typeLabel(d));
        String transport = BtUtil.transportLabel(d);
        if (transport != null) {
            meta.append(" · ").append(transport);
        }
        Ui.add(card, Ui.small(this, meta.toString()), 2);

        String state;
        int color;
        if (!known) {
            state = "Checking connection...";
            color = R.color.idle;
        } else if (connected.contains(address)) {
            state = "Connected now";
            color = R.color.ok;
        } else {
            state = "Not connected";
            color = R.color.idle;
        }
        LinearLayout statusRow = Ui.row(this);
        statusRow.addView(Ui.dot(this, Ui.col(this, color)));
        statusRow.addView(Ui.text(this, state, 14, R.color.text_primary, false));
        Ui.add(card, statusRow, 8);

        Boolean a2dp = BtUtil.advertisesA2dp(d);
        Boolean hfp = BtUtil.advertisesHandsFree(d);
        StringBuilder profiles = new StringBuilder();
        if (a2dp != null) {
            profiles.append(a2dp ? "Music (A2DP): yes" : "Music (A2DP): not advertised");
        }
        if (hfp != null) {
            profiles.append(profiles.length() > 0 ? " · " : "")
                    .append(hfp ? "Calls: yes" : "Calls: not advertised");
        }
        if (profiles.length() > 0) {
            Ui.add(card, Ui.small(this, profiles.toString()), 4);
        }

        if (isCurrent) {
            Ui.add(card, Ui.small(this, "Currently selected"), 10);
        } else {
            Ui.add(card, Ui.button(this, current == null ? "Select" : "Select instead",
                    Ui.BTN_PRIMARY, v -> select(address, name)), 10);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, Ui.dp(this, 12));
        card.setLayoutParams(lp);
        return card;
    }

    private void select(String address, String name) {
        prefs.setPreferred(address, name);
        controller.onPreferredDeviceChanged();
        Ui.toast(this, name + " selected.");
        finish();
    }
}
