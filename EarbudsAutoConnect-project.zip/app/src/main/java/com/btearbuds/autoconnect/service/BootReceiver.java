package com.btearbuds.autoconnect.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.btearbuds.autoconnect.data.Prefs;

/** After a reboot or an app update, restores monitoring - but only if you had turned it on. */
public final class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }
        String a = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(a) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            return;
        }
        try {
            Prefs p = new Prefs(context);
            if (p.monitoring() && p.preferredAddress() != null) {
                Notifs.ensureChannels(context);
                MonitorService.start(context);
            }
        } catch (RuntimeException e) {
            // Never crash a boot broadcast.
        }
    }
}
