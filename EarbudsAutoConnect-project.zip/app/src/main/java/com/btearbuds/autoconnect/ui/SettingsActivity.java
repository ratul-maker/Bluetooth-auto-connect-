package com.btearbuds.autoconnect.ui;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.data.Prefs;

/** Alerts, history, widgets, "keep it running" help for XOS, privacy and limits. */
public final class SettingsActivity extends Activity {

    private static final int MIN_THRESHOLD = 5;
    private static final int MAX_THRESHOLD = 50;

    private Prefs prefs;
    private TextView thresholdLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);

        LinearLayout page = Ui.page(this, "Settings");
        page.addView(Ui.title(this, "Settings"));

        // ---- alerts
        LinearLayout alerts = Ui.card(this);
        alerts.addView(Ui.heading(this, "BATTERY ALERTS"));
        Ui.SwitchRow alertsRow = Ui.switchRow(this, "Low-battery alert",
                "One alert when the battery falls to your limit. It repeats only after the level "
                        + "recovers and drops again. Never based on missing readings.",
                checked -> prefs.setAlertsEnabled(checked));
        alertsRow.set(prefs.alertsEnabled());
        Ui.add(alerts, alertsRow.view, 6);

        thresholdLabel = Ui.text(this, "", 15, R.color.text_primary, true);
        Ui.add(alerts, thresholdLabel, 10);
        SeekBar bar = new SeekBar(this);
        bar.setMax(MAX_THRESHOLD - MIN_THRESHOLD);
        bar.setProgress(prefs.alertThreshold() - MIN_THRESHOLD);
        bar.setContentDescription("Low battery limit");
        updateThresholdLabel(prefs.alertThreshold());
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int value = progress + MIN_THRESHOLD;
                updateThresholdLabel(value);
                if (fromUser) {
                    prefs.setAlertThreshold(value);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        Ui.styleSeekBar(this, bar);
        Ui.add(alerts, bar, 4);

        Ui.SwitchRow connRow = Ui.switchRow(this, "Connection notifications",
                "Show a short notification when your earbuds connect or disconnect.",
                checked -> prefs.setConnectionNotifications(checked));
        connRow.set(prefs.connectionNotifications());
        Ui.add(alerts, connRow.view, 12);
        Ui.addCard(page, alerts);

        // ---- history
        LinearLayout history = Ui.card(this);
        history.addView(Ui.heading(this, "BATTERY HISTORY"));
        Ui.SwitchRow histRow = Ui.switchRow(this, "Save battery readings",
                "Keeps real readings (with times) on this phone so History can show observed "
                        + "changes. Turn off to stop saving.",
                checked -> prefs.setBatteryHistory(checked));
        histRow.set(prefs.batteryHistory());
        Ui.add(history, histRow.view, 6);
        Ui.addCard(page, history);

        // ---- keep running
        LinearLayout keep = Ui.card(this);
        keep.addView(Ui.heading(this, "KEEP IT RUNNING (INFINIX / XOS)"));
        Ui.add(keep, Ui.body(this, "Background Monitoring uses a visible notification. Android and "
                + "XOS can still pause apps to save power, and no app can prevent a force-stop or a "
                + "restart. These steps help; menu names differ between XOS versions:"), 6);
        Ui.add(keep, Ui.body(this, "1. Allow background activity: Settings > Apps > Earbuds "
                + "Auto-Connect > Battery, then choose No restrictions (or Allow background "
                + "activity).\n\n"
                + "2. Autostart: in Phone Master (or Settings > Battery / App management), allow "
                + "Earbuds Auto-Connect to start automatically.\n\n"
                + "3. Lock the app in Recents: open the recent-apps screen and use the lock option on "
                + "the app's card so \"Clear all\" doesn't close it.\n\n"
                + "4. If the monitoring notification disappears, the system stopped it - open the "
                + "app and turn Background Monitoring off and on."), 8);
        Ui.add(keep, Ui.button(this, "Battery optimisation settings", Ui.BTN_TONAL,
                v -> Ui.openBatteryOptimization(this)), 12);
        Ui.add(keep, Ui.button(this, "Open App info", Ui.BTN_TEXT, v -> Ui.openAppInfo(this)), 4);
        Ui.addCard(page, keep);

        // ---- widgets
        LinearLayout widgets = Ui.card(this);
        widgets.addView(Ui.heading(this, "HOME-SCREEN WIDGETS"));
        Ui.add(widgets, Ui.body(this, "Two widgets are available: \"Earbuds - compact\" (one slim "
                + "row) and \"Earbuds - expanded\" (status, battery, connected-since time and a "
                + "live timer). Touch and hold an empty spot on your home screen, tap Widgets, "
                + "find Earbuds Auto-Connect and drag one out."), 6);
        Ui.add(widgets, Ui.body(this, "Widgets cannot watch Bluetooth themselves. The app updates "
                + "them only when something changes, and only while it is running (the app open or "
                + "Background Monitoring on). When the app isn't watching, the widget says so, shows "
                + "what was last seen, and shows no running timer or battery number. Android itself "
                + "refreshes widgets at most every 30 minutes; the app adds no extra background "
                + "work for them."), 8);
        Ui.addCard(page, widgets);

        // ---- tile
        LinearLayout tile = Ui.card(this);
        tile.addView(Ui.heading(this, "QUICK SETTINGS TILE"));
        Ui.add(tile, Ui.body(this, "Swipe down twice to open Quick Settings, tap the pencil (edit) "
                + "icon and drag \"Earbuds\" into your active tiles. It shows the real connection "
                + "state. Tapping it opens the app when connected, or sends one connection request "
                + "when not connected."), 6);
        Ui.addCard(page, tile);

        // ---- limits & privacy
        LinearLayout about = Ui.card(this);
        about.addView(Ui.heading(this, "HONEST LIMITS"));
        Ui.add(about, Ui.body(this, "• Android 11 gives apps no direct way to connect or "
                + "disconnect Bluetooth headsets. \"Connect now\" is a best-effort request whose "
                + "result is always verified. If it can't work for your earbuds, the app says so.\n"
                + "• Battery appears only if your earbuds report it to Android. Left/right "
                + "levels and case battery are not available through public Android APIs, so they "
                + "are never shown.\n"
                + "• The app can't tell whether earbuds are in their case, or whether one or "
                + "both are connected.\n"
                + "• Connection history records only what the app sees while it is running. "
                + "Times it couldn't watch are shown as gaps, never filled in.\n"
                + "• Treble Lab asks Android's equalizer for the change and checks that Android "
                + "accepted it. It can't hear the result, and some phones or apps ignore it."), 6);
        Ui.addCard(page, about);

        LinearLayout privacy = Ui.card(this);
        privacy.addView(Ui.heading(this, "PRIVACY"));
        Ui.add(privacy, Ui.body(this, "This app has no internet permission, no account, no ads and "
                + "no analytics. It stores only: your chosen earbuds' name and address, your "
                + "settings, connection sessions, a connection log, the last state shown on "
                + "widgets, your treble setting and (optionally) battery readings - all on this "
                + "phone. Uninstalling the app deletes everything."), 6);
        Ui.add(privacy, Ui.small(this, "Permissions used: Bluetooth (see paired devices, connection "
                + "state), Foreground service (the monitoring and Treble Lab notifications), Run at "
                + "startup (restore monitoring or Treble Lab after a reboot if you turned them on), "
                + "Change audio settings (Treble Lab only: lets the app attach an equalizer; it can't "
                + "record or read audio)."), 8);
        Ui.add(privacy, Ui.small(this, versionLine()), 8);
        Ui.addCard(page, privacy);
    }

    private void updateThresholdLabel(int value) {
        thresholdLabel.setText("Alert at or below " + value + "%");
    }

    private String versionLine() {
        String v = "unknown";
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            v = pi.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            // keep "unknown"
        }
        return "Version " + v + " · Android " + Build.VERSION.RELEASE;
    }
}
