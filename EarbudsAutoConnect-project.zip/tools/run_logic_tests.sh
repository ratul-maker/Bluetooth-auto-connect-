#!/usr/bin/env bash
# Compiles and runs the pure-Java logic checks. Needs only a JDK (no Android SDK).
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
javac -d "$OUT" app/src/main/java/com/btearbuds/autoconnect/logic/*.java app/src/main/java/com/btearbuds/autoconnect/treble/TrebleMath.java tools/LogicSelfTest.java
java -cp "$OUT" LogicSelfTest
