package com.btearbuds.autoconnect.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.treble.TrebleMath;

/**
 * A rotary dial for the treble amount. The full scale is -12 to +12 dB; the part of the scale the
 * phone's equalizer can't reach is drawn dim and the dial refuses to go there.
 */
public final class TrebleDialView extends View {

    public interface Listener {
        void onValueChanged(double db, boolean fromUser);
    }

    private static final float START_ANGLE = 135f;
    private static final float SWEEP = 270f;

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lockedTrack = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint active = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valueText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint unitText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint scaleText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();

    private double value;
    private int minUsable = (int) TrebleMath.MIN_DB;
    private int maxUsable = (int) TrebleMath.MAX_DB;
    private boolean dialEnabled = true;
    private Listener listener;
    private float cx;
    private float cy;
    private float arcR;

    public TrebleDialView(Context c) {
        super(c);
        float stroke = Ui.dp(c, 8);
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(stroke);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setColor(c.getColor(R.color.surface_high));
        lockedTrack.setStyle(Paint.Style.STROKE);
        lockedTrack.setStrokeWidth(stroke);
        lockedTrack.setStrokeCap(Paint.Cap.BUTT);
        lockedTrack.setColor(0x40FF4D6A);
        active.setStyle(Paint.Style.STROKE);
        active.setStrokeWidth(stroke);
        active.setStrokeCap(Paint.Cap.ROUND);
        tick.setStyle(Paint.Style.STROKE);
        tick.setStrokeWidth(Ui.dp(c, 1.5f));
        knobGlow.setStyle(Paint.Style.FILL);
        knob.setStyle(Paint.Style.FILL);
        knob.setColor(c.getColor(R.color.text_primary));
        valueText.setTextAlign(Paint.Align.CENTER);
        valueText.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        valueText.setColor(c.getColor(R.color.text_primary));
        unitText.setTextAlign(Paint.Align.CENTER);
        unitText.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        unitText.setColor(c.getColor(R.color.text_secondary));
        unitText.setLetterSpacing(0.2f);
        scaleText.setTextAlign(Paint.Align.CENTER);
        scaleText.setColor(c.getColor(R.color.text_dim));
        setFocusable(true);
        updateDescription();
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    /** The whole-dB range the phone's equalizer can actually reach. */
    public void setUsableRange(int minDb, int maxDb) {
        minUsable = minDb;
        maxUsable = maxDb;
        value = TrebleMath.clamp(value, new int[]{minDb, maxDb});
        invalidate();
    }

    public void setDialEnabled(boolean enabled) {
        dialEnabled = enabled;
        setAlpha(enabled ? 1f : 0.45f);
        setEnabled(enabled);
    }

    public double getValue() {
        return value;
    }

    public void setValue(double db) {
        double v = TrebleMath.clamp(TrebleMath.snap(db), new int[]{minUsable, maxUsable});
        if (v != value) {
            value = v;
            updateDescription();
            invalidate();
        }
    }

    private void updateDescription() {
        setContentDescription("Treble, " + TrebleMath.formatDb(value)
                + ". Swipe up or down with TalkBack to adjust.");
    }

    // ------------------------------------------------------------------ layout & drawing

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int size = Ui.dp(getContext(), 250);
        int w = resolveSize(size, widthSpec);
        setMeasuredDimension(w, resolveSize(Math.min(w, size), heightSpec));
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        cx = w / 2f;
        cy = h / 2f;
        float r = Math.min(w, h) / 2f;
        arcR = r - Ui.dp(getContext(), 30);
        oval.set(cx - arcR, cy - arcR, cx + arcR, cy + arcR);
        valueText.setTextSize(arcR * 0.50f);
        unitText.setTextSize(arcR * 0.15f);
        scaleText.setTextSize(arcR * 0.13f);
        core.setShader(new RadialGradient(cx, cy, arcR * 0.8f,
                new int[]{0x2200E5FF, 0xFF04090D, 0xFF000000}, new float[]{0f, 0.85f, 1f},
                Shader.TileMode.CLAMP));
    }

    private static float angleFor(double db) {
        return START_ANGLE + SWEEP * (float) ((db - TrebleMath.MIN_DB)
                / (TrebleMath.MAX_DB - TrebleMath.MIN_DB));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Context c = getContext();
        int cyan = c.getColor(R.color.primary);
        int violet = c.getColor(R.color.accent);

        canvas.drawCircle(cx, cy, arcR * 0.80f, core);

        // full track, then the unreachable ends dimmed with a red tint
        canvas.drawArc(oval, START_ANGLE, SWEEP, false, track);
        if (minUsable > TrebleMath.MIN_DB) {
            float a0 = angleFor(TrebleMath.MIN_DB);
            float a1 = angleFor(minUsable);
            canvas.drawArc(oval, a0, a1 - a0, false, lockedTrack);
        }
        if (maxUsable < TrebleMath.MAX_DB) {
            float a0 = angleFor(maxUsable);
            float a1 = angleFor(TrebleMath.MAX_DB);
            canvas.drawArc(oval, a0, a1 - a0, false, lockedTrack);
        }

        // ticks every 1 dB
        float tickOuter = arcR + Ui.dp(c, 12);
        for (int k = (int) TrebleMath.MIN_DB; k <= (int) TrebleMath.MAX_DB; k++) {
            boolean major = k % 6 == 0;
            boolean usable = k >= minUsable && k <= maxUsable;
            double rad = Math.toRadians(angleFor(k));
            float inner = tickOuter - Ui.dp(c, major ? 8 : 4);
            tick.setColor(usable ? (major ? cyan : 0x6600E5FF) : 0x33FFFFFF);
            canvas.drawLine(cx + (float) Math.cos(rad) * inner, cy + (float) Math.sin(rad) * inner,
                    cx + (float) Math.cos(rad) * tickOuter, cy + (float) Math.sin(rad) * tickOuter,
                    tick);
        }
        // scale labels
        float labelR = arcR + Ui.dp(c, 26);
        drawScaleLabel(canvas, "-12", -12, labelR);
        drawScaleLabel(canvas, "0", 0, labelR);
        drawScaleLabel(canvas, "+12", 12, labelR);

        // active arc from 0 to the value
        float zero = angleFor(0);
        float now = angleFor(value);
        active.setColor(value >= 0 ? cyan : violet);
        if (Math.abs(now - zero) > 0.1f) {
            canvas.drawArc(oval, Math.min(zero, now), Math.abs(now - zero), false, active);
        }

        // knob with a soft glow
        double rad = Math.toRadians(now);
        float kx = cx + (float) Math.cos(rad) * arcR;
        float ky = cy + (float) Math.sin(rad) * arcR;
        int glow = value >= 0 ? cyan : violet;
        knobGlow.setColor((glow & 0x00FFFFFF) | 0x22000000);
        canvas.drawCircle(kx, ky, Ui.dp(c, 18), knobGlow);
        knobGlow.setColor((glow & 0x00FFFFFF) | 0x55000000);
        canvas.drawCircle(kx, ky, Ui.dp(c, 12), knobGlow);
        canvas.drawCircle(kx, ky, Ui.dp(c, 7), knob);

        // centre read-out
        String v = TrebleMath.formatDb(value).replace(" dB", "");
        canvas.drawText(v, cx, cy + valueText.getTextSize() * 0.15f, valueText);
        canvas.drawText("dB  TREBLE", cx, cy + valueText.getTextSize() * 0.15f
                + unitText.getTextSize() * 1.9f, unitText);
    }

    private void drawScaleLabel(Canvas canvas, String label, int db, float r) {
        double rad = Math.toRadians(angleFor(db));
        float x = cx + (float) Math.cos(rad) * r;
        float y = cy + (float) Math.sin(rad) * r - (scaleText.descent() + scaleText.ascent()) / 2f;
        canvas.drawText(label, x, y, scaleText);
    }

    // ------------------------------------------------------------------ touch & accessibility

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!dialEnabled) {
            return false;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(true);
                }
                moveTo(e.getX(), e.getY());
                return true;
            case MotionEvent.ACTION_MOVE:
                moveTo(e.getX(), e.getY());
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                }
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    private void moveTo(float x, float y) {
        double deg = Math.toDegrees(Math.atan2(y - cy, x - cx));
        double rel = (deg - START_ANGLE + 720.0) % 360.0;
        if (rel > SWEEP) {
            // finger is in the gap at the bottom: stick to the nearer end
            rel = (rel - SWEEP) < (360.0 - rel) ? SWEEP : 0.0;
        }
        double target = TrebleMath.MIN_DB + (TrebleMath.MAX_DB - TrebleMath.MIN_DB) * (rel / SWEEP);
        target = TrebleMath.snap(target);
        // ignore a jump across the gap (from one end of the scale straight to the other)
        if (Math.abs(target - value) > 14.0) {
            return;
        }
        applyFromUser(target);
    }

    private void applyFromUser(double db) {
        double v = TrebleMath.clamp(db, new int[]{minUsable, maxUsable});
        if (v != value) {
            value = v;
            updateDescription();
            invalidate();
            if (listener != null) {
                listener.onValueChanged(value, true);
            }
        }
    }

    @Override
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        if (dialEnabled) {
            info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD);
            info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD);
        }
    }

    @Override
    public boolean performAccessibilityAction(int action, Bundle args) {
        if (dialEnabled && action == AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) {
            applyFromUser(value + 1.0);
            return true;
        }
        if (dialEnabled && action == AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) {
            applyFromUser(value - 1.0);
            return true;
        }
        return super.performAccessibilityAction(action, args);
    }
}
