package com.btearbuds.autoconnect.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/** The only settings the app stores, all in private local storage. */
public final class Prefs {

    private static final String FILE = "settings";

    private static final String K_ADDRESS = "preferred_address";
    private static final String K_NAME = "preferred_name";
    private static final String K_AUTO = "auto_connect";
    private static final String K_MONITOR = "monitoring";
    private static final String K_ALERTS = "alerts_enabled";
    private static final String K_THRESHOLD = "alert_threshold";
    private static final String K_CONN_NOTIF = "connection_notifications";
    private static final String K_HISTORY = "battery_history";
    private static final String K_ATTEMPT_TIME = "last_attempt_time";
    private static final String K_ATTEMPT_RESULT = "last_attempt_result";
    private static final String K_SUCCESS_TIME = "last_success_time";
    private static final String K_ALERTED = "alerted_keys";
    private static final String K_BAT_LEVEL = "last_battery_level";
    private static final String K_BAT_TIME = "last_battery_time";
    private static final String K_BAT_SOURCE = "last_battery_source";
    private static final String K_LISTEN_SINCE = "listen_tracking_since";

    public static final int DEFAULT_THRESHOLD = 20;

    private final SharedPreferences sp;

    public Prefs(Context context) {
        sp = context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    // ---- preferred device
    public String preferredAddress() {
        return sp.getString(K_ADDRESS, null);
    }

    public String preferredName() {
        return sp.getString(K_NAME, null);
    }

    public void setPreferred(String address, String name) {
        sp.edit().putString(K_ADDRESS, address).putString(K_NAME, name).apply();
    }

    public void clearPreferred() {
        sp.edit().remove(K_ADDRESS).remove(K_NAME)
                .remove(K_BAT_LEVEL).remove(K_BAT_TIME).remove(K_BAT_SOURCE)
                .remove(K_ALERTED).apply();
    }

    // ---- toggles
    public boolean autoConnect() {
        return sp.getBoolean(K_AUTO, true);
    }

    public void setAutoConnect(boolean v) {
        sp.edit().putBoolean(K_AUTO, v).apply();
    }

    public boolean monitoring() {
        return sp.getBoolean(K_MONITOR, false);
    }

    public void setMonitoring(boolean v) {
        sp.edit().putBoolean(K_MONITOR, v).apply();
    }

    public boolean alertsEnabled() {
        return sp.getBoolean(K_ALERTS, true);
    }

    public void setAlertsEnabled(boolean v) {
        sp.edit().putBoolean(K_ALERTS, v).apply();
    }

    public int alertThreshold() {
        int v = sp.getInt(K_THRESHOLD, DEFAULT_THRESHOLD);
        if (v < 5) v = 5;
        if (v > 50) v = 50;
        return v;
    }

    public void setAlertThreshold(int v) {
        sp.edit().putInt(K_THRESHOLD, v).apply();
    }

    public boolean connectionNotifications() {
        return sp.getBoolean(K_CONN_NOTIF, false);
    }

    public void setConnectionNotifications(boolean v) {
        sp.edit().putBoolean(K_CONN_NOTIF, v).apply();
    }

    public boolean batteryHistory() {
        return sp.getBoolean(K_HISTORY, true);
    }

    public void setBatteryHistory(boolean v) {
        sp.edit().putBoolean(K_HISTORY, v).apply();
    }

    // ---- last attempt / success
    public long lastAttemptTime() {
        return sp.getLong(K_ATTEMPT_TIME, 0L);
    }

    public String lastAttemptResult() {
        return sp.getString(K_ATTEMPT_RESULT, null);
    }

    public void setLastAttempt(long time, String result) {
        sp.edit().putLong(K_ATTEMPT_TIME, time).putString(K_ATTEMPT_RESULT, result).apply();
    }

    /**
     * When listening-time tracking first ran on this phone (0 = never). Connections that began before
     * this moment are shown without a listening figure, because none was being recorded.
     */
    public long listenTrackingSince() {
        return sp.getLong(K_LISTEN_SINCE, 0L);
    }

    public void setListenTrackingSince(long t) {
        sp.edit().putLong(K_LISTEN_SINCE, t).apply();
    }

    public long lastSuccessTime() {
        return sp.getLong(K_SUCCESS_TIME, 0L);
    }

    public void setLastSuccessTime(long t) {
        sp.edit().putLong(K_SUCCESS_TIME, t).apply();
    }

    // ---- alert state (so a process restart does not repeat an alert)
    public Set<String> alertedKeys() {
        Set<String> s = sp.getStringSet(K_ALERTED, null);
        return s == null ? new HashSet<String>() : new HashSet<String>(s);
    }

    public void setAlertedKeys(Set<String> keys) {
        sp.edit().putStringSet(K_ALERTED, new HashSet<String>(keys)).apply();
    }

    // ---- last verified battery reading (shown only as "last reading", never as live)
    public int lastBatteryLevel() {
        return sp.getInt(K_BAT_LEVEL, -1);
    }

    public long lastBatteryTime() {
        return sp.getLong(K_BAT_TIME, 0L);
    }

    public String lastBatterySource() {
        return sp.getString(K_BAT_SOURCE, null);
    }

    public void setLastBattery(int level, long time, String source) {
        sp.edit().putInt(K_BAT_LEVEL, level).putLong(K_BAT_TIME, time)
                .putString(K_BAT_SOURCE, source).apply();
    }
}
