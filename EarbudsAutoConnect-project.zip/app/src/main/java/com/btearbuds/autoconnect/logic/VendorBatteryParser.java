package com.btearbuds.autoconnect.logic;

/**
 * Parses battery information from Bluetooth Hands-Free vendor-specific events.
 *
 * Only the widely documented Apple "+IPHONEACCEV" accessory event is understood:
 * AT+IPHONEACCEV=count,key1,val1,key2,val2,...
 *   key 1 = headset battery level, value 0..9
 *   key 2 = dock state (ignored - never treated as battery)
 *
 * The protocol only has 10 steps, so the value is mapped to 10%..100% in steps of 10.
 * Anything that does not parse cleanly returns null (= no reading).
 */
public final class VendorBatteryParser {

    private VendorBatteryParser() {
    }

    public static Integer parseIphoneAccev(Object[] args) {
        if (args == null || args.length < 3) {
            return null;
        }
        Integer count = toInt(args[0]);
        if (count == null || count.intValue() < 1) {
            return null;
        }
        int pairs = Math.min(count.intValue(), (args.length - 1) / 2);
        for (int i = 0; i < pairs; i++) {
            Integer key = toInt(args[1 + 2 * i]);
            Integer value = toInt(args[2 + 2 * i]);
            if (key != null && key.intValue() == 1) {
                if (value == null || value.intValue() < 0 || value.intValue() > 9) {
                    return null;
                }
                return Integer.valueOf((value.intValue() + 1) * 10);
            }
        }
        return null;
    }

    private static Integer toInt(Object o) {
        if (o instanceof Integer) {
            return (Integer) o;
        }
        if (o instanceof Number) {
            return Integer.valueOf(((Number) o).intValue());
        }
        if (o instanceof String) {
            try {
                return Integer.valueOf(Integer.parseInt(((String) o).trim()));
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }
}
