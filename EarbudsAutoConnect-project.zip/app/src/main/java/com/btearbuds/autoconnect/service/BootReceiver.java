package com.btearbuds.autoconnect.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.btearbuds.autoconnect.data.Prefs;
import com.btearbuds.autoconnect.treble.TrebleService;
import com.btearbuds.autoconnect.treble.TreblePrefs;
import com.btearbuds.autoconnect.widget.WidgetUpdater;

/** After a reboot or an app update, restores monitoring and Treble Lab - only if you had turned them on. */
public final class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }
        String a = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(a) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            return;
        }
        try {
            Prefs p = new Prefs(context);
            if (p.monitoring() && p.preferredAddress() != null) {
                Notifs.ensureChannels(context);
                MonitorService.start(context);
            }
        } catch (RuntimeException e) {
            // Never crash a boot broadcast.
        }
        try {
            // Treble Lab only comes back if you had turned it on.
            if (new TreblePrefs(context).enabled()) {
                Notifs.ensureChannels(context);
                TrebleService.start(context);
            }
        } catch (RuntimeException e) {
            // ignore
        }
        try {
            // After a restart nothing is being watched yet, so widgets must say "last known".
            WidgetUpdater.refresh(context);
        } catch (RuntimeException e) {
            // ignore
        }
    }
}
