package com.btearbuds.autoconnect.service;

import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

import com.btearbuds.autoconnect.bt.BtController;
import com.btearbuds.autoconnect.bt.Snapshot;
import com.btearbuds.autoconnect.bt.StatusText;
import com.btearbuds.autoconnect.ui.MainActivity;

/**
 * Optional Quick Settings tile. Shows the real connection state. Tapping it:
 *  - connected / no device / Bluetooth off: opens the app
 *  - not connected: sends one connection request (verified afterwards) via a short-lived service.
 */
public final class ConnectTileService extends TileService implements BtController.Listener {

    private BtController controller;
    private boolean listening;

    @Override
    public void onStartListening() {
        super.onStartListening();
        controller = BtController.get(this);
        if (!listening) {
            listening = true;
            controller.addListener(this);
            controller.acquire(false);
        }
        render(controller.snapshot());
    }

    @Override
    public void onStopListening() {
        if (listening) {
            listening = false;
            controller.removeListener(this);
            controller.release(false);
        }
        super.onStopListening();
    }

    @Override
    public void onSnapshot(Snapshot s) {
        render(s);
    }

    private void render(Snapshot s) {
        Tile t = getQsTile();
        if (t == null) {
            return;
        }
        t.setLabel(s.deviceName != null ? s.deviceName : "Earbuds");
        String state = StatusText.label(s);
        if (Build.VERSION.SDK_INT >= 29) {
            t.setSubtitle(state);
        }
        Snapshot.Status st = s.status();
        if (st == Snapshot.Status.CONNECTED || st == Snapshot.Status.CALLS_ONLY) {
            t.setState(Tile.STATE_ACTIVE);
        } else if (st == Snapshot.Status.DISCONNECTED || st == Snapshot.Status.CONNECTING
                || st == Snapshot.Status.LINKED_NO_AUDIO) {
            t.setState(Tile.STATE_INACTIVE);
        } else {
            t.setState(Tile.STATE_UNAVAILABLE);
        }
        t.updateTile();
    }

    @Override
    public void onClick() {
        super.onClick();
        Snapshot s = controller != null ? controller.snapshot() : null;
        Snapshot.Status st = s == null ? Snapshot.Status.NO_DEVICE : s.status();
        boolean canConnect = st == Snapshot.Status.DISCONNECTED || st == Snapshot.Status.LINKED_NO_AUDIO;
        if (canConnect && MonitorService.startConnect(this)) {
            return;
        }
        openApp(canConnect);
    }

    private void openApp(boolean connect) {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (connect) {
            i.putExtra(MainActivity.EXTRA_CONNECT, true);
        }
        startActivityAndCollapse(i);
    }
}
