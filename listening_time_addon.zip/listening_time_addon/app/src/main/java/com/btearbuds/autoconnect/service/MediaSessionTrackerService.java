package com.btearbuds.autoconnect.service;

import android.content.ComponentName;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaSessionManager;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.service.notification.NotificationListenerService;

import com.btearbuds.autoconnect.data.ListeningTimeStore;

import java.util.List;

/**
 * Optional Notification Access service. Estimates playback time while Android reports a media
 * session PLAYING and an output classified as Bluetooth audio is present. Does not read or store
 * notification text, titles, artists, or media metadata.
 *
 * Important limitation: public APIs cannot reliably prove that the Bluetooth output belongs to
 * the user's selected earbuds or that sound was audible. This is an estimate, not a hearing-dose
 * or physical-listening measurement.
 */
public final class MediaSessionTrackerService extends NotificationListenerService {
    private static final long SAMPLE_INTERVAL_MS = 1000L;
    private static final long MAX_SAMPLE_DELTA_MS = 2000L;
    private static final long SAVE_INTERVAL_MS = 10000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean listenerConnected;
    private boolean countedOnPreviousSample;
    private long previousSampleElapsed;
    private long previousSampleWallTime;
    private long pendingMillis;
    private long pendingDayWallTime;
    private long lastSaveElapsed;

    private final Runnable sampler = new Runnable() {
        @Override public void run() {
            if (!listenerConnected) return;
            try {
                sampleOnce();
            } catch (RuntimeException ignored) {
                // OEM media/Bluetooth services can temporarily fail. Do not crash the listener.
                countedOnPreviousSample = false;
                previousSampleElapsed = 0L;
            } finally {
                if (listenerConnected) handler.postDelayed(this, SAMPLE_INTERVAL_MS);
            }
        }
    };

    @Override public void onListenerConnected() {
        super.onListenerConnected();
        listenerConnected = true;
        countedOnPreviousSample = false;
        previousSampleElapsed = 0L;
        lastSaveElapsed = SystemClock.elapsedRealtime();
        handler.removeCallbacks(sampler);
        handler.post(sampler);
    }

    @Override public void onListenerDisconnected() {
        listenerConnected = false;
        handler.removeCallbacks(sampler);
        flushPending();
        resetSamplingState();
        super.onListenerDisconnected();
    }

    @Override public void onDestroy() {
        listenerConnected = false;
        handler.removeCallbacks(sampler);
        flushPending();
        resetSamplingState();
        super.onDestroy();
    }

    private void sampleOnce() {
        final long nowElapsed = SystemClock.elapsedRealtime();
        final long nowWall = System.currentTimeMillis();
        final boolean shouldCount = hasPlayingMediaSession() && hasBluetoothMediaOutput();

        // Only count an interval if both samples say playing + Bluetooth output. Use elapsed time
        // (not wall time) so clock changes do not create fake duration. A cap limits gaps if the
        // phone is dozing or the listener was temporarily delayed.
        if (countedOnPreviousSample && shouldCount && previousSampleElapsed > 0L) {
            long delta = nowElapsed - previousSampleElapsed;
            if (delta > 0L && delta <= MAX_SAMPLE_DELTA_MS) {
                addPending(previousSampleWallTime, delta);
            }
        }

        countedOnPreviousSample = shouldCount;
        previousSampleElapsed = nowElapsed;
        previousSampleWallTime = nowWall;

        if (pendingMillis >= SAVE_INTERVAL_MS || nowElapsed - lastSaveElapsed >= SAVE_INTERVAL_MS) {
            flushPending();
            lastSaveElapsed = nowElapsed;
        }
    }

    private void addPending(long sampleWallTime, long millis) {
        // Flush before changing days so a short interval around midnight is assigned to the day
        // in which that interval began, rather than whichever day happens to contain the flush.
        if (pendingMillis > 0L && !sameLocalDay(pendingDayWallTime, sampleWallTime)) {
            flushPending();
        }
        if (pendingMillis == 0L) pendingDayWallTime = sampleWallTime;
        pendingMillis += millis;
    }

    private boolean sameLocalDay(long a, long b) {
        java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
        return format.format(new java.util.Date(a)).equals(format.format(new java.util.Date(b)));
    }

    private boolean hasPlayingMediaSession() {
        try {
            MediaSessionManager manager =
                    (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
            if (manager == null) return false;
            ComponentName listener = new ComponentName(this, MediaSessionTrackerService.class);
            List<MediaController> controllers = manager.getActiveSessions(listener);
            if (controllers == null) return false;
            for (MediaController controller : controllers) {
                PlaybackState state = controller.getPlaybackState();
                if (state != null && state.getState() == PlaybackState.STATE_PLAYING) return true;
            }
        } catch (SecurityException ignored) {
            // Access may have been revoked while the service is alive.
        } catch (RuntimeException ignored) {
            // A media app/session can disappear while Android returns the active session list.
        }
        return false;
    }

    private boolean hasBluetoothMediaOutput() {
        try {
            AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioManager == null) return false;
            AudioDeviceInfo[] outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
            if (outputs == null) return false;
            for (AudioDeviceInfo output : outputs) {
                int type = output.getType();
                if (type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) return true;
                if (Build.VERSION.SDK_INT >= 31 &&
                        (type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                         type == AudioDeviceInfo.TYPE_BLE_SPEAKER)) return true;
            }
        } catch (RuntimeException ignored) {
            // If route data is unavailable, do not guess that listening is happening.
        }
        return false;
    }

    private void flushPending() {
        if (pendingMillis > 0L) {
            ListeningTimeStore.addMillisForDate(this, pendingDayWallTime, pendingMillis);
            pendingMillis = 0L;
            pendingDayWallTime = 0L;
        }
    }

    private void resetSamplingState() {
        countedOnPreviousSample = false;
        previousSampleElapsed = 0L;
        previousSampleWallTime = 0L;
    }
}
