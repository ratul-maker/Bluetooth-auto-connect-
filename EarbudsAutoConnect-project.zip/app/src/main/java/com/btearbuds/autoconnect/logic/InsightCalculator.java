package com.btearbuds.autoconnect.logic;

import java.util.ArrayList;
import java.util.List;

/**
 * Turns real stored battery readings into "sessions" and observed changes.
 *
 * Nothing here predicts anything: it only reports what was actually recorded.
 * A session is split when there is a long gap in readings or the level goes up
 * noticeably (charging).
 */
public final class InsightCalculator {

    public static final long SESSION_GAP_MS = 90L * 60L * 1000L;
    public static final long MIN_SPAN_MS = 10L * 60L * 1000L;
    public static final int CHARGE_JUMP = 5;

    private InsightCalculator() {
    }

    public static final class Point {
        public final long time;
        public final int level;

        public Point(long time, int level) {
            this.time = time;
            this.level = level;
        }
    }

    public static final class Session {
        public final List<Point> points = new ArrayList<Point>();

        public long startTime() {
            return points.get(0).time;
        }

        public long endTime() {
            return points.get(points.size() - 1).time;
        }

        public int startLevel() {
            return points.get(0).level;
        }

        public int endLevel() {
            return points.get(points.size() - 1).level;
        }

        public long spanMs() {
            return endTime() - startTime();
        }

        /** end level minus start level (negative = battery went down). */
        public int change() {
            return endLevel() - startLevel();
        }

        /** Enough real data to say something: at least 2 readings spanning 10+ minutes. */
        public boolean isSufficient() {
            return points.size() >= 2 && spanMs() >= MIN_SPAN_MS;
        }
    }

    /** @param sorted readings sorted by time ascending */
    public static List<Session> split(List<Point> sorted) {
        List<Session> out = new ArrayList<Session>();
        Session cur = null;
        Point prev = null;
        for (int i = 0; i < sorted.size(); i++) {
            Point p = sorted.get(i);
            boolean newSession = cur == null
                    || (p.time - prev.time) > SESSION_GAP_MS
                    || (p.level - prev.level) >= CHARGE_JUMP;
            if (newSession) {
                cur = new Session();
                out.add(cur);
            }
            cur.points.add(p);
            prev = p;
        }
        return out;
    }

    public static String formatDuration(long ms) {
        long minutes = ms / 60000L;
        if (minutes < 1) {
            return "under 1 min";
        }
        long h = minutes / 60;
        long m = minutes % 60;
        if (h == 0) {
            return m + " min";
        }
        if (m == 0) {
            return h + " h";
        }
        return h + " h " + m + " min";
    }
}
