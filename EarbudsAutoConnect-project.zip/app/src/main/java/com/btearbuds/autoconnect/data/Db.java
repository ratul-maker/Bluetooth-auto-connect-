package com.btearbuds.autoconnect.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Small local database: connection log, connection sessions, observation windows and (optional)
 * battery history. Rows are capped so storage can never grow without limit. Nothing leaves the
 * phone.
 *
 * A "session" is one connection of the chosen earbuds. A session records whether the app saw its
 * start and its end happen live ("exact") or not. An "observation window" is a period during which
 * the app was actually running and watching Bluetooth; everything outside the windows is time the
 * app could not observe.
 */
public final class Db extends SQLiteOpenHelper {

    private static final String NAME = "history.db";
    private static final int VERSION = 2;
    private static final int MAX_LOG_ROWS = 500;
    private static final int MAX_BATTERY_ROWS = 3000;
    private static final long MAX_BATTERY_AGE_MS = 60L * 24L * 60L * 60L * 1000L;
    private static final int MAX_SESSIONS = 500;

    public static final class LogRow {
        public final long time;
        public final String type;
        public final String detail;

        LogRow(long time, String type, String detail) {
            this.time = time;
            this.type = type;
            this.detail = detail;
        }
    }

    public static final class BatteryRow {
        public final long time;
        public final int level;
        public final String source;
        public final String kind;

        BatteryRow(long time, int level, String source, String kind) {
            this.time = time;
            this.level = level;
            this.source = source;
            this.kind = kind;
        }
    }

    public static final class SessionRow {
        public final long id;
        public final String name;
        public final String address;
        public final long start;
        /** 0 while the session is still open. */
        public final long end;
        public final boolean startExact;
        public final boolean endExact;
        public final long lastSeen;

        SessionRow(long id, String name, String address, long start, long end,
                   boolean startExact, boolean endExact, long lastSeen) {
            this.id = id;
            this.name = name;
            this.address = address;
            this.start = start;
            this.end = end;
            this.startExact = startExact;
            this.endExact = endExact;
            this.lastSeen = lastSeen;
        }
    }

    public static final class WindowRow {
        public final long start;
        /** 0 while the window is still open. */
        public final long end;

        WindowRow(long start, long end) {
            this.start = start;
            this.end = end;
        }
    }

    private static Db instance;

    public static synchronized Db get(Context context) {
        if (instance == null) {
            instance = new Db(context.getApplicationContext());
        }
        return instance;
    }

    private Db(Context context) {
        super(context, NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE conn_log (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "ts INTEGER NOT NULL, type TEXT NOT NULL, detail TEXT)");
        db.execSQL("CREATE TABLE battery (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "ts INTEGER NOT NULL, level INTEGER NOT NULL, source TEXT, kind TEXT)");
        createSessionTables(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // v1 -> v2: add the session tables. Existing log and battery rows are kept untouched.
            createSessionTables(db);
        }
    }

    private static void createSessionTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "name TEXT, address TEXT, start_ts INTEGER NOT NULL, end_ts INTEGER NOT NULL "
                + "DEFAULT 0, start_exact INTEGER NOT NULL DEFAULT 0, end_exact INTEGER NOT NULL "
                + "DEFAULT 0, last_seen INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE IF NOT EXISTS obs (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "start_ts INTEGER NOT NULL, end_ts INTEGER NOT NULL DEFAULT 0, "
                + "last_seen INTEGER NOT NULL DEFAULT 0)");
    }

    // ---- connection log
    public void addLog(String type, String detail) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues v = new ContentValues();
            v.put("ts", System.currentTimeMillis());
            v.put("type", type);
            v.put("detail", detail);
            db.insert("conn_log", null, v);
            db.execSQL("DELETE FROM conn_log WHERE id <= (SELECT MAX(id) FROM conn_log) - "
                    + MAX_LOG_ROWS);
        } catch (SQLiteException e) {
            // History is a convenience; never crash because of it.
        }
    }

    public List<LogRow> recentLogs(int limit) {
        List<LogRow> out = new ArrayList<LogRow>();
        Cursor c = null;
        try {
            c = getReadableDatabase().rawQuery(
                    "SELECT ts, type, detail FROM conn_log ORDER BY id DESC LIMIT " + limit, null);
            while (c.moveToNext()) {
                out.add(new LogRow(c.getLong(0), c.getString(1), c.getString(2)));
            }
        } catch (SQLiteException e) {
            // return what we have
        } finally {
            if (c != null) {
                c.close();
            }
        }
        return out;
    }

    public void clearLogs() {
        try {
            getWritableDatabase().execSQL("DELETE FROM conn_log");
        } catch (SQLiteException e) {
            // ignore
        }
    }

    // ---- battery history
    public void addBattery(long time, int level, String source, String kind) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues v = new ContentValues();
            v.put("ts", time);
            v.put("level", level);
            v.put("source", source);
            v.put("kind", kind);
            db.insert("battery", null, v);
            db.execSQL("DELETE FROM battery WHERE id <= (SELECT MAX(id) FROM battery) - "
                    + MAX_BATTERY_ROWS);
            db.execSQL("DELETE FROM battery WHERE ts < " + (time - MAX_BATTERY_AGE_MS));
        } catch (SQLiteException e) {
            // ignore
        }
    }

    public List<BatteryRow> batterySince(long sinceTime) {
        List<BatteryRow> out = new ArrayList<BatteryRow>();
        Cursor c = null;
        try {
            c = getReadableDatabase().rawQuery(
                    "SELECT ts, level, source, kind FROM battery WHERE ts >= " + sinceTime
                            + " ORDER BY ts ASC", null);
            while (c.moveToNext()) {
                out.add(new BatteryRow(c.getLong(0), c.getInt(1), c.getString(2), c.getString(3)));
            }
        } catch (SQLiteException e) {
            // return what we have
        } finally {
            if (c != null) {
                c.close();
            }
        }
        return out;
    }

    public void clearBattery() {
        try {
            getWritableDatabase().execSQL("DELETE FROM battery");
        } catch (SQLiteException e) {
            // ignore
        }
    }

    // ---- connection sessions

    /** @return the new session's id, or -1 if it could not be stored. */
    public long openSession(String name, String address, long start, boolean startExact) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues v = new ContentValues();
            v.put("name", name);
            v.put("address", address);
            v.put("start_ts", start);
            v.put("end_ts", 0L);
            v.put("start_exact", startExact ? 1 : 0);
            v.put("end_exact", 0);
            v.put("last_seen", start);
            long id = db.insert("sessions", null, v);
            db.execSQL("DELETE FROM sessions WHERE id <= (SELECT MAX(id) FROM sessions) - "
                    + MAX_SESSIONS);
            db.execSQL("DELETE FROM obs WHERE end_ts > 0 AND end_ts < "
                    + "(SELECT COALESCE(MIN(start_ts), 0) FROM sessions)");
            return id;
        } catch (SQLiteException e) {
            return -1L;
        }
    }

    /** Ends a session. endExact is true only if the app saw the disconnect happen. */
    public void closeSession(long id, long end, boolean endExact) {
        if (id <= 0L) {
            return;
        }
        try {
            ContentValues v = new ContentValues();
            v.put("end_ts", end);
            v.put("end_exact", endExact ? 1 : 0);
            v.put("last_seen", end);
            getWritableDatabase().update("sessions", v, "id = ? AND end_ts = 0",
                    new String[]{String.valueOf(id)});
        } catch (SQLiteException e) {
            // ignore
        }
    }

    /** "I just confirmed this session is still going." Used as a coarse heartbeat. */
    public void touchSession(long id, long now) {
        if (id <= 0L) {
            return;
        }
        try {
            getWritableDatabase().execSQL("UPDATE sessions SET last_seen = ? WHERE id = ? AND "
                    + "end_ts = 0", new Object[]{Long.valueOf(now), Long.valueOf(id)});
        } catch (SQLiteException e) {
            // ignore
        }
    }

    /** Newest first. */
    public List<SessionRow> recentSessions(int limit) {
        List<SessionRow> out = new ArrayList<SessionRow>();
        Cursor c = null;
        try {
            c = getReadableDatabase().rawQuery("SELECT id, name, address, start_ts, end_ts, "
                    + "start_exact, end_exact, last_seen FROM sessions ORDER BY start_ts DESC, "
                    + "id DESC LIMIT " + limit, null);
            while (c.moveToNext()) {
                out.add(new SessionRow(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3),
                        c.getLong(4), c.getInt(5) == 1, c.getInt(6) == 1, c.getLong(7)));
            }
        } catch (SQLiteException e) {
            // return what we have
        } finally {
            if (c != null) {
                c.close();
            }
        }
        return out;
    }

    /** Deletes finished sessions and the observation windows they needed. Open ones are kept. */
    public void clearSessions() {
        try {
            SQLiteDatabase db = getWritableDatabase();
            db.execSQL("DELETE FROM sessions WHERE end_ts > 0");
            db.execSQL("DELETE FROM obs WHERE end_ts > 0");
        } catch (SQLiteException e) {
            // ignore
        }
    }

    // ---- observation windows (when the app was really watching)

    /** @return the new window's id, or -1. */
    public long openWindow(long start) {
        try {
            ContentValues v = new ContentValues();
            v.put("start_ts", start);
            v.put("end_ts", 0L);
            v.put("last_seen", start);
            return getWritableDatabase().insert("obs", null, v);
        } catch (SQLiteException e) {
            return -1L;
        }
    }

    public void closeWindow(long id, long end) {
        if (id <= 0L) {
            return;
        }
        try {
            ContentValues v = new ContentValues();
            v.put("end_ts", end);
            v.put("last_seen", end);
            getWritableDatabase().update("obs", v, "id = ? AND end_ts = 0",
                    new String[]{String.valueOf(id)});
        } catch (SQLiteException e) {
            // ignore
        }
    }

    public void touchWindow(long id, long now) {
        if (id <= 0L) {
            return;
        }
        try {
            getWritableDatabase().execSQL("UPDATE obs SET last_seen = ? WHERE id = ? AND "
                    + "end_ts = 0", new Object[]{Long.valueOf(now), Long.valueOf(id)});
        } catch (SQLiteException e) {
            // ignore
        }
    }

    public List<WindowRow> windowsSince(long since) {
        List<WindowRow> out = new ArrayList<WindowRow>();
        Cursor c = null;
        try {
            c = getReadableDatabase().rawQuery("SELECT start_ts, end_ts FROM obs WHERE end_ts = 0 "
                    + "OR end_ts >= " + since + " ORDER BY start_ts ASC", null);
            while (c.moveToNext()) {
                out.add(new WindowRow(c.getLong(0), c.getLong(1)));
            }
        } catch (SQLiteException e) {
            // return what we have
        } finally {
            if (c != null) {
                c.close();
            }
        }
        return out;
    }

    /**
     * Run once when the app starts watching. Anything still "open" belongs to an earlier run that
     * ended without closing properly (process killed, phone restarted, battery died). Such rows are
     * closed at the last moment the app confirmed they were alive, and marked as not exact. Nothing
     * after that moment is claimed.
     */
    public void recoverStale() {
        try {
            SQLiteDatabase db = getWritableDatabase();
            db.execSQL("UPDATE sessions SET end_ts = MAX(last_seen, start_ts), end_exact = 0 "
                    + "WHERE end_ts = 0");
            db.execSQL("UPDATE obs SET end_ts = MAX(last_seen, start_ts) WHERE end_ts = 0");
        } catch (SQLiteException e) {
            // ignore
        }
    }
}
