package com.btearbuds.autoconnect;

import android.app.Application;

import com.btearbuds.autoconnect.service.Notifs;

public final class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Notifs.ensureChannels(this);
    }
}
