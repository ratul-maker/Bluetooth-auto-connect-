package com.btearbuds.autoconnect.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Stores estimated daily Bluetooth-media listening time locally on this phone. */
public final class ListeningTimeStore {
    private static final String PREFS = "listening_time_v1";
    private static final String DAY_PREFIX = "day_";
    private static final long DAY_LIMIT_MS = 24L * 60L * 60L * 1000L;

    private ListeningTimeStore() { }

    /** Adds duration to the local calendar day containing sampleWallTimeMillis. */
    public static void addMillisForDate(Context context, long sampleWallTimeMillis, long millis) {
        if (context == null || millis <= 0L) return;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String key = DAY_PREFIX + dayKey(sampleWallTimeMillis);
        long oldValue = Math.max(0L, prefs.getLong(key, 0L));
        long addition = Math.min(millis, DAY_LIMIT_MS);
        long newValue = oldValue > DAY_LIMIT_MS - addition ? DAY_LIMIT_MS : oldValue + addition;
        prefs.edit().putLong(key, newValue).apply();
    }

    /** Convenience method for adding time to today's local calendar day. */
    public static void addMillis(Context context, long millis) {
        addMillisForDate(context, System.currentTimeMillis(), millis);
    }

    public static long getTodayMillis(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return Math.max(0L, prefs.getLong(DAY_PREFIX + dayKey(System.currentTimeMillis()), 0L));
    }

    /** Returns today and previous days, newest first, including days with zero minutes. */
    public static List<DayTotal> getLastDays(Context context, int count) {
        int safeCount = Math.max(1, Math.min(count, 365));
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        List<DayTotal> result = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        for (int i = 0; i < safeCount; i++) {
            String key = dayKey(calendar.getTimeInMillis());
            result.add(new DayTotal(key, Math.max(0L, prefs.getLong(DAY_PREFIX + key, 0L))));
            calendar.add(Calendar.DAY_OF_YEAR, -1);
        }
        return result;
    }

    private static String dayKey(long millis) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(millis));
    }

    public static final class DayTotal {
        public final String date;
        public final long millis;

        public DayTotal(String date, long millis) {
            this.date = date;
            this.millis = millis;
        }
    }
}
