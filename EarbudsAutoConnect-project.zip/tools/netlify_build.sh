#!/usr/bin/env bash
# Best-effort: builds the APK inside Netlify's build container and publishes it as a download.
# Netlify normally hosts websites, not Android builds, so this downloads a JDK and the Android SDK
# first. If it fails, use the GitHub Actions workflow instead (.github/workflows/build-apk.yml).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="${HOME}/.btbuild"
mkdir -p "$WORK"
cd "$WORK"

if [ ! -x "$WORK/jdk17/bin/java" ]; then
  echo "Downloading JDK 17..."
  curl -fsSL -o jdk17.tar.gz "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse"
  mkdir -p jdk17
  tar -xzf jdk17.tar.gz -C jdk17 --strip-components=1
fi
export JAVA_HOME="$WORK/jdk17"
export PATH="$JAVA_HOME/bin:$PATH"

export ANDROID_HOME="$WORK/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
if [ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo "Downloading Android command-line tools..."
  mkdir -p "$ANDROID_HOME/cmdline-tools"
  curl -fsSL -o cmdtools.zip "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
  unzip -q -o cmdtools.zip -d "$ANDROID_HOME/cmdline-tools"
  rm -rf "$ANDROID_HOME/cmdline-tools/latest"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
fi
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKM" --licenses > /dev/null 2>&1 || true
"$SDKM" "platforms;android-34" "build-tools;34.0.0"

cd "$ROOT"
chmod +x gradlew
./gradlew --no-daemon assembleRelease

APK="app/build/outputs/apk/release/app-release.apk"
test -f "$APK"
mkdir -p public
cp "$APK" public/EarbudsAutoConnect.apk
ls -l public/EarbudsAutoConnect.apk
