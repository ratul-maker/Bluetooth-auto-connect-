package com.btearbuds.autoconnect.service;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import com.btearbuds.autoconnect.bt.BtController;
import com.btearbuds.autoconnect.bt.Snapshot;
import com.btearbuds.autoconnect.data.Prefs;

/**
 * Optional background monitoring. A foreground service (with a visible notification) keeps the
 * app's process alive so Bluetooth events keep arriving while the screen is off. It does no
 * polling: it only reacts to events from {@link BtController}.
 *
 * Android or the phone maker (XOS) may still stop it; see the Settings screen for guidance.
 */
public final class MonitorService extends Service implements BtController.Listener {

    public static final String ACTION_START = "com.btearbuds.autoconnect.START";
    public static final String ACTION_CONNECT = "com.btearbuds.autoconnect.CONNECT";
    public static final String ACTION_STOP = "com.btearbuds.autoconnect.STOP";

    private static final long ONE_SHOT_MAX_MS = 45000L;
    private static final long ONE_SHOT_AFTER_CONNECT_MS = 4000L;
    private static final long NOTIFY_DEBOUNCE_MS = 1000L;

    /** True while this service instance exists in this process. */
    public static volatile boolean running;

    private final Handler h = new Handler(Looper.getMainLooper());
    private BtController controller;
    private Prefs prefs;
    private NotificationManager nm;
    private boolean holding;
    private boolean oneShot;
    private String lastKey;

    public static void start(Context ctx) {
        try {
            Intent i = new Intent(ctx, MonitorService.class);
            i.setAction(ACTION_START);
            ctx.startForegroundService(i);
        } catch (RuntimeException e) {
            // Android refused to start a foreground service from the background. Nothing to do.
        }
    }

    /** @return false if Android refused to start the service (caller can open the app instead). */
    public static boolean startConnect(Context ctx) {
        try {
            Intent i = new Intent(ctx, MonitorService.class);
            i.setAction(ACTION_CONNECT);
            ctx.startForegroundService(i);
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static void stop(Context ctx) {
        try {
            ctx.stopService(new Intent(ctx, MonitorService.class));
        } catch (RuntimeException e) {
            // ignore
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        Notifs.ensureChannels(this);
        prefs = new Prefs(this);
        controller = BtController.get(this);
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Android requires startForeground() soon after startForegroundService(), every time.
        startForeground(Notifs.ID_MONITOR, Notifs.placeholder(this));
        lastKey = null;

        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            prefs.setMonitoring(false);
            shutDown();
            return START_NOT_STICKY;
        }
        if (ACTION_CONNECT.equals(action)) {
            if (!prefs.monitoring()) {
                oneShot = true;
                h.removeCallbacks(oneShotStop);
                h.postDelayed(oneShotStop, ONE_SHOT_MAX_MS);
            }
            ensureHolding();
            controller.connectNow();
            return oneShot ? START_NOT_STICKY : START_STICKY;
        }
        // ACTION_START, or a restart by Android after the process was killed (null intent).
        if (!prefs.monitoring()) {
            shutDown();
            return START_NOT_STICKY;
        }
        oneShot = false;
        h.removeCallbacks(oneShotStop);
        ensureHolding();
        return START_STICKY;
    }

    private void ensureHolding() {
        if (!holding) {
            holding = true;
            controller.addListener(this);
            controller.acquire(true);
        }
        updateNotificationNow();
    }

    private final Runnable oneShotStop = new Runnable() {
        @Override
        public void run() {
            if (oneShot) {
                shutDown();
            }
        }
    };

    private final Runnable notifyRunnable = new Runnable() {
        @Override
        public void run() {
            updateNotificationNow();
        }
    };

    @Override
    public void onSnapshot(Snapshot s) {
        if (oneShot && s.status() == Snapshot.Status.CONNECTED) {
            h.removeCallbacks(oneShotStop);
            h.postDelayed(oneShotStop, ONE_SHOT_AFTER_CONNECT_MS);
        }
        h.removeCallbacks(notifyRunnable);
        h.postDelayed(notifyRunnable, NOTIFY_DEBOUNCE_MS);
    }

    private void updateNotificationNow() {
        if (!holding || nm == null) {
            return;
        }
        Snapshot s = controller.snapshot();
        String key = Notifs.monitorTitle(s) + "|" + Notifs.monitorText(s) + "|" + s.isConnected()
                + "|" + s.adapterOn + "|" + oneShot;
        if (key.equals(lastKey)) {
            return;
        }
        lastKey = key;
        nm.notify(Notifs.ID_MONITOR, Notifs.monitorNotification(this, s, oneShot));
    }

    private void releaseController() {
        if (holding) {
            holding = false;
            controller.removeListener(this);
            controller.release(true);
        }
    }

    private void shutDown() {
        h.removeCallbacksAndMessages(null);
        releaseController();
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        releaseController();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
