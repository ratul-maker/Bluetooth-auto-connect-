# Earbuds Auto-Connect  (v2.1 - Bluetooth Intelligence)

A small, offline Android app (plain Java, **no third-party libraries**) that looks after one
pair of already-paired Bluetooth earbuds: a live dashboard, honest battery readings, connection
history, home-screen widgets, reconnect attempts, alerts, diagnostics and a treble adjuster.

- Built for **Android 11 (API 30)**, installs on Android 8.0+ (`minSdk 26`, `targetSdk 30`)
- Needs only: Bluetooth, foreground service, run-at-startup, and (Treble Lab only) change audio settings.
  **No internet, location, microphone, contacts or notification permission.**
- No account, ads, analytics or server. Everything is stored on the phone.
- No volume, mute, playback, track-info or noise-cancelling controls - by design.

## What is new in v2.1
- **Listening time** - how long Android reported audio **streaming to your earbuds**: a live
  "streaming now" indicator with a small equalizer animation, *today* and *this connection* totals on the
  dashboard, per-day totals for the last 7 days and a "Listened" line on each connection in History.
  It uses Android's own Bluetooth music-stream state (`BluetoothA2dp` playing state), so it needs no new
  permission and no polling. **Honest limits:** it counts *any* sound sent to the earbuds (music,
  video, games), not only music, and cannot tell which app made it; it counts only time the app was
  watching; a stream that was already running when the app started, or still running when the app
  stopped watching, makes the total "at least" (shown as "at least" / "+"). Nothing is estimated.
- **"Made by RATUL" line** under the app name. It is checked against the phone's fonts first; if the
  phone cannot draw the special letters it shows plain "Made by RATUL" instead of empty boxes.
- **More futuristic effects** (decoration only, nothing about your earbuds): a faint HUD grid with slowly
  rising motes and a soft scan line behind the dashboard, a light sweep across the credit line, neon
  glow on the title and timer, cards that rise in when the dashboard opens, and buttons that dip when
  pressed. All of it stops when the dashboard is not in front, and is off when Android's animations
  are off (for example in Battery Saver).

## What was new in v2
- **Live dashboard** - true-black AMOLED look, cyan accents, violet highlights. Glowing status orb, a
  connection timer that ticks every second **only while the dashboard is visible**, the exact
  connected-since time (to the second), and a battery ring that appears only when the earbuds
  really report a level ("not reported" otherwise - never a made-up number).
- **Home-screen widgets** - *Earbuds - compact* and *Earbuds - expanded* (device name, status, battery,
  connected-since, running timer). Real `AppWidgetProvider` widgets using `RemoteViews`; the timer is a
  system Chronometer; Android's 30-minute minimum refresh; no alarms or polling.
- **Treble Lab** - dial + slider (-12 to +12 dB, limited to what the phone's equalizer supports),
  presets Neutral / Warm / Balanced / Bright / Custom, via `android.media.audiofx.Equalizer`. Reports what
  Android *accepted* (read back), never claims it is audible. Separate from Bluetooth tracking.
- **Connection history** - sessions with start, end and duration, kept across restarts, with
  *recorded* vs *partly seen* vs *not observed* made explicit.

## How honesty is enforced
| Situation | What the app shows |
|---|---|
| Earbuds already connected when the app starts watching | Start time marked "first seen"; timer labelled "seen connected for" |
| App stopped watching while connected | Session end marked "last seen"; duration "at least ..." |
| App killed / phone restarted | Open sessions are closed at the last heartbeat (every 5 min) and marked partly seen |
| Time between sessions | Split into "watched, nothing connected" and "not observed" using stored watching windows |
| Widget while the app is not watching | "Last known", no running timer, no battery number |
| Battery not reported by the earbuds | Dashed empty ring and "not reported" |
| Treble rejected / no equalizer | "Not applied" / "Unavailable on this phone" - never "on" |

## Get the APK (this project does not contain a pre-built APK)

An APK has to be compiled with the Android SDK. Pick one route:

### A. GitHub Actions (recommended, free, reliable)
1. Create a **private** GitHub repository and upload everything in this folder (keep the folder structure,
   including `.github/workflows/build-apk.yml`).
2. Open the repo's **Actions** tab. The *Build APK* workflow runs on every push (or press *Run workflow*).
3. When it turns green, open the repo's **Releases** page on your phone and tap `EarbudsAutoConnect.apk`.
   (The same file is also under the run's *Artifacts*.)

### B. Phone-only, no folder upload (one file + one pasted workflow)
1. Create a private GitHub repo. Upload the single file `EarbudsAutoConnect-project.zip`.
2. *Add file -> Create new file*, name it `.github/workflows/build-from-zip.yml`, paste the contents of
   `phone-only/build-from-zip.yml`, and commit.
3. *Actions -> Build APK from zip -> Run workflow*. Download from *Releases* as above.

### C. Netlify (best effort, untested)
Netlify normally hosts websites; it does not build Android apps. `netlify.toml` + `tools/netlify_build.sh`
try to download a JDK and the Android SDK inside Netlify's build container, build the APK, and publish it
next to `public/index.html` as a download page. If that build fails, use A or B.

### D. Android Studio
Open the folder, *Build -> Build APK(s)* (release is already configured to sign with the bundled key).

## Install
Open the downloaded `.apk` on the phone, allow "install unknown apps" for your browser/Files app if asked,
tap Install. Then *Choose earbuds* and pick the already-paired earbuds.

**Updating:** the GitHub workflow used for this project creates a *new* signing key for every build, so
Android will not install a newer build over an older one ("App not installed"). Uninstall the old app
first (its settings and history are removed with it), then install the new one.
`signing/btearbuds-release.jks` is only used by Android Studio builds (route D). Do not publish this app
to a store with that key.

## What it does (and honestly cannot do)
| Feature | Reality on Android 11, non-rooted |
|---|---|
| Choose earbuds | Lists only already-paired devices; never scans or pairs |
| Connection status | Read from Android's A2DP (music) and hands-free (calls) state, never assumed |
| Reconnect | Android has **no public API to start a headset connection**. "Connect now"/Auto-Connect send a best-effort Bluetooth LE request, then **verify the real state**. Classic-only earbuds: the app says it can't and just waits |
| Retries | At most 4 automatic tries (20 s, 1 min, 3 min, 10 min), then pauses until something changes or you tap Connect now |
| Disconnect | Not possible via public API - not offered |
| Battery | One value, **only if the earbuds report it** (Android's system report, headset +IPHONEACCEV report in 10% steps, or the standard BLE battery service when exactly one exists). Otherwise: "Battery information unavailable for this device" |
| Left / right / case battery | Not available through public APIs - never shown, never guessed |
| Alerts | One alert per low episode, re-armed only after recovery; never on missing data |
| History | Optional, real readings only, no playtime prediction |
| Background | Foreground service + notification (Connect now / Open app / Stop). XOS/Android may still pause apps - see Settings > Keep it running |
| Tile | "Earbuds" Quick Settings tile showing real state |
| Widgets | Updated by the app only while it is running (app open or Background Monitoring on). Otherwise they say "last known" |
| Listening time | Android's A2DP stream state for the chosen earbuds. Counts any audio (not just music), cannot tell which app, counts only while the app is watching, and is shown as "at least" when a start or end was not seen |
| Treble | Equalizer effect on the main output and on music apps that announce their audio session. Some phones/apps ignore it; the app can't hear the result |

## Testing status (read this)
**Verified in the build environment**
- All 128 classes compile with `javac` against the real Android API 34 and API 30 `android.jar` (0 errors).
- 169 plain-Java checks of the pure logic pass (`tools/run_logic_tests.sh`): retry schedule, alert
  de-duplication, vendor battery parsing, history sessions, duration formatting, session/gap timeline,
  widget honesty rules, treble range and band maths, listening-time totals (overlaps, open spans,
  "at least" flags, midnight edges).
- `tools/check_resources.py`: all XML well formed, every `@resource` and `R.x.y` reference exists,
  every XML attribute name exists in the Android framework, widget layouts use only views allowed in
  `RemoteViews`, manifest classes exist, no INTERNET permission.
- The history database commands, including the v2 -> v3 upgrade that adds the listening table, run
  correctly in SQLite (23 checks).

**NOT verified (could not be, here)**
- Resource compilation by AAPT2 and the APK build happen only on GitHub (see the Actions run log).
- Any run on a phone or emulator: how screens, animations and widgets look and behave, battery
  availability on your earbuds, Bluetooth events, background survival on XOS, whether Treble is
  audible on your phone, whether your phone's stream state flips promptly when you pause, and whether
  the "Made by RATUL" letters draw on your phone's font.
Treat the first install as a test and use *Diagnostics -> Copy report* if something looks wrong.

## Layout
`app/src/main/java/com/btearbuds/autoconnect/`
- `bt/` Bluetooth: `BtController` (the only place that talks to Android Bluetooth), `GattProbe`, `AudioRoute`, `Compat`, `Diagnostics`, `StatusText`
- `logic/` pure Java rules with tests: `RetryPolicy`, `BatteryAlertEngine`, `VendorBatteryParser`, `InsightCalculator`, `DurationFormat`, `SessionTimeline`, `ListenStats`, `WidgetModel`
- `treble/` Treble Lab: `TrebleMath` (pure), `TrebleEngine`, `TrebleService`, `TreblePrefs`
- `widget/` home-screen widgets: two providers, `WidgetUpdater`, `WidgetRenderer`, `WidgetState`
- `service/` monitoring foreground service, notifications, boot receiver, Quick Settings tile
- `data/` local settings and SQLite history (connection log, sessions, watching windows, listening spans, battery)
- `ui/` screens built in code (dashboard, history, Treble Lab, settings...) plus custom views:
  `StatusOrbView`, `BatteryRingView`, `TrebleDialView`, `EqBarsView`, `ShimmerTextView`, `AmbientBackdropView`. Only the two widget layouts are XML.
