package com.btearbuds.autoconnect.widget;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.bt.StatusText;
import com.btearbuds.autoconnect.logic.WidgetModel;
import com.btearbuds.autoconnect.ui.MainActivity;

/**
 * Turns a {@link WidgetModel} into RemoteViews. Only views that Android allows inside widgets are
 * used. The running timer is a system Chronometer, so it ticks by itself without the app waking up.
 */
final class WidgetRenderer {

    private WidgetRenderer() {
    }

    // ------------------------------------------------------------------ compact

    static RemoteViews compact(Context ctx, WidgetModel m) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_compact);
        v.setOnClickPendingIntent(R.id.w_root, openApp(ctx));
        v.setImageViewResource(R.id.w_dot, dotFor(m));
        v.setContentDescription(R.id.w_dot, "Status: " + statusWord(m));
        v.setTextViewText(R.id.w_name, nameOf(m));

        String line;
        if (m.mode == WidgetModel.Mode.NO_DEVICE) {
            line = "Tap to choose your earbuds";
        } else if (m.mode == WidgetModel.Mode.LAST_KNOWN) {
            line = "Not watching · last seen " + StatusText.clock(ctx, m.updatedAt);
        } else if (m.showSince()) {
            line = m.statusLabel + " · " + (m.sinceExact ? "since " : "first seen ")
                    + timeOnlyIfToday(ctx, m.connectedSince);
        } else {
            line = m.statusLabel;
        }
        v.setTextViewText(R.id.w_line, line);

        bindBattery(ctx, v, m, R.id.w_battery, 15f, 12f, false);
        bindTimer(v, m, R.id.w_timer, R.id.w_timer_off);
        return v;
    }

    // ------------------------------------------------------------------ expanded

    static RemoteViews expanded(Context ctx, WidgetModel m) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_expanded);
        v.setOnClickPendingIntent(R.id.w_root, openApp(ctx));
        v.setImageViewResource(R.id.w_dot, dotFor(m));
        v.setContentDescription(R.id.w_dot, "Status: " + statusWord(m));
        v.setTextViewText(R.id.w_name, nameOf(m));

        // status chip
        String status;
        int statusColor;
        if (m.mode == WidgetModel.Mode.LAST_KNOWN) {
            status = "Not watching";
            statusColor = ctx.getColor(R.color.text_dim);
        } else {
            status = m.statusLabel;
            statusColor = toneColor(ctx, m.tone);
        }
        v.setTextViewText(R.id.w_status, status);
        v.setTextColor(R.id.w_status, statusColor);

        // timer + since
        v.setTextViewText(R.id.w_timer_label, m.showElapsed() ? "CONNECTED FOR" : "ELAPSED TIME");
        bindTimer(v, m, R.id.w_timer, R.id.w_timer_off);

        String since;
        if (m.mode == WidgetModel.Mode.NO_DEVICE) {
            since = "Open the app and choose your earbuds.";
        } else if (m.mode == WidgetModel.Mode.LIVE && m.showSince()) {
            since = (m.sinceExact ? "Connected since " : "First seen at ")
                    + StatusText.whenExact(ctx, m.connectedSince);
        } else if (m.mode == WidgetModel.Mode.LAST_KNOWN) {
            since = m.showSince()
                    ? "Last known: connected since " + StatusText.whenExact(ctx, m.connectedSince)
                    : "Last known: " + m.statusLabel;
        } else {
            since = m.connected ? "Start time unknown" : "Connected-since: none";
        }
        v.setTextViewText(R.id.w_since, since);

        // battery
        if (m.mode == WidgetModel.Mode.NO_DEVICE) {
            v.setViewVisibility(R.id.w_battery_label, View.INVISIBLE);
        } else {
            v.setViewVisibility(R.id.w_battery_label, View.VISIBLE);
        }
        bindBattery(ctx, v, m, R.id.w_battery, 22f, 14f, true);
        if (m.showBattery() && m.batteryPercent >= 0) {
            v.setViewVisibility(R.id.w_bar, View.VISIBLE);
            v.setProgressBar(R.id.w_bar, 100, m.batteryPercent, false);
        } else {
            v.setViewVisibility(R.id.w_bar, View.GONE);
        }

        // footer
        String footer;
        if (m.mode == WidgetModel.Mode.LIVE) {
            footer = "Watching · updates when Bluetooth changes";
        } else if (m.mode == WidgetModel.Mode.LAST_KNOWN) {
            footer = "App wasn't watching · last seen " + StatusText.when(ctx, m.updatedAt);
        } else {
            footer = "";
        }
        v.setTextViewText(R.id.w_footer, footer);
        return v;
    }

    // ------------------------------------------------------------------ shared pieces

    private static void bindTimer(RemoteViews v, WidgetModel m, int timerId, int offId) {
        if (m.showElapsed()) {
            long elapsed = Math.max(0L, System.currentTimeMillis() - m.connectedSince);
            long base = SystemClock.elapsedRealtime() - elapsed;
            v.setChronometer(timerId, base, null, true);
            v.setViewVisibility(timerId, View.VISIBLE);
            v.setViewVisibility(offId, View.GONE);
        } else {
            v.setChronometer(timerId, SystemClock.elapsedRealtime(), null, false);
            v.setViewVisibility(timerId, View.GONE);
            v.setViewVisibility(offId,
                    m.mode == WidgetModel.Mode.NO_DEVICE ? View.GONE : View.VISIBLE);
        }
    }

    private static void bindBattery(Context ctx, RemoteViews v, WidgetModel m, int id,
                                    float bigSp, float smallSp, boolean showPlaceholder) {
        String text = m.batteryText();
        if (text.length() == 0 && !showPlaceholder) {
            v.setViewVisibility(id, View.GONE);
            return;
        }
        v.setViewVisibility(id, View.VISIBLE);
        v.setTextViewText(id, text);
        boolean real = m.showBattery();
        v.setTextColor(id, ctx.getColor(real ? R.color.accent : R.color.text_dim));
        boolean shortText = real && m.batteryPercent >= 0;
        v.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, shortText ? bigSp : smallSp);
    }

    private static String nameOf(WidgetModel m) {
        return m.name != null && m.name.length() > 0 ? m.name : "Earbuds Auto-Connect";
    }

    private static String statusWord(WidgetModel m) {
        return m.mode == WidgetModel.Mode.LAST_KNOWN ? "not watching" : m.statusLabel;
    }

    private static int dotFor(WidgetModel m) {
        switch (m.tone) {
            case WidgetModel.TONE_OK:
                return R.drawable.widget_dot_ok;
            case WidgetModel.TONE_WARN:
                return R.drawable.widget_dot_warn;
            case WidgetModel.TONE_ERROR:
                return R.drawable.widget_dot_error;
            case WidgetModel.TONE_IDLE:
            default:
                return R.drawable.widget_dot_idle;
        }
    }

    private static int toneColor(Context ctx, int tone) {
        switch (tone) {
            case WidgetModel.TONE_OK:
                return ctx.getColor(R.color.ok);
            case WidgetModel.TONE_WARN:
                return ctx.getColor(R.color.warn);
            case WidgetModel.TONE_ERROR:
                return ctx.getColor(R.color.error);
            case WidgetModel.TONE_IDLE:
            default:
                return ctx.getColor(R.color.text_secondary);
        }
    }

    private static String timeOnlyIfToday(Context ctx, long millis) {
        String full = StatusText.whenExact(ctx, millis);
        return full.startsWith("Today ") ? full.substring(6) : full;
    }

    private static PendingIntent openApp(Context ctx) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(ctx, 20, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
