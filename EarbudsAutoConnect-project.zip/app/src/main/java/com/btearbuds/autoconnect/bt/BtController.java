package com.btearbuds.autoconnect.bt;

import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHeadset;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Looper;

import com.btearbuds.autoconnect.data.Db;
import com.btearbuds.autoconnect.data.Prefs;
import com.btearbuds.autoconnect.logic.BatteryAlertEngine;
import com.btearbuds.autoconnect.logic.RetryPolicy;
import com.btearbuds.autoconnect.logic.VendorBatteryParser;
import com.btearbuds.autoconnect.service.Notifs;
import com.btearbuds.autoconnect.widget.WidgetUpdater;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The single place that talks to Android Bluetooth.
 *
 * Everything runs on the main thread. The controller is "active" only while something holds it
 * (the monitoring service, a visible screen, or the Quick Settings tile) - when nobody holds it,
 * all receivers are unregistered and nothing runs.
 *
 * Honest limits (Android 11, no root, public APIs only):
 *  - There is no public API for an app to start an A2DP/headset connection. "Connect" therefore
 *    sends a Bluetooth LE connection request to dual-mode/LE devices and then VERIFIES the real
 *    profile state. For classic-only devices nothing can be requested and the user is told so.
 *  - There is no public API to disconnect a headset, so none is offered.
 *  - Success is only ever reported when Android's profile state says the headset is connected.
 */
public final class BtController {

    public interface Listener {
        void onSnapshot(Snapshot snapshot);
    }

    private static BtController instance;

    public static synchronized BtController get(Context context) {
        if (instance == null) {
            instance = new BtController(context.getApplicationContext());
        }
        return instance;
    }

    // Broadcast used by Android's Bluetooth stack for device battery changes. The constants are
    // not in the public SDK, so the strings are used directly. Only 0..100 is ever accepted.
    private static final String ACTION_BATTERY_LEVEL_CHANGED =
            "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED";
    private static final String EXTRA_BATTERY_LEVEL =
            "android.bluetooth.device.extra.BATTERY_LEVEL";
    private static final int APPLE_COMPANY_ID = 76;

    private static final long STARTUP_SETTLE_MS = 2500L;
    private static final long ADAPTER_ON_DELAY_MS = 5000L;
    private static final long PROFILE_GRACE_MS = 7000L;
    private static final long ATTEMPT_TIMEOUT_MS = 15000L;
    private static final long VERIFY_AFTER_LINK_MS = 8000L;
    private static final long BATTERY_PROBE_DELAY_MS = 20000L;
    private static final long BATTERY_PROBE_TIMEOUT_MS = 15000L;
    private static final long PROXY_WAIT_MS = 1200L;
    private static final long HISTORY_MIN_INTERVAL_MS = 10L * 60L * 1000L;
    /** How often the app re-confirms to the database that it is still watching (see recoverStale). */
    private static final long HEARTBEAT_MS = 5L * 60L * 1000L;

    /** True only while this process is actively watching Bluetooth. Widgets use it to avoid lying. */
    private static volatile boolean observing;

    public static boolean isObserving() {
        return observing;
    }

    private final Context app;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Prefs prefs;
    private final Db db;
    private final List<Listener> listeners = new CopyOnWriteArrayList<Listener>();
    private final BatteryAlertEngine alertEngine;

    private int acquireCount;
    private int activeCount;
    private boolean receiversRegistered;
    private boolean startupSettled;

    private BluetoothAdapter adapter;
    private boolean permissionOk = true;
    private boolean adapterOn;

    private BluetoothA2dp a2dp;
    private boolean a2dpUsable;
    private boolean a2dpRequested;
    private BluetoothHeadset hfp;
    private boolean hfpUsable;
    private boolean hfpRequested;

    private String prefAddress;
    private String prefName;

    private int a2dpState = BluetoothProfile.STATE_DISCONNECTED;
    private int hfpState = BluetoothProfile.STATE_DISCONNECTED;
    private int aclState = Snapshot.ACL_UNKNOWN;
    private long aclTime;
    private boolean linkedNoAudio;
    private boolean wasConnected;
    private long connectedSince;
    /** The app has seen the earbuds NOT connected since it started watching (so a start is real). */
    private boolean observedDisconnected;
    private boolean connectedSinceExact;
    private long openSessionId;
    private long openWindowId;
    /**
     * Android reports that audio is streaming to the earbuds (the Bluetooth A2DP stream is started).
     * This is "sound is flowing", not "music is playing": video and other sound count, and the app
     * cannot tell which app makes it.
     */
    private boolean a2dpPlaying;
    private long playingSince;
    private boolean playingSinceExact;
    private long openListenId;
    private boolean otherAudioConnected;
    private String otherAudioName;

    private boolean inFlight;
    private boolean classicNoted;
    private boolean attemptManual;
    private long attemptStart;
    private int failedAttempts;
    private boolean gaveUp;
    private boolean pending;
    private String pendingReason;
    private long nextAttemptAt;
    private String lastAttemptResult;
    private Boolean lastAttemptOk;
    private GattProbe attemptProbe;
    private GattProbe batteryProbe;
    private int batProbeState;

    private Integer batSingle;
    private Integer batLeft;
    private Integer batRight;
    private long batTime;
    private String batSource;
    private boolean batLive;
    private final Map<String, long[]> lastStored = new HashMap<String, long[]>();

    private BtController(Context appContext) {
        this.app = appContext;
        this.prefs = new Prefs(appContext);
        this.db = Db.get(appContext);
        this.alertEngine = new BatteryAlertEngine(prefs.alertedKeys());
    }

    // ------------------------------------------------------------------ lifecycle

    /**
     * @param active true for holders that are allowed to trigger automatic connection attempts
     *               (the monitoring service and the visible main screen). Passive holders (the
     *               device list, history, Quick Settings tile peeking) only observe.
     */
    public void acquire(boolean active) {
        acquireCount++;
        if (active) {
            activeCount++;
        }
        if (acquireCount == 1) {
            startUp();
        } else if (active && activeCount == 1) {
            onActiveStarted();
        }
    }

    public void release(boolean active) {
        if (acquireCount == 0) {
            return;
        }
        acquireCount--;
        if (active && activeCount > 0) {
            activeCount--;
        }
        if (acquireCount == 0) {
            activeCount = 0;
            shutDown();
        } else if (active && activeCount == 0) {
            cancelPendingAttempt();
            gaveUp = false;
            publish();
        }
    }

    private void onActiveStarted() {
        if (startupSettled && !isConnectedNow() && canAutoConnect() && !pending && !inFlight) {
            failedAttempts = 0;
            gaveUp = false;
            schedulePending("Monitoring started", 3000L);
        }
    }

    public void addListener(Listener l) {
        if (!listeners.contains(l)) {
            listeners.add(l);
        }
    }

    public void removeListener(Listener l) {
        listeners.remove(l);
    }

    private void startUp() {
        adapter = BtUtil.adapter(app);
        permissionOk = BtUtil.hasPermission(app);
        adapterOn = readAdapterOn();
        prefAddress = prefs.preferredAddress();
        prefName = prefs.preferredName();
        wasConnected = false;
        connectedSince = 0L;
        connectedSinceExact = false;
        observedDisconnected = false;
        openSessionId = 0L;
        openListenId = 0L;
        a2dpPlaying = false;
        playingSince = 0L;
        playingSinceExact = false;
        aclState = Snapshot.ACL_UNKNOWN;
        linkedNoAudio = false;
        a2dpState = BluetoothProfile.STATE_DISCONNECTED;
        hfpState = BluetoothProfile.STATE_DISCONNECTED;
        inFlight = false;
        pending = false;
        nextAttemptAt = 0L;
        failedAttempts = 0;
        gaveUp = false;
        classicNoted = false;
        batLive = false;
        batProbeState = 0;
        startupSettled = false;
        // Anything still open in the database is from an earlier run that ended abruptly.
        db.recoverStale();
        if (prefs.listenTrackingSince() == 0L) {
            prefs.setListenTrackingSince(System.currentTimeMillis());
        }
        openWindowId = db.openWindow(System.currentTimeMillis());
        observing = true;
        h.removeCallbacks(heartbeatRunnable);
        h.postDelayed(heartbeatRunnable, HEARTBEAT_MS);
        registerReceivers();
        ensureProxies();
        h.removeCallbacks(initialCheckRunnable);
        h.postDelayed(initialCheckRunnable, STARTUP_SETTLE_MS);
        publish();
    }

    private void shutDown() {
        long now = System.currentTimeMillis();
        h.removeCallbacks(heartbeatRunnable);
        // The app stops watching now. If the earbuds were connected, that connection may well
        // continue - but nothing after this moment is known, so the session is closed here and
        // flagged as "end not observed".
        if (openSessionId > 0L) {
            db.closeSession(openSessionId, now, false);
            openSessionId = 0L;
        }
        // Same for streaming: it may well continue, but the app can no longer see it.
        if (openListenId > 0L) {
            db.closeListen(openListenId, now, false);
            openListenId = 0L;
        }
        a2dpPlaying = false;
        playingSince = 0L;
        playingSinceExact = false;
        db.closeWindow(openWindowId, now);
        openWindowId = 0L;
        observing = false;
        WidgetUpdater.onObservingStopped(app, now);
        unregisterReceivers();
        cancelAllTimers();
        if (attemptProbe != null) {
            attemptProbe.cancel();
            attemptProbe = null;
        }
        if (batteryProbe != null) {
            batteryProbe.cancel();
            batteryProbe = null;
        }
        inFlight = false;
        closeProxies();
    }

    private boolean readAdapterOn() {
        try {
            return adapter != null && permissionOk && adapter.isEnabled();
        } catch (SecurityException e) {
            permissionOk = false;
            return false;
        }
    }

    // ------------------------------------------------------------------ profile proxies

    private final BluetoothProfile.ServiceListener serviceListener =
            new BluetoothProfile.ServiceListener() {
                @Override
                public void onServiceConnected(final int profile, final BluetoothProfile proxy) {
                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            handleServiceConnected(profile, proxy);
                        }
                    });
                }

                @Override
                public void onServiceDisconnected(final int profile) {
                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            handleServiceDisconnected(profile);
                        }
                    });
                }
            };

    private void ensureProxies() {
        if (adapter == null || !adapterOn || !permissionOk) {
            return;
        }
        try {
            if (!a2dpRequested) {
                a2dpRequested = true;
                if (!adapter.getProfileProxy(app, serviceListener, BluetoothProfile.A2DP)) {
                    a2dpRequested = false;
                }
            }
            if (!hfpRequested) {
                hfpRequested = true;
                if (!adapter.getProfileProxy(app, serviceListener, BluetoothProfile.HEADSET)) {
                    hfpRequested = false;
                }
            }
        } catch (SecurityException e) {
            permissionOk = false;
        }
    }

    private void closeProxies() {
        if (adapter != null) {
            try {
                if (a2dp != null) {
                    adapter.closeProfileProxy(BluetoothProfile.A2DP, a2dp);
                }
                if (hfp != null) {
                    adapter.closeProfileProxy(BluetoothProfile.HEADSET, hfp);
                }
            } catch (RuntimeException e) {
                // ignore
            }
        }
        a2dp = null;
        hfp = null;
        a2dpUsable = false;
        hfpUsable = false;
        a2dpRequested = false;
        hfpRequested = false;
    }

    private void handleServiceConnected(int profile, BluetoothProfile proxy) {
        if (acquireCount == 0) {
            try {
                if (adapter != null) {
                    adapter.closeProfileProxy(profile, proxy);
                }
            } catch (RuntimeException e) {
                // ignore
            }
            return;
        }
        if (profile == BluetoothProfile.A2DP) {
            a2dp = (BluetoothA2dp) proxy;
            a2dpUsable = true;
        } else if (profile == BluetoothProfile.HEADSET) {
            hfp = (BluetoothHeadset) proxy;
            hfpUsable = true;
        }
        refreshProfileStates();
        evaluateTransition("profile service ready");
    }

    private void handleServiceDisconnected(int profile) {
        if (profile == BluetoothProfile.A2DP) {
            a2dpUsable = false;
            a2dpState = BluetoothProfile.STATE_DISCONNECTED;
        } else if (profile == BluetoothProfile.HEADSET) {
            hfpUsable = false;
            hfpState = BluetoothProfile.STATE_DISCONNECTED;
        }
        evaluateTransition("Bluetooth audio service stopped");
    }

    private BluetoothDevice preferredDevice() {
        if (adapter == null || prefAddress == null) {
            return null;
        }
        try {
            return adapter.getRemoteDevice(prefAddress);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private boolean isPreferred(BluetoothDevice d) {
        return d != null && prefAddress != null && prefAddress.equalsIgnoreCase(d.getAddress());
    }

    private static BluetoothDevice deviceFrom(Intent intent) {
        try {
            return intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private boolean isBonded(BluetoothDevice d) {
        try {
            return d.getBondState() == BluetoothDevice.BOND_BONDED;
        } catch (SecurityException e) {
            return false;
        }
    }

    private static int safeType(BluetoothDevice d) {
        try {
            return d.getType();
        } catch (SecurityException e) {
            return BluetoothDevice.DEVICE_TYPE_UNKNOWN;
        }
    }

    private String displayName(BluetoothDevice d) {
        if (d != null) {
            String live = BtUtil.safeName(d);
            if (!"Unnamed device".equals(live)) {
                return live;
            }
        }
        return prefName != null ? prefName : "Your earbuds";
    }

    private void refreshProfileStates() {
        BluetoothDevice d = preferredDevice();
        if (!adapterOn) {
            a2dpState = BluetoothProfile.STATE_DISCONNECTED;
            hfpState = BluetoothProfile.STATE_DISCONNECTED;
            otherAudioConnected = false;
            otherAudioName = null;
            return;
        }
        try {
            if (a2dp != null && a2dpUsable && d != null) {
                a2dpState = a2dp.getConnectionState(d);
            }
            if (hfp != null && hfpUsable && d != null) {
                hfpState = hfp.getConnectionState(d);
            }
        } catch (SecurityException e) {
            permissionOk = false;
        } catch (RuntimeException e) {
            // Bluetooth service restarting; the next event will correct this.
        }
        refreshOtherAudio();
    }

    private void refreshOtherAudio() {
        otherAudioConnected = false;
        otherAudioName = null;
        try {
            if (a2dp != null && a2dpUsable) {
                noteOthers(a2dp.getConnectedDevices());
            }
            if (hfp != null && hfpUsable) {
                noteOthers(hfp.getConnectedDevices());
            }
        } catch (SecurityException e) {
            permissionOk = false;
        } catch (RuntimeException e) {
            // ignore
        }
    }

    private void noteOthers(List<BluetoothDevice> devices) {
        if (devices == null) {
            return;
        }
        for (int i = 0; i < devices.size(); i++) {
            BluetoothDevice o = devices.get(i);
            if (o != null && !isPreferred(o)) {
                otherAudioConnected = true;
                if (otherAudioName == null) {
                    otherAudioName = BtUtil.safeName(o);
                }
            }
        }
    }

    /** Addresses of devices Android currently reports as connected for music or calls. */
    public Set<String> connectedAudioAddresses() {
        Set<String> out = new HashSet<String>();
        try {
            if (a2dp != null && a2dpUsable) {
                for (BluetoothDevice d : a2dp.getConnectedDevices()) {
                    out.add(d.getAddress());
                }
            }
            if (hfp != null && hfpUsable) {
                for (BluetoothDevice d : hfp.getConnectedDevices()) {
                    out.add(d.getAddress());
                }
            }
        } catch (RuntimeException e) {
            // ignore
        }
        return out;
    }

    public boolean connectionStateKnown() {
        return a2dpUsable || hfpUsable;
    }

    // ------------------------------------------------------------------ broadcasts

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            handleBroadcast(intent);
        }
    };

    private final BroadcastReceiver vendorReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            handleVendorEvent(intent);
        }
    };

    private void registerReceivers() {
        if (receiversRegistered) {
            return;
        }
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        f.addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED);
        f.addAction(BluetoothA2dp.ACTION_PLAYING_STATE_CHANGED);
        f.addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED);
        f.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        f.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        f.addAction(ACTION_BATTERY_LEVEL_CHANGED);
        app.registerReceiver(stateReceiver, f);

        IntentFilter v = new IntentFilter(BluetoothHeadset.ACTION_VENDOR_SPECIFIC_HEADSET_EVENT);
        v.addCategory(BluetoothHeadset.VENDOR_SPECIFIC_HEADSET_EVENT_COMPANY_ID_CATEGORY
                + "." + APPLE_COMPANY_ID);
        app.registerReceiver(vendorReceiver, v);
        receiversRegistered = true;
    }

    private void unregisterReceivers() {
        if (!receiversRegistered) {
            return;
        }
        try {
            app.unregisterReceiver(stateReceiver);
        } catch (RuntimeException e) {
            // ignore
        }
        try {
            app.unregisterReceiver(vendorReceiver);
        } catch (RuntimeException e) {
            // ignore
        }
        receiversRegistered = false;
    }

    private void handleBroadcast(Intent intent) {
        if (intent == null || intent.getAction() == null) {
            return;
        }
        String action = intent.getAction();
        if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) {
            onAdapterState(intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR));
            return;
        }
        BluetoothDevice dev = deviceFrom(intent);
        boolean mine = isPreferred(dev);

        if (BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED.equals(action)) {
            if (mine) {
                a2dpState = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, a2dpState);
                refreshOtherAudio();
                evaluateTransition("music audio state changed");
            } else {
                onOtherAudioEvent();
            }
        } else if (BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED.equals(action)) {
            if (mine) {
                hfpState = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, hfpState);
                refreshOtherAudio();
                evaluateTransition("call audio state changed");
            } else {
                onOtherAudioEvent();
            }
        } else if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
            if (mine) {
                onAcl(true);
            }
        } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
            if (mine) {
                onAcl(false);
            }
        } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)) {
            if (mine) {
                int bond = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1);
                if (bond == BluetoothDevice.BOND_NONE) {
                    db.addLog("UNPAIRED", displayName(dev) + " was unpaired in Android settings");
                }
                publish();
            }
        } else if (BluetoothA2dp.ACTION_PLAYING_STATE_CHANGED.equals(action)) {
            if (mine) {
                int st = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, -1);
                if (st == BluetoothA2dp.STATE_PLAYING) {
                    setPlaying(true);
                } else if (st == BluetoothA2dp.STATE_NOT_PLAYING) {
                    setPlaying(false);
                }
            }
        } else if (ACTION_BATTERY_LEVEL_CHANGED.equals(action)) {
            if (mine && (isConnectedNow() || aclState == Snapshot.ACL_UP)) {
                int level = intent.getIntExtra(EXTRA_BATTERY_LEVEL, -1);
                onBatteryReading("single", level, "Android system battery report");
            }
        }
    }

    private void handleVendorEvent(Intent intent) {
        if (intent == null) {
            return;
        }
        BluetoothDevice dev = deviceFrom(intent);
        if (!isPreferred(dev)) {
            return;
        }
        String cmd = intent.getStringExtra(BluetoothHeadset.EXTRA_VENDOR_SPECIFIC_HEADSET_EVENT_CMD);
        if (!"+IPHONEACCEV".equals(cmd)) {
            return;
        }
        Serializable raw = intent.getSerializableExtra(
                BluetoothHeadset.EXTRA_VENDOR_SPECIFIC_HEADSET_EVENT_ARGS);
        if (!(raw instanceof Object[])) {
            return;
        }
        Integer percent = VendorBatteryParser.parseIphoneAccev((Object[]) raw);
        if (percent != null) {
            onBatteryReading("single", percent.intValue(),
                    "Headset battery report (10% steps)");
        }
    }

    private void onOtherAudioEvent() {
        refreshOtherAudio();
        if (!otherAudioConnected && canAutoConnect() && !isConnectedNow() && !inFlight && !pending) {
            schedulePending("Another audio device disconnected", 5000L);
        }
        publish();
    }

    private void onAdapterState(int st) {
        if (st == BluetoothAdapter.STATE_OFF || st == BluetoothAdapter.STATE_TURNING_OFF) {
            if (adapterOn) {
                db.addLog("BT_OFF", "Bluetooth was turned off");
            }
            adapterOn = false;
            cancelAllTimers();
            abortAttempt("Bluetooth was turned off.");
            a2dpState = BluetoothProfile.STATE_DISCONNECTED;
            hfpState = BluetoothProfile.STATE_DISCONNECTED;
            aclState = Snapshot.ACL_UNKNOWN;
            linkedNoAudio = false;
            evaluateTransition("Bluetooth turned off");
        } else if (st == BluetoothAdapter.STATE_ON) {
            if (!adapterOn) {
                db.addLog("BT_ON", "Bluetooth was turned on");
            }
            adapterOn = true;
            permissionOk = BtUtil.hasPermission(app);
            ensureProxies();
            failedAttempts = 0;
            gaveUp = false;
            h.removeCallbacks(adapterOnRunnable);
            h.postDelayed(adapterOnRunnable, ADAPTER_ON_DELAY_MS);
            publish();
        }
    }

    private void onAcl(boolean up) {
        if (attemptProbe != null || batteryProbe != null) {
            // These events come from this app's own short Bluetooth LE request; they say nothing
            // about the earbuds being nearby for audio, and would only clutter the log.
            return;
        }
        aclState = up ? Snapshot.ACL_UP : Snapshot.ACL_DOWN;
        aclTime = System.currentTimeMillis();
        BluetoothDevice d = preferredDevice();
        db.addLog(up ? "LINK_UP" : "LINK_DOWN",
                displayName(d) + (up ? " link established" : " link ended"));
        h.removeCallbacks(gapCheckRunnable);
        linkedNoAudio = false;
        if (up) {
            // The earbuds found the phone themselves; no request is needed. Give Android a few
            // seconds to bring up audio, then check.
            cancelPendingAttempt();
            h.postDelayed(gapCheckRunnable, PROFILE_GRACE_MS);
        }
        publish();
    }

    // ------------------------------------------------------------------ timers

    private final Runnable initialCheckRunnable = new Runnable() {
        @Override
        public void run() {
            startupSettled = true;
            refreshProfileStates();
            evaluateTransition("startup");
            if (!isConnectedNow() && canAutoConnect() && !pending && !inFlight) {
                schedulePending("Monitoring started", 3000L);
            }
            publish();
        }
    };

    private final Runnable heartbeatRunnable = new Runnable() {
        @Override
        public void run() {
            if (acquireCount == 0) {
                return;
            }
            long now = System.currentTimeMillis();
            db.touchWindow(openWindowId, now);
            if (openSessionId > 0L && wasConnected) {
                db.touchSession(openSessionId, now);
            }
            if (openListenId > 0L && a2dpPlaying) {
                db.touchListen(openListenId, now);
            }
            WidgetUpdater.touch(app, now);
            h.postDelayed(this, HEARTBEAT_MS);
        }
    };

    private final Runnable adapterOnRunnable = new Runnable() {
        @Override
        public void run() {
            refreshProfileStates();
            evaluateTransition("Bluetooth turned on");
            if (!isConnectedNow() && canAutoConnect() && !inFlight && !otherAudioConnected) {
                startAttempt("Bluetooth turned on", false);
            }
        }
    };

    private final Runnable pendingAttemptRunnable = new Runnable() {
        @Override
        public void run() {
            pending = false;
            nextAttemptAt = 0L;
            if (!canAutoConnect() || inFlight) {
                publish();
                return;
            }
            refreshProfileStates();
            evaluateTransition("check before retry");
            if (isConnectedNow()) {
                return;
            }
            if (otherAudioConnected) {
                String msg = "Skipped: another audio device (" + otherAudioName
                        + ") is connected and was left alone.";
                db.addLog("SKIPPED", msg);
                lastAttemptResult = msg;
                lastAttemptOk = null;
                prefs.setLastAttempt(System.currentTimeMillis(), msg);
                publish();
                return;
            }
            startAttempt(pendingReason, false);
        }
    };

    private final Runnable attemptTimeoutRunnable = new Runnable() {
        @Override
        public void run() {
            if (inFlight) {
                refreshProfileStates();
                evaluateTransition("attempt timeout");
                if (inFlight) {
                    finishAttempt(false, "No connection was confirmed in time.");
                }
            }
        }
    };

    private final Runnable verifyRunnable = new Runnable() {
        @Override
        public void run() {
            if (!inFlight) {
                return;
            }
            refreshProfileStates();
            evaluateTransition("verifying");
            if (inFlight) {
                finishAttempt(false, "The earbuds answered, but Android did not bring up audio. "
                        + "Open Bluetooth settings and tap the earbuds to connect.");
            }
        }
    };

    private final Runnable gapCheckRunnable = new Runnable() {
        @Override
        public void run() {
            refreshProfileStates();
            evaluateTransition("link check");
            if (!isConnectedNow() && aclState == Snapshot.ACL_UP && !inFlight) {
                linkedNoAudio = true;
                BluetoothDevice d = preferredDevice();
                db.addLog("LINKED_NO_AUDIO", displayName(d)
                        + " is linked but audio is not connected");
                if (prefs.connectionNotifications()) {
                    Notifs.connectionEvent(app, displayName(d) + " is nearby",
                            "Audio isn't connected. Open Bluetooth settings and tap the earbuds.");
                }
            }
            publish();
        }
    };

    private final Runnable batteryProbeRunnable = new Runnable() {
        @Override
        public void run() {
            if (isConnectedNow() && !batLive) {
                startBatteryProbe();
            }
        }
    };

    private void cancelAllTimers() {
        h.removeCallbacks(initialCheckRunnable);
        h.removeCallbacks(adapterOnRunnable);
        h.removeCallbacks(pendingAttemptRunnable);
        h.removeCallbacks(attemptTimeoutRunnable);
        h.removeCallbacks(verifyRunnable);
        h.removeCallbacks(gapCheckRunnable);
        h.removeCallbacks(batteryProbeRunnable);
        h.removeCallbacks(connectNowRunnable);
        pending = false;
        nextAttemptAt = 0L;
    }

    private void cancelPendingAttempt() {
        h.removeCallbacks(pendingAttemptRunnable);
        pending = false;
        nextAttemptAt = 0L;
    }

    // ------------------------------------------------------------------ connection state

    private boolean isConnectedNow() {
        return adapterOn && (a2dpState == BluetoothProfile.STATE_CONNECTED
                || hfpState == BluetoothProfile.STATE_CONNECTED);
    }

    private boolean canAutoConnect() {
        if (activeCount <= 0 || !prefs.autoConnect() || prefAddress == null
                || !adapterOn || !permissionOk) {
            return false;
        }
        BluetoothDevice d = preferredDevice();
        return d != null && isBonded(d);
    }

    /**
     * True when "not connected" is a trustworthy reading, so that a later connection can be
     * recorded as an exact start. It needs the startup check done and both audio profile services
     * bound (or Bluetooth off, which is a definite "not connected").
     */
    private boolean reliableRead() {
        return startupSettled && (!adapterOn || (a2dpUsable && hfpUsable));
    }

    private void evaluateTransition(String cause) {
        boolean now = isConnectedNow();
        if (!now && reliableRead()) {
            observedDisconnected = true;
        }
        if (now && !wasConnected) {
            wasConnected = true;
            onBecameConnected(cause);
        } else if (!now && wasConnected) {
            wasConnected = false;
            onBecameDisconnected(cause);
        }
        syncPlaying();
        publish();
    }

    // ------------------------------------------------------------------ listening time

    /**
     * A live "streaming started / stopped" event from Android for the chosen earbuds. A start seen
     * here is exact; a stop seen here is exact.
     */
    private void setPlaying(boolean playing) {
        long now = System.currentTimeMillis();
        if (playing) {
            if (a2dpPlaying) {
                return;
            }
            if (a2dpState != BluetoothProfile.STATE_CONNECTED) {
                // The stream event can overtake the "connected" event. Catch the connection up
                // first so the session is recorded before the streaming inside it.
                refreshProfileStates();
                evaluateTransition("music stream started");
                if (a2dpPlaying) {
                    return; // found by looking while catching up: recorded as "first seen"
                }
            }
            if (!adapterOn || a2dpState != BluetoothProfile.STATE_CONNECTED) {
                return;
            }
            a2dpPlaying = true;
            playingSince = now;
            playingSinceExact = true;
            openListenId = db.openListen(now, true);
        } else {
            if (!a2dpPlaying) {
                return;
            }
            endPlaying(now, true);
        }
        publish();
    }

    private void endPlaying(long now, boolean exact) {
        if (openListenId > 0L) {
            db.closeListen(openListenId, now, exact);
            openListenId = 0L;
        }
        a2dpPlaying = false;
        playingSince = 0L;
        playingSinceExact = false;
    }

    /**
     * Brings the streaming state in line with what is known, when no event told us: when the music
     * link ends, a span ends (seen live, so exact); when the link is up and Android says audio is
     * already flowing, a span starts that was only "first seen" (not exact).
     */
    private void syncPlaying() {
        long now = System.currentTimeMillis();
        boolean linked = adapterOn && a2dpState == BluetoothProfile.STATE_CONNECTED;
        if (!linked) {
            if (a2dpPlaying) {
                endPlaying(now, true);
            }
            return;
        }
        if (a2dpPlaying || a2dp == null || !a2dpUsable) {
            return;
        }
        BluetoothDevice d = preferredDevice();
        if (d == null) {
            return;
        }
        try {
            if (a2dp.isA2dpPlaying(d)) {
                a2dpPlaying = true;
                playingSince = now;
                playingSinceExact = false;
                openListenId = db.openListen(now, false);
            }
        } catch (SecurityException e) {
            permissionOk = false;
        } catch (RuntimeException e) {
            // Bluetooth service restarting; the next event will correct this.
        }
    }

    private void onBecameConnected(String cause) {
        long now = System.currentTimeMillis();
        connectedSince = now;
        connectedSinceExact = observedDisconnected;
        BluetoothDevice dev = preferredDevice();
        if (openSessionId > 0L) {
            db.closeSession(openSessionId, now, false);
        }
        openSessionId = db.openSession(displayName(dev), prefAddress, now, connectedSinceExact);
        prefs.setLastSuccessTime(now);
        cancelPendingAttempt();
        h.removeCallbacks(gapCheckRunnable);
        failedAttempts = 0;
        gaveUp = false;
        linkedNoAudio = false;
        BluetoothDevice d = preferredDevice();
        String name = displayName(d);
        boolean music = a2dpState == BluetoothProfile.STATE_CONNECTED;
        boolean calls = hfpState == BluetoothProfile.STATE_CONNECTED;
        String what = music ? (calls ? "music + calls" : "music") : "calls only";
        db.addLog("CONNECTED", name + " connected (" + what + ")"
                + (startupSettled ? "" : " - already connected when monitoring started"));
        if (inFlight) {
            finishAttempt(true, "Connected - confirmed from Android's connection state.");
        }
        if (startupSettled && prefs.connectionNotifications()) {
            Notifs.connectionEvent(app, name + " connected", "Connected for " + what + ".");
        }
        batProbeState = 0;
        h.removeCallbacks(batteryProbeRunnable);
        h.postDelayed(batteryProbeRunnable, BATTERY_PROBE_DELAY_MS);
    }

    private void onBecameDisconnected(String cause) {
        // The app was watching when this happened, so the end time is real.
        if (openSessionId > 0L) {
            db.closeSession(openSessionId, System.currentTimeMillis(), true);
            openSessionId = 0L;
        }
        connectedSince = 0L;
        connectedSinceExact = false;
        batLive = false;
        h.removeCallbacks(batteryProbeRunnable);
        if (batteryProbe != null) {
            batteryProbe.cancel();
            batteryProbe = null;
        }
        BluetoothDevice d = preferredDevice();
        String name = displayName(d);
        db.addLog("DISCONNECTED", name + " disconnected (" + cause + ")");
        if (prefs.connectionNotifications()) {
            Notifs.connectionEvent(app, name + " disconnected", cause);
        }
        if (canAutoConnect()) {
            failedAttempts = 0;
            gaveUp = false;
            scheduleNext();
        }
    }

    // ------------------------------------------------------------------ connection attempts

    private void schedulePending(String reason, long delayMs) {
        cancelPendingAttempt();
        pending = true;
        pendingReason = reason;
        nextAttemptAt = System.currentTimeMillis() + delayMs;
        h.postDelayed(pendingAttemptRunnable, delayMs);
        publish();
    }

    private void scheduleNext() {
        long delay = RetryPolicy.delayAfterFailures(failedAttempts);
        if (delay < 0) {
            gaveUp = true;
            String msg = "Stopped automatic retries after " + failedAttempts
                    + " tries. They resume when Bluetooth or the earbuds change state, "
                    + "or when you tap Connect Now.";
            db.addLog("GAVE_UP", msg);
            lastAttemptResult = msg;
            publish();
            return;
        }
        schedulePending("Automatic retry", delay);
    }

    private final Runnable connectNowRunnable = new Runnable() {
        @Override
        public void run() {
            doConnectNow();
        }
    };

    /** User asked to connect (button, notification action or Quick Settings tile). */
    public void connectNow() {
        if (acquireCount == 0) {
            return;
        }
        if (!a2dpUsable || !hfpUsable) {
            // Profile services were just requested; give them a moment so "already connected"
            // can be detected instead of sending a pointless request.
            h.removeCallbacks(connectNowRunnable);
            h.postDelayed(connectNowRunnable, PROXY_WAIT_MS);
            return;
        }
        doConnectNow();
    }

    private void doConnectNow() {
        BluetoothDevice d = preferredDevice();
        if (d == null || !adapterOn || !permissionOk) {
            publish();
            return;
        }
        refreshProfileStates();
        evaluateTransition("manual check");
        long now = System.currentTimeMillis();
        if (isConnectedNow()) {
            lastAttemptResult = "Already connected - no request was needed.";
            lastAttemptOk = Boolean.TRUE;
            prefs.setLastAttempt(now, lastAttemptResult);
            publish();
            return;
        }
        if (inFlight) {
            return;
        }
        cancelPendingAttempt();
        failedAttempts = 0;
        gaveUp = false;
        startAttempt("Connect Now", true);
    }

    private void startAttempt(String reason, boolean manual) {
        if (inFlight) {
            return;
        }
        BluetoothDevice d = preferredDevice();
        if (d == null || !adapterOn) {
            return;
        }
        refreshProfileStates();
        if (isConnectedNow()) {
            evaluateTransition("check before attempt");
            return;
        }
        if (safeType(d) == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
            // Nothing can be requested for classic-only devices on Android 11. Be upfront about it
            // and do NOT loop: automatic mode just waits for the earbuds to connect themselves.
            String msg = "These earbuds use classic Bluetooth only. Android doesn't let apps "
                    + "start that connection. Turn the earbuds on or take them out of the case, "
                    + "or tap them in Bluetooth settings.";
            long t = System.currentTimeMillis();
            lastAttemptOk = Boolean.FALSE;
            lastAttemptResult = msg;
            prefs.setLastAttempt(t, msg);
            if (manual) {
                db.addLog("ATTEMPT_FAILED", msg);
            } else if (!classicNoted) {
                classicNoted = true;
                db.addLog("CANNOT_REQUEST", msg);
            }
            publish();
            return;
        }
        inFlight = true;
        attemptManual = manual;
        attemptStart = System.currentTimeMillis();
        lastAttemptOk = null;
        lastAttemptResult = "Request in progress...";
        prefs.setLastAttempt(attemptStart, lastAttemptResult);
        db.addLog("ATTEMPT", reason + ": sending connection request to " + displayName(d));
        publish();

        h.removeCallbacks(attemptTimeoutRunnable);
        h.postDelayed(attemptTimeoutRunnable,
                ATTEMPT_TIMEOUT_MS + VERIFY_AFTER_LINK_MS + 3000L);
        attemptProbe = new GattProbe(app, d, false, ATTEMPT_TIMEOUT_MS, new GattProbe.Listener() {
            @Override
            public void onLinkUp() {
                // The link being up is NOT a success; only the profile state counts.
            }

            @Override
            public void onBattery(int level) {
                // not requested for connection attempts
            }

            @Override
            public void onFinished(boolean linkEstablished, int status, boolean batteryServiceFound) {
                attemptProbe = null;
                if (!inFlight) {
                    return;
                }
                if (linkEstablished) {
                    h.removeCallbacks(verifyRunnable);
                    h.postDelayed(verifyRunnable, VERIFY_AFTER_LINK_MS);
                } else {
                    finishAttempt(false, describeGattFailure(status));
                }
            }
        });
        attemptProbe.start();
    }

    private static String describeGattFailure(int status) {
        String possible = " The earbuds may be off, in their case, out of range, or connected "
                + "to another device.";
        if (status == 133 || status == 62) {
            return "No response from the earbuds." + possible;
        }
        if (status == 8) {
            return "The earbuds didn't answer in time." + possible;
        }
        if (status == -1) {
            return "Android could not start a Bluetooth request (Bluetooth busy or permission "
                    + "missing). Try again in a moment.";
        }
        return "Android could not reach the earbuds (code " + status + ")." + possible;
    }

    private void finishAttempt(boolean ok, String message) {
        if (!inFlight) {
            return;
        }
        inFlight = false;
        h.removeCallbacks(attemptTimeoutRunnable);
        h.removeCallbacks(verifyRunnable);
        if (attemptProbe != null) {
            attemptProbe.cancel();
            attemptProbe = null;
        }
        lastAttemptOk = Boolean.valueOf(ok);
        lastAttemptResult = message;
        prefs.setLastAttempt(System.currentTimeMillis(), message);
        if (!ok) {
            db.addLog("ATTEMPT_FAILED", message);
            if (!attemptManual) {
                failedAttempts++;
                if (canAutoConnect() && !isConnectedNow()) {
                    scheduleNext();
                }
            }
        }
        publish();
    }

    private void abortAttempt(String reason) {
        if (!inFlight) {
            return;
        }
        inFlight = false;
        h.removeCallbacks(attemptTimeoutRunnable);
        h.removeCallbacks(verifyRunnable);
        if (attemptProbe != null) {
            attemptProbe.cancel();
            attemptProbe = null;
        }
        lastAttemptOk = Boolean.FALSE;
        lastAttemptResult = reason;
        prefs.setLastAttempt(System.currentTimeMillis(), reason);
    }

    // ------------------------------------------------------------------ battery

    /** Ask the earbuds for their battery now (standard BLE battery service only). */
    public void checkBatteryNow() {
        if (acquireCount == 0 || !isConnectedNow()) {
            return;
        }
        startBatteryProbe();
    }

    private void startBatteryProbe() {
        if (batteryProbe != null || attemptProbe != null) {
            return;
        }
        BluetoothDevice d = preferredDevice();
        if (d == null || !isConnectedNow()) {
            return;
        }
        if (safeType(d) == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
            batProbeState = 2;
            publish();
            return;
        }
        batProbeState = 1;
        publish();
        batteryProbe = new GattProbe(app, d, true, BATTERY_PROBE_TIMEOUT_MS, new GattProbe.Listener() {
            @Override
            public void onLinkUp() {
            }

            @Override
            public void onBattery(int level) {
                batProbeState = 3;
                onBatteryReading("single", level, "Standard Bluetooth battery service");
            }

            @Override
            public void onFinished(boolean linkEstablished, int status, boolean batteryServiceFound) {
                batteryProbe = null;
                if (batProbeState == 1) {
                    // 2 = reached the earbuds but no single readable battery service
                    // 4 = could not open a Bluetooth LE link, so nothing is known either way
                    batProbeState = linkEstablished ? 2 : 4;
                }
                publish();
            }
        });
        batteryProbe.start();
    }

    private void onBatteryReading(String kind, int level, String source) {
        if (!BatteryAlertEngine.isValidLevel(level)) {
            return; // unknown / invalid readings are never shown or alerted on
        }
        long now = System.currentTimeMillis();
        if ("left".equals(kind)) {
            batLeft = Integer.valueOf(level);
        } else if ("right".equals(kind)) {
            batRight = Integer.valueOf(level);
        } else {
            batSingle = Integer.valueOf(level);
            prefs.setLastBattery(level, now, source);
        }
        batTime = now;
        batSource = source;
        batLive = true;

        if (prefs.batteryHistory()) {
            long[] last = lastStored.get(kind);
            if (last == null || (int) last[1] != level || now - last[0] >= HISTORY_MIN_INTERVAL_MS) {
                db.addBattery(now, level, source, kind);
                lastStored.put(kind, new long[]{now, level});
            }
        }

        boolean fire = alertEngine.onReading(kind, level, prefs.alertThreshold(),
                prefs.alertsEnabled(), isConnectedNow() || aclState == Snapshot.ACL_UP);
        prefs.setAlertedKeys(alertEngine.snapshot());
        if (fire) {
            Notifs.lowBattery(app, displayName(preferredDevice()), kind, level);
        }
        publish();
    }

    // ------------------------------------------------------------------ settings / device changes

    public void onPreferredDeviceChanged() {
        prefAddress = prefs.preferredAddress();
        prefName = prefs.preferredName();
        if (acquireCount == 0) {
            return;
        }
        cancelAllTimers();
        abortAttempt("Device changed.");
        if (batteryProbe != null) {
            batteryProbe.cancel();
            batteryProbe = null;
        }
        if (openSessionId > 0L) {
            // The user switched earbuds: the old session stops being tracked here, so its end was
            // not observed.
            db.closeSession(openSessionId, System.currentTimeMillis(), false);
            openSessionId = 0L;
        }
        if (openListenId > 0L) {
            db.closeListen(openListenId, System.currentTimeMillis(), false);
            openListenId = 0L;
        }
        a2dpPlaying = false;
        playingSince = 0L;
        playingSinceExact = false;
        wasConnected = false;
        connectedSince = 0L;
        connectedSinceExact = false;
        observedDisconnected = false;
        a2dpState = BluetoothProfile.STATE_DISCONNECTED;
        hfpState = BluetoothProfile.STATE_DISCONNECTED;
        aclState = Snapshot.ACL_UNKNOWN;
        linkedNoAudio = false;
        batSingle = null;
        batLeft = null;
        batRight = null;
        batLive = false;
        batProbeState = 0;
        alertEngine.reset();
        prefs.setAlertedKeys(alertEngine.snapshot());
        lastStored.clear();
        failedAttempts = 0;
        gaveUp = false;
        classicNoted = false;
        lastAttemptResult = null;
        lastAttemptOk = null;
        if (prefAddress != null) {
            db.addLog("DEVICE_SELECTED", (prefName == null ? "Device" : prefName) + " selected");
            refreshProfileStates();
            evaluateTransition("device changed");
            if (!isConnectedNow() && canAutoConnect()) {
                schedulePending("Device selected", 3000L);
            }
        }
        publish();
    }

    public void onSettingsChanged() {
        if (acquireCount == 0) {
            return;
        }
        if (!prefs.autoConnect()) {
            cancelPendingAttempt();
            gaveUp = false;
        } else if (!isConnectedNow() && canAutoConnect() && !pending && !inFlight) {
            failedAttempts = 0;
            gaveUp = false;
            schedulePending("Auto-Connect turned on", 2000L);
        }
        publish();
    }

    // ------------------------------------------------------------------ snapshot

    private void publish() {
        if (acquireCount == 0 && listeners.isEmpty()) {
            return;
        }
        Snapshot s = snapshot();
        if (acquireCount > 0 && startupSettled) {
            // Not before the startup check: until then "not connected" is only a default, and a
            // widget must not flash it. Cheap when nothing changed or no widget is placed.
            WidgetUpdater.onSnapshot(app, s, observing);
        }
        for (Listener l : listeners) {
            l.onSnapshot(s);
        }
    }

    public Snapshot snapshot() {
        Snapshot s = new Snapshot();
        if (adapter == null) {
            adapter = BtUtil.adapter(app);
        }
        s.adapterPresent = adapter != null;
        s.adapterOn = adapterOn;
        s.permissionOk = permissionOk;

        BluetoothDevice d = preferredDevice();
        s.deviceAddress = prefAddress;
        s.deviceName = prefAddress == null ? null : displayName(d);
        s.bonded = d != null && isBonded(d);
        if (d != null) {
            s.deviceType = BtUtil.typeLabel(d);
            s.transport = BtUtil.transportLabel(d);
            s.deviceTypeCode = safeType(d);
            s.advertisesA2dp = BtUtil.advertisesA2dp(d);
            s.advertisesHandsFree = BtUtil.advertisesHandsFree(d);
        }
        s.a2dpState = a2dpState;
        s.hfpState = hfpState;
        s.a2dpProxyReady = a2dpUsable;
        s.hfpProxyReady = hfpUsable;
        s.aclState = aclState;
        s.aclTime = aclTime;
        s.linkedNoAudio = linkedNoAudio;
        s.connectedSince = connectedSince;
        s.connectedSinceExact = connectedSinceExact;
        s.a2dpPlaying = a2dpPlaying && adapterOn && a2dpState == BluetoothProfile.STATE_CONNECTED;
        s.playingSince = s.a2dpPlaying ? playingSince : 0L;
        s.playingSinceExact = s.a2dpPlaying && playingSinceExact;
        s.otherAudioConnected = otherAudioConnected;
        s.otherAudioName = otherAudioName;

        s.attemptInFlight = inFlight;
        s.attemptManual = attemptManual;
        s.failedAttempts = failedAttempts;
        s.gaveUp = gaveUp;
        s.nextAttemptAt = nextAttemptAt;
        s.lastAttemptTime = prefs.lastAttemptTime();
        s.lastAttemptResult = lastAttemptResult != null ? lastAttemptResult : prefs.lastAttemptResult();
        s.lastAttemptOk = lastAttemptOk;
        s.lastSuccessTime = prefs.lastSuccessTime();

        if (batLive && isConnectedNow()) {
            s.batSingle = batSingle;
            s.batLeft = batLeft;
            s.batRight = batRight;
            s.batTime = batTime;
            s.batSource = batSource;
            s.batLive = true;
        }
        s.lastBatLevel = prefs.lastBatteryLevel();
        s.lastBatTime = prefs.lastBatteryTime();
        s.lastBatSource = prefs.lastBatterySource();
        s.batProbeState = batProbeState;

        s.autoConnect = prefs.autoConnect();
        s.monitoring = prefs.monitoring();
        return s;
    }
}
