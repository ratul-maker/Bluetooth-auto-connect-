package com.btearbuds.autoconnect.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.view.View;
import android.view.animation.LinearInterpolator;

import com.btearbuds.autoconnect.R;

/**
 * The glowing orb on the dashboard. Its look follows the real connection state:
 * connected = slow rotating arc and gentle breathing glow, connecting = fast pulse, anything else
 * = still and dim. It animates only while the screen is visible and only if Android's animations
 * are enabled; it draws with plain strokes and gradients (no blur), which is cheap on the GPU.
 */
public final class StatusOrbView extends View {

    public static final int MODE_IDLE = 0;
    public static final int MODE_CONNECTED = 1;
    public static final int MODE_CONNECTING = 2;
    public static final int MODE_ERROR = 3;

    private final Paint haloPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint corePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();

    private int mainColor;
    private int endColor;
    private int mode = MODE_IDLE;
    private boolean running = true;
    private float phase;
    private ValueAnimator anim;

    private float cx;
    private float cy;
    private float radius;
    private float[] ticks = new float[0];

    public StatusOrbView(Context c) {
        super(c);
        mainColor = c.getColor(R.color.idle);
        endColor = mainColor;
        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setStrokeWidth(Ui.dp(c, 2));
        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeWidth(Ui.dp(c, 4));
        arcPaint.setStrokeCap(Paint.Cap.ROUND);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(Ui.dp(c, 1));
        tickPaint.setStyle(Paint.Style.STROKE);
        tickPaint.setStrokeWidth(Ui.dp(c, 1));
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    /** @param color main colour; @param end second colour for the arc's tail (violet when connected). */
    public void setStatus(int mode, int color, int end) {
        boolean changed = this.mode != mode || mainColor != color || endColor != end;
        this.mode = mode;
        this.mainColor = color;
        this.endColor = end;
        if (changed) {
            rebuildShaders();
            updateAnimation();
            invalidate();
        }
    }

    /** The activity calls this from onResume/onPause so nothing animates in the background. */
    public void setRunning(boolean running) {
        this.running = running;
        updateAnimation();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int size = Ui.dp(getContext(), 220);
        setMeasuredDimension(resolveSize(size, widthSpec), resolveSize(size, heightSpec));
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        cx = w / 2f;
        cy = h / 2f;
        radius = Math.min(w, h) / 2f - Ui.dp(getContext(), 14);
        float arcR = radius * 0.88f;
        oval.set(cx - arcR, cy - arcR, cx + arcR, cy + arcR);
        int n = 48;
        ticks = new float[n * 4];
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            float len = (i % 4 == 0) ? 0.06f : 0.03f;
            float r1 = radius * 1.0f;
            float r0 = radius * (1.0f - len);
            ticks[i * 4] = cx + (float) Math.cos(a) * r0;
            ticks[i * 4 + 1] = cy + (float) Math.sin(a) * r0;
            ticks[i * 4 + 2] = cx + (float) Math.cos(a) * r1;
            ticks[i * 4 + 3] = cy + (float) Math.sin(a) * r1;
        }
        rebuildShaders();
    }

    private void rebuildShaders() {
        if (radius <= 0f) {
            return;
        }
        haloPaint.setShader(new RadialGradient(cx, cy, radius * 1.3f,
                new int[]{alpha(mainColor, 0x59), alpha(mainColor, 0x1F), alpha(mainColor, 0x00)},
                new float[]{0.62f, 0.82f, 1f}, Shader.TileMode.CLAMP));
        corePaint.setShader(new RadialGradient(cx, cy, radius * 0.8f,
                new int[]{alpha(mainColor, 0x2E), 0xFF04090D, 0xFF000000},
                new float[]{0f, 0.85f, 1f}, Shader.TileMode.CLAMP));
        arcPaint.setShader(new SweepGradient(cx, cy,
                new int[]{alpha(mainColor, 0x00), mainColor, endColor},
                new float[]{0f, 0.72f, 1f}));
        trackPaint.setColor(alpha(mainColor, 0x40));
        ringPaint.setColor(alpha(mainColor, 0x80));
        tickPaint.setColor(alpha(mainColor, mode == MODE_IDLE ? 0x30 : 0x66));
    }

    private static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    // ------------------------------------------------------------------ animation

    private boolean shouldAnimate() {
        return running && isAttachedToWindow() && getWindowVisibility() == VISIBLE && isShown()
                && (mode == MODE_CONNECTED || mode == MODE_CONNECTING)
                && ValueAnimator.areAnimatorsEnabled();
    }

    private void updateAnimation() {
        if (shouldAnimate()) {
            long duration = mode == MODE_CONNECTING ? 1600L : 7000L;
            if (anim == null) {
                anim = ValueAnimator.ofFloat(0f, 1f);
                anim.setInterpolator(new LinearInterpolator());
                anim.setRepeatCount(ValueAnimator.INFINITE);
                anim.addUpdateListener(a -> {
                    phase = (Float) a.getAnimatedValue();
                    invalidate();
                });
            }
            if (anim.getDuration() != duration) {
                anim.setDuration(duration);
            }
            if (!anim.isStarted()) {
                anim.start();
            }
        } else if (anim != null) {
            anim.cancel();
            phase = 0f;
            invalidate();
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        updateAnimation();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.cancel();
            anim = null;
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        updateAnimation();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        updateAnimation();
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas canvas) {
        if (radius <= 0f) {
            return;
        }
        boolean animated = anim != null && anim.isRunning();
        float breathe = 0f;
        if (animated) {
            double turns = mode == MODE_CONNECTING ? 1.0 : 3.0;
            breathe = 0.5f + 0.5f * (float) Math.sin(phase * Math.PI * 2 * turns);
        }

        // halo
        float haloScale = 1f + 0.07f * breathe;
        canvas.save();
        canvas.scale(haloScale, haloScale, cx, cy);
        canvas.drawCircle(cx, cy, radius * 1.3f, haloPaint);
        canvas.restore();

        // ticks and thin rings
        canvas.drawLines(ticks, tickPaint);
        canvas.drawCircle(cx, cy, radius * 0.88f, trackPaint);
        canvas.drawCircle(cx, cy, radius * 0.74f, ringPaint);

        // rotating arc
        if (mode == MODE_CONNECTED || mode == MODE_CONNECTING) {
            canvas.save();
            canvas.rotate(phase * 360f, cx, cy);
            canvas.drawArc(oval, 0f, 300f, false, arcPaint);
            canvas.restore();
        }

        // dark core
        canvas.drawCircle(cx, cy, radius * 0.72f, corePaint);
    }
}
