package com.btearbuds.autoconnect.logic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Adds up "listening time": the periods in which Android reported that audio was streaming to the
 * chosen earbuds. A period is a {@link Span}.
 *
 * Honesty rules (the same spirit as the connection history):
 *  - Only time the app was watching is ever counted; nothing is estimated or filled in.
 *  - A span whose start or end the app did not see live is flagged, and a total that contains such a
 *    span is flagged "partial" so the screen can say "at least".
 *  - The stream state says "audio is flowing", not "music is playing": video, games and
 *    notification sounds count too, and the app cannot tell which app made the sound.
 * Pure Java, no Android, so it can be tested on any computer.
 */
public final class ListenStats {

    private ListenStats() {
    }

    public static final class Span {
        public final long start;
        /** 0 while the span is still open (audio is streaming right now). */
        public final long end;
        /** The app saw streaming start (false = it was already streaming when first seen). */
        public final boolean startExact;
        /** The app saw streaming stop (false = the app stopped watching while it was streaming). */
        public final boolean endExact;

        public Span(long start, long end, boolean startExact, boolean endExact) {
            this.start = start;
            this.end = end;
            this.startExact = startExact;
            this.endExact = endExact;
        }

        public boolean isOpen() {
            return end <= 0L;
        }
    }

    public static final class Total {
        public final long ms;
        /** At least one span inside the range has an unobserved start or end: the real value is higher. */
        public final boolean partial;
        public final int spans;

        Total(long ms, boolean partial, int spans) {
            this.ms = ms;
            this.partial = partial;
            this.spans = spans;
        }
    }

    /**
     * Listening time inside [from, to]. Open spans run up to {@code now}. Overlapping spans are not
     * counted twice. A span cut off by the range edge is not "partial" because of that edge.
     */
    public static Total total(List<Span> spans, long from, long to, long now) {
        long limit = Math.min(to, now);
        if (spans == null || spans.isEmpty() || limit <= from) {
            return new Total(0L, false, 0);
        }
        List<long[]> clipped = new ArrayList<long[]>();
        boolean partial = false;
        for (Span s : spans) {
            long sEnd = s.isOpen() ? now : s.end;
            long a = Math.max(s.start, from);
            long b = Math.min(sEnd, limit);
            if (b <= a) {
                continue;
            }
            clipped.add(new long[]{a, b});
            boolean startInside = s.start >= from;
            boolean endInside = !s.isOpen() && s.end <= limit;
            if ((startInside && !s.startExact) || (endInside && !s.endExact)) {
                partial = true;
            }
        }
        if (clipped.isEmpty()) {
            return new Total(0L, false, 0);
        }
        long[][] arr = clipped.toArray(new long[0][]);
        Arrays.sort(arr, new Comparator<long[]>() {
            @Override
            public int compare(long[] x, long[] y) {
                return x[0] < y[0] ? -1 : (x[0] > y[0] ? 1 : 0);
            }
        });
        long sum = 0L;
        long curS = arr[0][0];
        long curE = arr[0][1];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i][0] <= curE) {
                curE = Math.max(curE, arr[i][1]);
            } else {
                sum += curE - curS;
                curS = arr[i][0];
                curE = arr[i][1];
            }
        }
        sum += curE - curS;
        return new Total(sum, partial, arr.length);
    }

    /** Streaming time that happened during one connection session [start, end] (end 0 = still open). */
    public static Total duringSession(List<Span> spans, long sessionStart, long sessionEnd, long now) {
        long end = sessionEnd <= 0L ? now : sessionEnd;
        return total(spans, sessionStart, end, now);
    }

    /** Whether any span is open, i.e. audio is streaming right now. */
    public static boolean streamingNow(List<Span> spans) {
        if (spans == null) {
            return false;
        }
        for (Span s : spans) {
            if (s.isOpen()) {
                return true;
            }
        }
        return false;
    }
}
