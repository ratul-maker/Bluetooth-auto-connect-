package com.btearbuds.autoconnect.bt;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.text.format.DateFormat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Plain-language wording shared by the screen, the notification and the Quick Settings tile. */
public final class StatusText {

    public enum Action {
        NONE, PICK_DEVICE, OPEN_BT_SETTINGS, ENABLE_BT, APP_INFO
    }

    public static final class Hint {
        public final String text;
        public final Action action;
        public final String actionLabel;

        Hint(String text, Action action, String actionLabel) {
            this.text = text;
            this.action = action;
            this.actionLabel = actionLabel;
        }
    }

    private StatusText() {
    }

    public static String label(Snapshot s) {
        switch (s.status()) {
            case NO_DEVICE:
                return "No earbuds selected";
            case BT_UNAVAILABLE:
                return "Bluetooth unavailable";
            case BT_OFF:
                return "Bluetooth is off";
            case NO_PERMISSION:
                return "Permission needed";
            case UNPAIRED:
                return "Not paired";
            case CONNECTING:
                return "Connecting...";
            case CONNECTED:
                return "Connected";
            case CALLS_ONLY:
                return "Connected for calls only";
            case LINKED_NO_AUDIO:
                return "Nearby - audio not connected";
            case DISCONNECTED:
            default:
                return "Not connected";
        }
    }

    /** One line about battery for the notification; never invents a value. */
    public static String batteryLine(Snapshot s) {
        if (!s.isConnected()) {
            return null;
        }
        if (s.batSingle != null) {
            return "Battery " + s.batSingle + "%";
        }
        if (s.batLeft != null || s.batRight != null) {
            StringBuilder b = new StringBuilder();
            if (s.batLeft != null) {
                b.append("L ").append(s.batLeft).append("%");
            }
            if (s.batRight != null) {
                if (b.length() > 0) {
                    b.append("  ");
                }
                b.append("R ").append(s.batRight).append("%");
            }
            return b.toString();
        }
        return "Battery not reported";
    }

    public static Hint hint(Context ctx, Snapshot s) {
        switch (s.status()) {
            case NO_DEVICE:
                return new Hint("Choose the earbuds this app should look after. They must already "
                        + "be paired in Android's Bluetooth settings.", Action.PICK_DEVICE,
                        "Choose earbuds");
            case BT_UNAVAILABLE:
                return new Hint("Android reports no usable Bluetooth adapter, or the Bluetooth "
                        + "service isn't answering. Restarting the phone usually fixes a busy "
                        + "adapter.", Action.NONE, null);
            case BT_OFF:
                return new Hint("Turn Bluetooth on so the earbuds can connect.", Action.ENABLE_BT,
                        "Turn on Bluetooth");
            case NO_PERMISSION:
                return new Hint("Bluetooth permission is missing. Open App info, then Permissions, "
                        + "and allow it.", Action.APP_INFO, "Open App info");
            case UNPAIRED:
                return new Hint("These earbuds are no longer paired with this phone. Pair them "
                        + "again in Bluetooth settings, then choose them here.",
                        Action.OPEN_BT_SETTINGS, "Open Bluetooth settings");
            case LINKED_NO_AUDIO:
                return new Hint("The earbuds are close and linked, but Android hasn't connected "
                        + "audio. Open Bluetooth settings, tap the earbuds and make sure Media "
                        + "audio is on.", Action.OPEN_BT_SETTINGS, "Open Bluetooth settings");
            case CALLS_ONLY:
                return new Hint("Connected for phone calls only - music isn't connected. In "
                        + "Bluetooth settings, tap the gear next to the earbuds and turn on Media "
                        + "audio.", Action.OPEN_BT_SETTINGS, "Open Bluetooth settings");
            case DISCONNECTED:
                return disconnectedHint(ctx, s);
            case CONNECTING:
            case CONNECTED:
            default:
                return null;
        }
    }

    private static Hint disconnectedHint(Context ctx, Snapshot s) {
        if (s.otherAudioConnected) {
            return new Hint("Another audio device (" + s.otherAudioName + ") is connected. "
                    + "This app leaves it alone.", Action.NONE, null);
        }
        if (s.deviceTypeCode == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
            return new Hint("Android doesn't let apps start a connection to classic-only earbuds. "
                    + "Turn them on or take them out of the case - or tap them in Bluetooth "
                    + "settings. This app will notice when they connect.",
                    Action.OPEN_BT_SETTINGS, "Open Bluetooth settings");
        }
        if (s.gaveUp) {
            return new Hint("Automatic retries are paused after " + s.failedAttempts
                    + " tries so your battery isn't wasted. They resume when Bluetooth or the "
                    + "earbuds change state, or when you tap Connect Now.", Action.NONE, null);
        }
        if (s.nextAttemptAt > 0L) {
            return new Hint("Next automatic try around " + clock(ctx, s.nextAttemptAt)
                    + ". Android can't tell whether the earbuds are off, in their case, out of "
                    + "range or connected to another phone.", Action.NONE, null);
        }
        if (!s.autoConnect) {
            return new Hint("Auto-Connect is off. Tap Connect Now to try, or turn Auto-Connect on.",
                    Action.NONE, null);
        }
        if (!s.monitoring) {
            return new Hint("Auto-Connect works while the app is open or Background Monitoring is "
                    + "on. Turn Background Monitoring on to keep watching when the screen is off.",
                    Action.NONE, null);
        }
        return new Hint("The earbuds may be off, in their case, out of range or connected to "
                + "another phone. Android doesn't say which.", Action.NONE, null);
    }

    public static String clock(Context ctx, long millis) {
        return DateFormat.getTimeFormat(ctx).format(new Date(millis));
    }

    /** "Today 14:32", "Oct 13, 14:32" or "never". */
    public static String when(Context ctx, long millis) {
        if (millis <= 0L) {
            return "never";
        }
        Date d = new Date(millis);
        String time = DateFormat.getTimeFormat(ctx).format(d);
        long startOfToday = startOfToday();
        if (millis >= startOfToday) {
            return "Today " + time;
        }
        if (millis >= startOfToday - 24L * 60L * 60L * 1000L) {
            return "Yesterday " + time;
        }
        return DateFormat.getMediumDateFormat(ctx).format(d) + ", " + time;
    }

    /** Time of day down to the second, in the phone's 12 or 24 hour style: "14:32:07". */
    public static String clockSeconds(Context ctx, long millis) {
        String pattern = DateFormat.is24HourFormat(ctx) ? "HH:mm:ss" : "h:mm:ss a";
        return new SimpleDateFormat(pattern, Locale.getDefault()).format(new Date(millis));
    }

    /** Like {@link #when} but with seconds: "Today 14:32:07", "Yesterday 09:01:44", "Oct 13, 14:32:07". */
    public static String whenExact(Context ctx, long millis) {
        if (millis <= 0L) {
            return "never";
        }
        Date d = new Date(millis);
        String time = clockSeconds(ctx, millis);
        long startOfToday = startOfToday();
        if (millis >= startOfToday) {
            return "Today " + time;
        }
        if (millis >= startOfToday - 24L * 60L * 60L * 1000L) {
            return "Yesterday " + time;
        }
        return DateFormat.getMediumDateFormat(ctx).format(d) + ", " + time;
    }

    /** Colour tone of a status, shared by the dashboard and the widgets. */
    public static int tone(Snapshot s) {
        switch (s.status()) {
            case CONNECTED:
                return com.btearbuds.autoconnect.logic.WidgetModel.TONE_OK;
            case CONNECTING:
            case CALLS_ONLY:
            case LINKED_NO_AUDIO:
                return com.btearbuds.autoconnect.logic.WidgetModel.TONE_WARN;
            case BT_OFF:
            case BT_UNAVAILABLE:
            case NO_PERMISSION:
            case UNPAIRED:
                return com.btearbuds.autoconnect.logic.WidgetModel.TONE_ERROR;
            case NO_DEVICE:
            case DISCONNECTED:
            default:
                return com.btearbuds.autoconnect.logic.WidgetModel.TONE_IDLE;
        }
    }

    private static long startOfToday() {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.set(java.util.Calendar.HOUR_OF_DAY, 0);
        c.set(java.util.Calendar.MINUTE, 0);
        c.set(java.util.Calendar.SECOND, 0);
        c.set(java.util.Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }
}
