#!/usr/bin/env python3
"""Offline checks for the Android resources (no Android SDK needed).

  * every XML file is well formed
  * every @type/name reference in XML and the manifest points at a resource that exists
  * every R.type.name used in Java exists
  * widget layouts use only views that Android allows inside widgets (RemoteViews)
  * classes named in the manifest exist as source files
  * writes a stub R.java (for compile checks) into the directory given as argv[1]

Usage: python3 tools/check_resources.py <stub-output-dir>
"""
import os
import re
import sys
import xml.etree.ElementTree as ET

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MAIN = os.path.join(ROOT, "app", "src", "main")
RES = os.path.join(MAIN, "res")
JAVA = os.path.join(MAIN, "java")
PKG = "com.btearbuds.autoconnect"
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

ALLOWED_WIDGET_VIEWS = {
    "FrameLayout", "LinearLayout", "RelativeLayout", "GridLayout", "AnalogClock", "Button",
    "Chronometer", "ImageButton", "ImageView", "ProgressBar", "TextView", "ViewFlipper",
    "ListView", "GridView", "StackView", "AdapterViewFlipper", "ViewStub", "TextClock",
}

errors = []
res = {k: set() for k in
       ["color", "drawable", "mipmap", "layout", "xml", "string", "style", "id", "dimen"]}


def err(msg):
    errors.append(msg)
    print("ERROR:", msg)


def parse(path):
    try:
        return ET.parse(path).getroot()
    except ET.ParseError as e:
        err("XML not well formed: %s (%s)" % (os.path.relpath(path, ROOT), e))
        return None


# ---- collect resources
for dirpath, _, files in os.walk(RES):
    folder = os.path.basename(dirpath)
    for f in files:
        path = os.path.join(dirpath, f)
        base, ext = os.path.splitext(f)
        if ext != ".xml":
            err("unexpected non-XML resource file: " + path)
            continue
        root = parse(path)
        if root is None:
            continue
        kind = folder.split("-")[0]
        if kind == "values":
            for el in root:
                name = el.get("name")
                if el.tag in ("color", "string", "dimen"):
                    res[el.tag].add(name)
                elif el.tag == "style":
                    res["style"].add(name)
        elif kind in ("drawable", "mipmap", "layout", "xml"):
            res[kind].add(base)
            if kind == "layout":
                for el in root.iter():
                    v = el.get(ANDROID_NS + "id")
                    if v and v.startswith("@+id/"):
                        res["id"].add(v[5:])

# ---- references inside XML and the manifest
REF = re.compile(r"@(?!android:)(?:\+)?([a-z]+)/([A-Za-z0-9_.]+)")
xml_files = []
for dirpath, _, files in os.walk(RES):
    xml_files += [os.path.join(dirpath, f) for f in files if f.endswith(".xml")]
xml_files.append(os.path.join(MAIN, "AndroidManifest.xml"))
for path in xml_files:
    text = open(path, encoding="utf-8").read()
    for kind, name in REF.findall(text):
        if kind == "+id":
            continue
        if kind == "id":
            continue
        if kind not in res:
            continue
        if name not in res[kind]:
            err("%s: @%s/%s is not defined" % (os.path.relpath(path, ROOT), kind, name))

# ---- R.* used in Java
USE = re.compile(r"\bR\.(color|drawable|mipmap|layout|xml|string|style|id|dimen)\.([A-Za-z0-9_]+)")
for dirpath, _, files in os.walk(JAVA):
    for f in files:
        if f.endswith(".java"):
            text = open(os.path.join(dirpath, f), encoding="utf-8").read()
            for kind, name in USE.findall(text):
                if name not in res[kind]:
                    err("%s: R.%s.%s is not defined" % (f, kind, name))

# ---- widget layouts: only RemoteViews-safe classes
for f in ("widget_compact", "widget_expanded"):
    root = parse(os.path.join(RES, "layout", f + ".xml"))
    if root is not None:
        for el in root.iter():
            if el.tag not in ALLOWED_WIDGET_VIEWS:
                err("layout %s uses <%s>, which RemoteViews does not allow" % (f, el.tag))

# ---- manifest classes exist
man = parse(os.path.join(MAIN, "AndroidManifest.xml"))
if man is not None:
    for el in man.iter():
        n = el.get(ANDROID_NS + "name")
        if n and n.startswith(".") and el.tag in ("activity", "service", "receiver"):
            rel = n[1:].replace(".", os.sep) + ".java"
            if not os.path.exists(os.path.join(JAVA, *PKG.split("."), rel)):
                err("manifest names %s but %s does not exist" % (n, rel))
    perms = sorted(e.get(ANDROID_NS + "name") for e in man.iter("uses-permission"))
    print("permissions:", ", ".join(p.split(".")[-1] for p in perms))
    if any("INTERNET" in p for p in perms):
        err("INTERNET permission must not be present")

# ---- every id the widget renderer touches exists in the layout it is applied to
rend = os.path.join(JAVA, *PKG.split("."), "widget", "WidgetRenderer.java")
if os.path.exists(rend):
    src = open(rend, encoding="utf-8").read()
    for name in ("compact", "expanded"):
        i = src.index("static RemoteViews %s(" % name)
        j = src.index("\n    }\n", i)
        used = set(re.findall(r"R\.id\.(\w+)", src[i:j]))
        lay = open(os.path.join(RES, "layout", "widget_%s.xml" % name), encoding="utf-8").read()
        have = set(re.findall(r"@\+id/(\w+)", lay))
        for helper_id in ("w_timer", "w_timer_off", "w_battery"):
            if helper_id not in have:
                err("widget_%s.xml lacks @+id/%s used by shared helpers" % (name, helper_id))
        for u in sorted(used - have):
            err("WidgetRenderer.%s() uses R.id.%s but widget_%s.xml has no such id" % (name, u, name))

# ---- stub R.java
if len(sys.argv) > 1:
    out = os.path.join(sys.argv[1], *PKG.split("."))
    os.makedirs(out, exist_ok=True)
    lines = ["package %s;" % PKG, "public final class R {"]
    n = 1
    for kind in sorted(res):
        lines.append("    public static final class %s {" % kind)
        for name in sorted(res[kind]):
            lines.append("        public static final int %s = 0x7f%02x%04x;" % (
                name.replace(".", "_"), list(sorted(res)).index(kind) + 1, n))
            n += 1
        lines.append("    }")
    lines.append("}")
    with open(os.path.join(out, "R.java"), "w") as fh:
        fh.write("\n".join(lines) + "\n")
    print("stub R.java written")

print("resources:", {k: len(v) for k, v in res.items() if v})
if errors:
    print("FAILED: %d problem(s)" % len(errors))
    sys.exit(1)
print("resource checks passed")
