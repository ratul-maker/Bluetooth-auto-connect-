package com.btearbuds.autoconnect.logic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Builds the connection-history timeline from stored sessions and the stored "observation
 * windows" (the periods when the app was actually running and watching Bluetooth).
 *
 * The point is honesty: a session only counts as fully recorded when the app saw both its start
 * and its end happen. Time between sessions is split into the part the app really observed and
 * the part it could not observe, because it was not running, so nothing is known about it.
 * Nothing here estimates or fills in missing data. Pure Java, no Android.
 */
public final class SessionTimeline {

    private SessionTimeline() {
    }

    public static final class Session {
        public final String name;
        public final long start;
        /** 0 while the session is still open. */
        public final long end;
        /** The app saw the connection start happen (false = it was already connected when first seen). */
        public final boolean startExact;
        /** The app saw the disconnect happen (false = the app stopped watching while connected). */
        public final boolean endExact;

        public Session(String name, long start, long end, boolean startExact, boolean endExact) {
            this.name = name;
            this.start = start;
            this.end = end;
            this.startExact = startExact;
            this.endExact = endExact;
        }

        public boolean isOpen() {
            return end <= 0L;
        }

        /** Observed length; for sessions with an unobserved end this is a lower bound. */
        public long durationMs(long now) {
            long e = isOpen() ? now : end;
            return Math.max(0L, e - start);
        }

        /** Both ends seen live (an open session only needs its start). */
        public boolean fullyRecorded() {
            return startExact && (isOpen() || endExact);
        }
    }

    public static final class Window {
        public final long start;
        /** 0 while the window is still open (the app is watching right now). */
        public final long end;

        public Window(long start, long end) {
            this.start = start;
            this.end = end;
        }
    }

    public static final class Item {
        /** Non-null for a session row, null for a gap row. */
        public final Session session;
        public final long gapStart;
        public final long gapEnd;
        public final long unobservedMs;

        Item(Session session, long gapStart, long gapEnd, long unobservedMs) {
            this.session = session;
            this.gapStart = gapStart;
            this.gapEnd = gapEnd;
            this.unobservedMs = unobservedMs;
        }

        public boolean isGap() {
            return session == null;
        }

        public long gapMs() {
            return gapEnd - gapStart;
        }

        public long observedMs() {
            return Math.max(0L, gapMs() - unobservedMs);
        }
    }

    /** How much of [from, to] was covered by observation windows (overlaps are not double counted). */
    public static long coveredMs(List<Window> windows, long from, long to, long now) {
        if (to <= from || windows == null || windows.isEmpty()) {
            return 0L;
        }
        List<long[]> clipped = new ArrayList<long[]>();
        for (Window w : windows) {
            long s = Math.max(w.start, from);
            long e = Math.min(w.end <= 0L ? now : w.end, to);
            if (e > s) {
                clipped.add(new long[]{s, e});
            }
        }
        if (clipped.isEmpty()) {
            return 0L;
        }
        long[][] arr = clipped.toArray(new long[0][]);
        Arrays.sort(arr, new Comparator<long[]>() {
            @Override
            public int compare(long[] a, long[] b) {
                return a[0] < b[0] ? -1 : (a[0] > b[0] ? 1 : 0);
            }
        });
        long total = 0L;
        long curS = arr[0][0];
        long curE = arr[0][1];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i][0] <= curE) {
                curE = Math.max(curE, arr[i][1]);
            } else {
                total += curE - curS;
                curS = arr[i][0];
                curE = arr[i][1];
            }
        }
        total += curE - curS;
        return total;
    }

    /**
     * @param newestFirst sessions, newest first
     * @param minGapMs    gaps shorter than this are not shown
     * @return session rows with a gap row between two sessions whenever time passed between them
     */
    public static List<Item> build(List<Session> newestFirst, List<Window> windows, long now,
                                   long minGapMs) {
        List<Item> out = new ArrayList<Item>();
        for (int i = 0; i < newestFirst.size(); i++) {
            Session s = newestFirst.get(i);
            out.add(new Item(s, 0L, 0L, 0L));
            if (i + 1 < newestFirst.size()) {
                Session older = newestFirst.get(i + 1);
                long gapStart = older.isOpen() ? older.start : older.end;
                long gapEnd = s.start;
                if (gapEnd - gapStart >= minGapMs) {
                    long covered = coveredMs(windows, gapStart, gapEnd, now);
                    out.add(new Item(null, gapStart, gapEnd, (gapEnd - gapStart) - covered));
                }
            }
        }
        return out;
    }
}
