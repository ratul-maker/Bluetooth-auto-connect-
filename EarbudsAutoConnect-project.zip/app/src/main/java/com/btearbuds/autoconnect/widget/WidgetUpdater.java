package com.btearbuds.autoconnect.widget;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;

import com.btearbuds.autoconnect.bt.BtController;
import com.btearbuds.autoconnect.bt.Snapshot;
import com.btearbuds.autoconnect.bt.StatusText;
import com.btearbuds.autoconnect.logic.WidgetModel;

/**
 * Keeps home-screen widgets in step with what the app really knows.
 *
 * Android widgets cannot watch Bluetooth by themselves, so the app pushes an update only when
 * something actually changed (connection, battery, selected device) and only while it is
 * running. The system's own periodic refresh is the 30 minute minimum Android allows; the app
 * adds no timers, alarms or polling for widgets. The running timer on the widget is a system
 * Chronometer, so it keeps counting without any updates from the app.
 */
public final class WidgetUpdater {

    private static String lastKey;

    private WidgetUpdater() {
    }

    /** Called by the Bluetooth controller whenever its state is published. */
    public static void onSnapshot(Context ctx, Snapshot s, boolean observing) {
        Context app = ctx.getApplicationContext();
        WidgetModel m = modelOf(s, observing);
        String key = keyOf(m);
        if (key.equals(lastKey)) {
            return;
        }
        lastKey = key;
        WidgetState.save(app, m, m.updatedAt);
        render(app, m);
    }

    /** The app stopped watching: from now on the widgets show "last known", not live data. */
    public static void onObservingStopped(Context ctx, long now) {
        Context app = ctx.getApplicationContext();
        WidgetState.touch(app, now);
        lastKey = null;
        render(app, WidgetState.load(app, false));
    }

    /** Heartbeat: remembers "the app was still watching at this moment". Does not redraw. */
    public static void touch(Context ctx, long now) {
        WidgetState.touch(ctx.getApplicationContext(), now);
    }

    /** From the widget's own update callback (system refresh, new widget, boot). */
    public static void refresh(Context ctx) {
        Context app = ctx.getApplicationContext();
        lastKey = null;
        render(app, WidgetState.load(app, BtController.isObserving()));
    }

    private static WidgetModel modelOf(Snapshot s, boolean observing) {
        int single = s.batSingle != null && s.batLive ? s.batSingle.intValue() : -1;
        String detail = null;
        if (single < 0 && s.batLive && (s.batLeft != null || s.batRight != null)) {
            StringBuilder b = new StringBuilder();
            if (s.batLeft != null) {
                b.append("L ").append(s.batLeft).append("%");
            }
            if (s.batRight != null) {
                if (b.length() > 0) {
                    b.append(" · ");
                }
                b.append("R ").append(s.batRight).append("%");
            }
            detail = b.toString();
        }
        return WidgetModel.from(s.deviceAddress != null, s.deviceName,
                StatusText.label(s),
                StatusText.tone(s), s.isConnected(),
                s.connectedSince, s.connectedSinceExact, single, detail, observing,
                System.currentTimeMillis());
    }

    private static String keyOf(WidgetModel m) {
        return m.mode + "|" + m.name + "|" + m.statusLabel + "|" + m.tone + "|" + m.connected
                + "|" + m.connectedSince + "|" + m.sinceExact + "|" + m.batteryPercent + "|"
                + m.batteryDetail;
    }

    private static int[] ids(AppWidgetManager mgr, Context ctx, Class<?> provider) {
        return mgr.getAppWidgetIds(new ComponentName(ctx, provider));
    }

    private static void render(Context app, WidgetModel m) {
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(app);
            if (mgr == null) {
                return;
            }
            int[] compact = ids(mgr, app, CompactWidgetProvider.class);
            if (compact.length > 0) {
                mgr.updateAppWidget(compact, WidgetRenderer.compact(app, m));
            }
            int[] expanded = ids(mgr, app, ExpandedWidgetProvider.class);
            if (expanded.length > 0) {
                mgr.updateAppWidget(expanded, WidgetRenderer.expanded(app, m));
            }
        } catch (RuntimeException e) {
            // A widget problem must never take the app down.
        }
    }
}
