package com.btearbuds.autoconnect.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.TypedValue;
import android.view.View;

import com.btearbuds.autoconnect.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Plots real stored readings only (no smoothing, no prediction). */
public final class LineChartView extends View {

    private long[] times = new long[0];
    private int[] levels = new int[0];
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);

    public LineChartView(Context c) {
        super(c);
        grid.setColor(c.getColor(R.color.outline));
        grid.setStrokeWidth(Ui.dp(c, 1));
        line.setColor(c.getColor(R.color.primary));
        line.setStrokeWidth(Ui.dp(c, 2.5f));
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        dot.setColor(c.getColor(R.color.primary));
        label.setColor(c.getColor(R.color.text_secondary));
        label.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 11,
                c.getResources().getDisplayMetrics()));
    }

    public void setData(long[] t, int[] v) {
        times = t;
        levels = v;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        setMeasuredDimension(resolveSize(Ui.dp(getContext(), 200), widthSpec),
                resolveSize(Ui.dp(getContext(), 170), heightSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Context c = getContext();
        float left = Ui.dp(c, 38);
        float right = getWidth() - Ui.dp(c, 8);
        float top = Ui.dp(c, 8);
        float bottom = getHeight() - Ui.dp(c, 24);
        float h = bottom - top;

        int[] marks = {0, 50, 100};
        for (int i = 0; i < marks.length; i++) {
            float y = bottom - h * marks[i] / 100f;
            canvas.drawLine(left, y, right, y, grid);
            canvas.drawText(marks[i] + "%", Ui.dp(c, 2), y + label.getTextSize() / 3f, label);
        }
        int n = Math.min(times.length, levels.length);
        if (n < 2) {
            return;
        }
        long t0 = times[0];
        long t1 = times[n - 1];
        long span = Math.max(1L, t1 - t0);

        float px = 0;
        float py = 0;
        for (int i = 0; i < n; i++) {
            float x = left + (right - left) * (times[i] - t0) / (float) span;
            float y = bottom - h * Math.max(0, Math.min(100, levels[i])) / 100f;
            if (i > 0) {
                canvas.drawLine(px, py, x, y, line);
            }
            canvas.drawCircle(x, y, Ui.dp(c, 3), dot);
            px = x;
            py = y;
        }
        String pattern = span > 20L * 60L * 60L * 1000L ? "MMM d HH:mm" : "HH:mm";
        SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.getDefault());
        String a = f.format(new Date(t0));
        String b = f.format(new Date(t1));
        float ty = getHeight() - Ui.dp(c, 6);
        canvas.drawText(a, left, ty, label);
        canvas.drawText(b, right - label.measureText(b), ty, label);
    }
}
