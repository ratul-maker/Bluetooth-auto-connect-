package com.btearbuds.autoconnect.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

import com.btearbuds.autoconnect.R;

/**
 * A small equalizer-style indicator for the "audio is streaming to the earbuds" state.
 *
 * It does NOT show the music: Android does not give apps the sound level. The bars dance only while
 * Android reports that audio is streaming, and sit flat and dim otherwise. Animation runs only
 * while the screen is in front and Android's animations are on.
 */
public final class EqBarsView extends View {

    private static final int BARS = 7;
    private static final long PERIOD_MS = 1800L;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final int cyan;
    private final int purple;
    private boolean streaming;
    private boolean running = true;
    private float phase;
    private ValueAnimator anim;

    public EqBarsView(Context c) {
        super(c);
        cyan = c.getColor(R.color.primary);
        purple = c.getColor(R.color.accent);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    public void setStreaming(boolean streaming) {
        if (this.streaming != streaming) {
            this.streaming = streaming;
            updateAnimation();
            invalidate();
        }
    }

    /** The activity calls this from onResume/onPause so nothing animates in the background. */
    public void setRunning(boolean running) {
        this.running = running;
        updateAnimation();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        setMeasuredDimension(resolveSize(Ui.dp(getContext(), 54), widthSpec),
                resolveSize(Ui.dp(getContext(), 34), heightSpec));
    }

    private boolean shouldAnimate() {
        return running && streaming && isAttachedToWindow() && isShown()
                && ValueAnimator.areAnimatorsEnabled();
    }

    private void updateAnimation() {
        if (shouldAnimate()) {
            if (anim == null) {
                anim = ValueAnimator.ofFloat(0f, 1f);
                anim.setDuration(PERIOD_MS);
                anim.setInterpolator(new LinearInterpolator());
                anim.setRepeatCount(ValueAnimator.INFINITE);
                anim.addUpdateListener(a -> {
                    phase = (Float) a.getAnimatedValue();
                    invalidate();
                });
            }
            if (!anim.isStarted()) {
                anim.start();
            }
        } else if (anim != null) {
            anim.cancel();
            phase = 0f;
            invalidate();
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        updateAnimation();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.cancel();
            anim = null;
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        updateAnimation();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        updateAnimation();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float gap = Ui.dp(getContext(), 3);
        float bw = (w - gap * (BARS - 1)) / BARS;
        if (bw <= 0f) {
            return;
        }
        boolean dancing = anim != null && anim.isRunning();
        for (int i = 0; i < BARS; i++) {
            float level;
            if (streaming && dancing) {
                // whole-number multiples of the phase, so the loop restarts without a jump
                int k = 1 + (i % 3);
                level = 0.2f + 0.8f * (0.5f + 0.5f * (float) Math.sin(
                        phase * 6.2832f * k + i * 1.3f));
            } else if (streaming) {
                level = 0.5f;
            } else {
                level = 0.14f;
            }
            float t = i / (float) (BARS - 1);
            int color = blend(cyan, purple, t);
            paint.setColor((color & 0x00FFFFFF) | ((streaming ? 0xFF : 0x5A) << 24));
            float left = i * (bw + gap);
            rect.set(left, h - level * h, left + bw, h);
            canvas.drawRoundRect(rect, bw / 2f, bw / 2f, paint);
        }
    }

    private static int blend(int a, int b, float t) {
        int r = (int) (((a >> 16) & 0xFF) * (1f - t) + ((b >> 16) & 0xFF) * t);
        int g = (int) (((a >> 8) & 0xFF) * (1f - t) + ((b >> 8) & 0xFF) * t);
        int bl = (int) ((a & 0xFF) * (1f - t) + (b & 0xFF) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
