package com.btearbuds.autoconnect.widget;

import android.content.Context;
import android.content.SharedPreferences;

import com.btearbuds.autoconnect.data.Prefs;
import com.btearbuds.autoconnect.logic.WidgetModel;

/**
 * The last state the app really saw, stored so home-screen widgets can show it even when the app
 * is not running. Widgets never read Bluetooth themselves. When the app is not watching, the
 * stored values are shown as "last known" (see {@link WidgetModel}).
 */
final class WidgetState {

    private static final String FILE = "widget_state";

    private WidgetState() {
    }

    private static SharedPreferences sp(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /** Stores what a live model shows. Nothing is invented: the model already holds real values. */
    static void save(Context ctx, WidgetModel m, long now) {
        sp(ctx).edit()
                .putBoolean("saved", true)
                .putBoolean("has_device", m.mode != WidgetModel.Mode.NO_DEVICE)
                .putString("name", m.name)
                .putString("label", m.statusLabel)
                .putInt("tone", m.tone)
                .putBoolean("connected", m.connected)
                .putLong("since", m.connectedSince)
                .putBoolean("since_exact", m.sinceExact)
                .putInt("battery", m.batteryPercent)
                .putString("detail", m.batteryDetail)
                .putLong("updated", now)
                .apply();
    }

    static void touch(Context ctx, long now) {
        SharedPreferences p = sp(ctx);
        if (p.getBoolean("saved", false)) {
            p.edit().putLong("updated", now).apply();
        }
    }

    static WidgetModel load(Context ctx, boolean observing) {
        SharedPreferences p = sp(ctx);
        if (!p.getBoolean("saved", false)) {
            // The app has not recorded anything yet (for example right after an update).
            Prefs prefs = new Prefs(ctx);
            boolean has = prefs.preferredAddress() != null;
            return WidgetModel.from(has, prefs.preferredName(), "Open the app to refresh",
                    WidgetModel.TONE_IDLE, false, 0L, false, -1, null, observing, 0L);
        }
        return WidgetModel.from(p.getBoolean("has_device", false), p.getString("name", null),
                p.getString("label", ""), p.getInt("tone", WidgetModel.TONE_IDLE),
                p.getBoolean("connected", false), p.getLong("since", 0L),
                p.getBoolean("since_exact", false), p.getInt("battery", -1),
                p.getString("detail", null), observing, p.getLong("updated", 0L));
    }
}
