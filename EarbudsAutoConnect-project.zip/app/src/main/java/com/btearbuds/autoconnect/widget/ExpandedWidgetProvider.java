package com.btearbuds.autoconnect.widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

/** The larger home-screen widget. All drawing is done by {@link WidgetUpdater}. */
public final class ExpandedWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        WidgetUpdater.refresh(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager mgr, int id,
                                          android.os.Bundle newOptions) {
        WidgetUpdater.refresh(context);
    }
}
