package com.btearbuds.autoconnect.treble;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.Equalizer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Applies the treble setting through Android's audio equalizer effect.
 *
 * What this can and cannot know (and the UI says so):
 *  - It CAN check that Android accepted the settings: after writing the band levels it reads them
 *    back, and checks the effect is enabled and that this app has control of it.
 *  - It CANNOT hear or measure sound. Whether the system, a music app or the earbuds' own
 *    processing actually honour the effect is up to the phone. So "applied" here always means
 *    "accepted by Android", never "you will hear it".
 *
 * Two kinds of targets are used:
 *  - the global output mix (audio session 0), which some phones honour and others ignore;
 *  - the audio session of any music app that announces it (the standard
 *    ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION broadcast, sent by apps that support equalizers).
 *
 * Everything runs on the main thread. No Bluetooth code is used here: treble is independent of the
 * Bluetooth connection tracking.
 */
public final class TrebleEngine {

    public interface Listener {
        void onTrebleStatus(Status status);
    }

    /** What the phone's equalizer offers. */
    public static final class Capability {
        public final boolean present;
        public final int[] centerHz;
        public final int minMb;
        public final int maxMb;
        /** Whole-dB range the user may choose, or null if the equalizer can't do a useful treble change. */
        public final int[] rangeDb;
        /** Plain-language reason it can't be used, or null if usable. */
        public final String problem;

        Capability(boolean present, int[] centerHz, int minMb, int maxMb, int[] rangeDb,
                   String problem) {
            this.present = present;
            this.centerHz = centerHz;
            this.minMb = minMb;
            this.maxMb = maxMb;
            this.rangeDb = rangeDb;
            this.problem = problem;
        }

        public boolean usable() {
            return problem == null;
        }
    }

    /** A live picture of what is applied. */
    public static final class Status {
        public final boolean running;
        public final double db;
        public final boolean globalTried;
        public final boolean globalVerified;
        public final String globalProblem;
        public final int appSessions;
        public final int appSessionsVerified;
        public final boolean controlLost;

        Status(boolean running, double db, boolean globalTried, boolean globalVerified,
               String globalProblem, int appSessions, int appSessionsVerified, boolean controlLost) {
            this.running = running;
            this.db = db;
            this.globalTried = globalTried;
            this.globalVerified = globalVerified;
            this.globalProblem = globalProblem;
            this.appSessions = appSessions;
            this.appSessionsVerified = appSessionsVerified;
            this.controlLost = controlLost;
        }

        /** True when Android accepted the settings on at least one target. */
        public boolean applied() {
            return running && (globalVerified || appSessionsVerified > 0);
        }

        public String headline() {
            if (!running) {
                return "Off";
            }
            if (!applied()) {
                return "Not applied";
            }
            return "Accepted by Android";
        }
    }

    private static final class Target {
        final int session;
        Equalizer eq;
        boolean verified;
        boolean controlLost;
        String problem;

        Target(int session) {
            this.session = session;
        }
    }

    private static TrebleEngine instance;

    public static synchronized TrebleEngine get(Context context) {
        if (instance == null) {
            instance = new TrebleEngine(context.getApplicationContext());
        }
        return instance;
    }

    private static final int VERIFY_TOLERANCE_MB = 50;

    private final Context app;
    private final TreblePrefs prefs;
    private final List<Listener> listeners = new CopyOnWriteArrayList<Listener>();
    private final Map<Integer, Target> appTargets = new HashMap<Integer, Target>();
    private Target global;
    private boolean globalTried;
    private boolean running;
    private boolean receiverRegistered;
    private Capability capability;

    private TrebleEngine(Context appContext) {
        this.app = appContext;
        this.prefs = new TreblePrefs(appContext);
    }

    public void addListener(Listener l) {
        if (!listeners.contains(l)) {
            listeners.add(l);
        }
    }

    public void removeListener(Listener l) {
        listeners.remove(l);
    }

    // ------------------------------------------------------------------ capability

    /**
     * Asks the phone what its equalizer can do, using a throw-away audio session (nothing audible
     * is touched). The answer is cached for the life of the process.
     */
    public synchronized Capability capability() {
        if (capability == null) {
            capability = probe();
        }
        return capability;
    }

    private Capability probe() {
        boolean listed = false;
        try {
            AudioEffect.Descriptor[] all = AudioEffect.queryEffects();
            if (all != null) {
                for (AudioEffect.Descriptor d : all) {
                    if (AudioEffect.EFFECT_TYPE_EQUALIZER.equals(d.type)) {
                        listed = true;
                        break;
                    }
                }
            }
        } catch (RuntimeException e) {
            // fall through to the direct test below
        }
        AudioManager am = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
        Equalizer eq = null;
        try {
            int session = am != null ? am.generateAudioSessionId() : 0;
            if (session <= 0) {
                return new Capability(listed, null, 0, 0, null,
                        "Android could not create an audio session to test the equalizer.");
            }
            eq = new Equalizer(0, session);
            short bands = eq.getNumberOfBands();
            int[] hz = new int[bands];
            for (short b = 0; b < bands; b++) {
                hz[b] = eq.getCenterFreq(b) / 1000;
            }
            short[] range = eq.getBandLevelRange();
            int min = range[0];
            int max = range[1];
            int[] rangeDb = TrebleMath.usableRangeDb(min, max);
            if (bands < 1 || !TrebleMath.hasTrebleBand(hz)) {
                return new Capability(true, hz, min, max, rangeDb,
                        "This phone's equalizer has no band above 3 kHz, so it cannot change treble.");
            }
            if (rangeDb == null) {
                return new Capability(true, hz, min, max, null,
                        "This phone's equalizer cannot move a band by at least 1 dB each way.");
            }
            return new Capability(true, hz, min, max, rangeDb, null);
        } catch (RuntimeException e) {
            return new Capability(listed, null, 0, 0, null, listed
                    ? "The equalizer exists but Android refused to open it (" + e.getClass()
                    .getSimpleName() + ")."
                    : "This phone does not offer an audio equalizer effect to apps.");
        } finally {
            if (eq != null) {
                try {
                    eq.release();
                } catch (RuntimeException e) {
                    // ignore
                }
            }
        }
    }

    // ------------------------------------------------------------------ lifecycle

    /** Starts applying the saved setting. Safe to call again. */
    public void start() {
        if (running) {
            reapply();
            return;
        }
        running = true;
        registerReceiver();
        global = null;
        globalTried = false;
        reapply();
    }

    /** Stops: sets the bands flat, releases every effect and unregisters. The sound goes back to normal. */
    public void stop() {
        if (!running && global == null && appTargets.isEmpty()) {
            return;
        }
        running = false;
        unregisterReceiver();
        if (global != null) {
            releaseTarget(global);
            global = null;
        }
        for (Target t : appTargets.values()) {
            releaseTarget(t);
        }
        appTargets.clear();
        globalTried = false;
        notifyListeners();
    }

    public boolean isRunning() {
        return running;
    }

    /** Re-applies the saved dB to every target (after the dial or a preset changed). */
    public void reapply() {
        if (!running) {
            notifyListeners();
            return;
        }
        Capability cap = capability();
        if (!cap.usable()) {
            globalTried = true;
            notifyListeners();
            return;
        }
        double db = TrebleMath.clamp(prefs.db(), cap.rangeDb);
        if (global == null) {
            global = open(0);
            globalTried = true;
        }
        applyTo(global, cap, db);
        List<Integer> dead = new ArrayList<Integer>();
        for (Target t : appTargets.values()) {
            applyTo(t, cap, db);
            if (t.eq == null) {
                dead.add(Integer.valueOf(t.session));
            }
        }
        for (Integer id : dead) {
            appTargets.remove(id);
        }
        notifyListeners();
    }

    // ------------------------------------------------------------------ one equalizer

    private Target open(int session) {
        Target t = new Target(session);
        try {
            final Target target = t;
            Equalizer eq = new Equalizer(0, session);
            eq.setControlStatusListener(new AudioEffect.OnControlStatusChangeListener() {
                @Override
                public void onControlStatusChange(AudioEffect effect, boolean controlGranted) {
                    target.controlLost = !controlGranted;
                    if (!controlGranted) {
                        target.verified = false;
                    }
                    notifyListeners();
                }
            });
            t.eq = eq;
        } catch (RuntimeException e) {
            t.eq = null;
            t.problem = describe(e);
        }
        return t;
    }

    private static String describe(RuntimeException e) {
        if (e instanceof SecurityException) {
            return "Android denied permission to use the equalizer.";
        }
        if (e instanceof UnsupportedOperationException) {
            return "This phone does not allow apps to attach an equalizer here.";
        }
        if (e instanceof IllegalArgumentException) {
            return "Android rejected the equalizer request.";
        }
        return "Android could not start the equalizer (" + e.getClass().getSimpleName() + ").";
    }

    private void applyTo(Target t, Capability cap, double db) {
        t.verified = false;
        if (t.eq == null) {
            return;
        }
        try {
            int[] levels = TrebleMath.bandLevelsMb(cap.centerHz, db, cap.minMb, cap.maxMb);
            for (int b = 0; b < levels.length; b++) {
                t.eq.setBandLevel((short) b, (short) levels[b]);
            }
            int status = t.eq.setEnabled(true);
            boolean ok = status == AudioEffect.SUCCESS && t.eq.getEnabled() && t.eq.hasControl();
            for (int b = 0; ok && b < levels.length; b++) {
                int back = t.eq.getBandLevel((short) b);
                if (Math.abs(back - levels[b]) > VERIFY_TOLERANCE_MB) {
                    ok = false;
                    t.problem = "Android did not keep the setting (it reported a different value "
                            + "when asked).";
                }
            }
            if (!t.eq.hasControl()) {
                t.controlLost = true;
                t.problem = "Another app or the system has taken over this equalizer.";
                ok = false;
            } else {
                t.controlLost = false;
            }
            if (ok) {
                t.problem = null;
            } else if (t.problem == null) {
                t.problem = "Android did not confirm that the equalizer is on.";
            }
            t.verified = ok;
        } catch (RuntimeException e) {
            // IllegalStateException: effect was released by the system; others: bad request.
            t.verified = false;
            t.problem = describe(e);
            releaseQuietly(t);
        }
    }

    private void releaseTarget(Target t) {
        if (t.eq != null) {
            try {
                // Put the bands flat first so nothing lingers if the system keeps the effect around.
                Capability cap = capability;
                if (cap != null && cap.centerHz != null) {
                    for (short b = 0; b < cap.centerHz.length; b++) {
                        t.eq.setBandLevel(b, (short) 0);
                    }
                }
                t.eq.setEnabled(false);
            } catch (RuntimeException e) {
                // ignore: we are releasing anyway
            }
        }
        releaseQuietly(t);
    }

    private static void releaseQuietly(Target t) {
        if (t.eq != null) {
            try {
                t.eq.setControlStatusListener(null);
                t.eq.release();
            } catch (RuntimeException e) {
                // ignore
            }
            t.eq = null;
        }
    }

    // ------------------------------------------------------------------ app audio sessions

    private final BroadcastReceiver sessionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!running || intent == null) {
                return;
            }
            int session = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1);
            if (session <= 0) {
                return;
            }
            String action = intent.getAction();
            if (AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION.equals(action)) {
                if (!appTargets.containsKey(Integer.valueOf(session))) {
                    Capability cap = capability();
                    Target t = open(session);
                    appTargets.put(Integer.valueOf(session), t);
                    if (cap.usable()) {
                        applyTo(t, cap, TrebleMath.clamp(prefs.db(), cap.rangeDb));
                    }
                    notifyListeners();
                }
            } else if (AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION.equals(action)) {
                Target t = appTargets.remove(Integer.valueOf(session));
                if (t != null) {
                    releaseTarget(t);
                    notifyListeners();
                }
            }
        }
    };

    private void registerReceiver() {
        if (receiverRegistered) {
            return;
        }
        IntentFilter f = new IntentFilter();
        f.addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION);
        f.addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION);
        app.registerReceiver(sessionReceiver, f);
        receiverRegistered = true;
    }

    private void unregisterReceiver() {
        if (receiverRegistered) {
            try {
                app.unregisterReceiver(sessionReceiver);
            } catch (IllegalArgumentException e) {
                // already gone
            }
            receiverRegistered = false;
        }
    }

    // ------------------------------------------------------------------ status

    public Status status() {
        boolean globalOk = global != null && global.verified;
        String globalProblem = null;
        if (globalTried && !globalOk) {
            Capability cap = capability;
            if (cap != null && !cap.usable()) {
                globalProblem = cap.problem;
            } else if (global != null) {
                globalProblem = global.problem;
            }
        }
        int verified = 0;
        boolean lost = global != null && global.controlLost;
        for (Iterator<Target> it = appTargets.values().iterator(); it.hasNext(); ) {
            Target t = it.next();
            if (t.verified) {
                verified++;
            }
            if (t.controlLost) {
                lost = true;
            }
        }
        double db = prefs.db();
        Capability cap = capability;
        if (cap != null && cap.rangeDb != null) {
            db = TrebleMath.clamp(db, cap.rangeDb);
        }
        return new Status(running, db, globalTried, globalOk, globalProblem, appTargets.size(),
                verified, lost);
    }

    private void notifyListeners() {
        Status s = status();
        for (Listener l : listeners) {
            l.onTrebleStatus(s);
        }
    }
}
