package com.btearbuds.autoconnect.bt;

import android.bluetooth.BluetoothDevice;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

/**
 * The compatibility engine: for this phone's Android version and the selected earbuds, which
 * features genuinely work. Every row is derived from live state or documented Android limits;
 * nothing is shown as working unless it can be observed.
 */
public final class Compat {

    public enum Level {
        SUPPORTED("Supported"), PARTIAL("Partly"), UNAVAILABLE("Unavailable"), UNKNOWN("Not known yet");

        public final String label;

        Level(String label) {
            this.label = label;
        }
    }

    public static final class Row {
        public final String title;
        public final Level level;
        public final String detail;

        Row(String title, Level level, String detail) {
            this.title = title;
            this.level = level;
            this.detail = detail;
        }
    }

    private Compat() {
    }

    public static List<Row> evaluate(Snapshot s, boolean ignoringBatteryOptimizations) {
        List<Row> r = new ArrayList<Row>();
        boolean hasDevice = s.deviceAddress != null;

        r.add(new Row("Bluetooth adapter",
                s.adapterPresent ? Level.SUPPORTED : Level.UNAVAILABLE,
                s.adapterPresent ? (s.adapterOn ? "Present and on." : "Present, currently off.")
                        : "Android reports no Bluetooth adapter."));

        r.add(new Row("Paired device list", Level.SUPPORTED,
                "Uses Android's list of already-paired devices. The app never scans or pairs."));

        r.add(new Row("Event detection (connect / disconnect / Bluetooth on-off)", Level.SUPPORTED,
                "Uses Android's Bluetooth broadcasts, so no polling is needed."));

        // connection state
        if (!hasDevice) {
            r.add(new Row("Music connection status", Level.UNKNOWN, "Choose earbuds first."));
            r.add(new Row("Call connection status", Level.UNKNOWN, "Choose earbuds first."));
        } else {
            r.add(new Row("Music connection status (A2DP)",
                    s.a2dpProxyReady ? Level.SUPPORTED : (s.adapterOn ? Level.UNKNOWN : Level.UNAVAILABLE),
                    s.a2dpProxyReady ? "Read directly from Android."
                            : (s.adapterOn ? "Waiting for Android's audio service."
                            : "Turn Bluetooth on.")));
            r.add(new Row("Call connection status (hands-free)",
                    s.hfpProxyReady ? Level.SUPPORTED : (s.adapterOn ? Level.UNKNOWN : Level.UNAVAILABLE),
                    s.hfpProxyReady ? "Read directly from Android."
                            : (s.adapterOn ? "Waiting for Android's audio service."
                            : "Turn Bluetooth on.")));
        }

        // starting a connection
        if (!hasDevice) {
            r.add(new Row("Start a connection from this app", Level.UNKNOWN, "Choose earbuds first."));
        } else if (s.deviceTypeCode == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
            r.add(new Row("Start a connection from this app", Level.UNAVAILABLE,
                    "Your earbuds use classic Bluetooth only. Android 11 has no public API that lets "
                            + "an app start that connection. The app still detects when they connect."));
        } else if (s.deviceTypeCode == BluetoothDevice.DEVICE_TYPE_UNKNOWN) {
            r.add(new Row("Start a connection from this app", Level.PARTIAL,
                    "Android hasn't said whether the earbuds support Bluetooth LE. The app sends a "
                            + "request and checks the real result; it may not work."));
        } else {
            r.add(new Row("Start a connection from this app", Level.PARTIAL,
                    "Best effort only: Android 11 has no direct connect API for apps. The app sends "
                            + "a Bluetooth LE request, then verifies the real connection state. Some "
                            + "earbuds ignore it."));
        }

        r.add(new Row("Disconnect from this app", Level.UNAVAILABLE,
                "Android 11 offers no public API to disconnect a headset. Turn the earbuds off or "
                        + "use Bluetooth settings."));

        // audio route
        if (Build.VERSION.SDK_INT >= 28) {
            r.add(new Row("Is music really routed to the earbuds?", Level.SUPPORTED,
                    "Android lists audio outputs with their addresses, so this can be checked."));
        } else {
            r.add(new Row("Is music really routed to the earbuds?", Level.PARTIAL,
                    "On this Android version the app can see that a Bluetooth output exists, but not "
                            + "which device owns it."));
        }

        // battery
        r.add(batteryReport(s, hasDevice));
        r.add(batteryGatt(s, hasDevice));

        r.add(new Row("Separate left / right earbud battery", Level.UNAVAILABLE,
                "Android 11 has no public API for this, and earbud makers use private protocols. "
                        + "The app never guesses or splits a single value into two."));
        r.add(new Row("Charging-case battery", Level.UNAVAILABLE,
                "Deliberately never shown, so it can't be mistaken for an earbud level."));

        r.add(new Row("Quick Settings tile", Level.SUPPORTED,
                "Add it from the Quick Settings edit screen (the pencil icon)."));

        r.add(new Row("Background monitoring",
                ignoringBatteryOptimizations ? Level.SUPPORTED : Level.PARTIAL,
                ignoringBatteryOptimizations
                        ? "Runs as a visible foreground service. Phone-maker restrictions can still "
                        + "stop any app, so check the Settings screen if it stops."
                        : "Runs as a visible foreground service, but battery optimisation is active "
                        + "for this app. XOS may stop it - see Settings > Keep it running."));
        return r;
    }

    private static Row batteryReport(Snapshot s, boolean hasDevice) {
        String title = "Battery from Android / headset report";
        if (!hasDevice) {
            return new Row(title, Level.UNKNOWN, "Choose earbuds first.");
        }
        if (s.batLive && s.batSource != null && !s.batSource.startsWith("Standard")) {
            return new Row(title, Level.SUPPORTED,
                    "Your earbuds sent a battery level this connection (" + s.batSource + ").");
        }
        if (!s.isConnected()) {
            return new Row(title, Level.UNKNOWN, "Connect the earbuds to find out.");
        }
        return new Row(title, Level.PARTIAL,
                "Only works if the earbuds send a battery level to the phone. Many don't, and "
                        + "none has arrived yet this connection.");
    }

    private static Row batteryGatt(Snapshot s, boolean hasDevice) {
        String title = "Battery from standard Bluetooth LE service";
        if (!hasDevice) {
            return new Row(title, Level.UNKNOWN, "Choose earbuds first.");
        }
        if (s.deviceTypeCode == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
            return new Row(title, Level.UNAVAILABLE, "Classic-only earbuds have no LE services.");
        }
        switch (s.batProbeState) {
            case 3:
                return new Row(title, Level.SUPPORTED, "A level was read from the earbuds.");
            case 2:
                return new Row(title, Level.UNAVAILABLE,
                        "Checked: the earbuds don't offer one readable standard battery service.");
            case 4:
                return new Row(title, Level.UNKNOWN,
                        "The check couldn't open a Bluetooth LE link to the earbuds, so it's unknown "
                                + "whether they offer a battery service.");
            case 1:
                return new Row(title, Level.UNKNOWN, "Checking now...");
            default:
                return new Row(title, Level.UNKNOWN,
                        s.isConnected() ? "Will be checked shortly after connecting."
                                : "Connect the earbuds to check.");
        }
    }
}
