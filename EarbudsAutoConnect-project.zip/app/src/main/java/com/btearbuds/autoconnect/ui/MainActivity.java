package com.btearbuds.autoconnect.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.bt.AudioRoute;
import com.btearbuds.autoconnect.bt.BtController;
import com.btearbuds.autoconnect.bt.Diagnostics;
import com.btearbuds.autoconnect.bt.Snapshot;
import com.btearbuds.autoconnect.bt.StatusText;
import com.btearbuds.autoconnect.data.Prefs;
import com.btearbuds.autoconnect.logic.DurationFormat;
import com.btearbuds.autoconnect.service.MonitorService;

import java.util.ArrayList;
import java.util.List;

/**
 * The live dashboard: connection orb, running connection timer, exact connected-since time,
 * battery (only when the earbuds really report it) and the main controls.
 */
public final class MainActivity extends Activity implements BtController.Listener {

    public static final String EXTRA_CONNECT = "connect";

    private static final long AUDIO_SETTLE_MS = 6000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private BtController controller;
    private Prefs prefs;
    private boolean holding;
    private boolean resumed;
    private boolean pendingConnect;
    private Snapshot lastSnap;

    // hero card
    private LinearLayout heroCard;
    private StatusOrbView orb;
    private TextView timerText;
    private TextView timerCaption;
    private TextView deviceName;
    private LinearLayout statusRow;
    private View statusDot;
    private TextView statusText;
    private TextView deviceInfo;
    private TextView sinceValue;
    private TextView sinceNote;
    private LinearLayout statsRow;
    private BatteryRingView ringA;
    private BatteryRingView ringB;
    private TextView ringLabelA;
    private TextView ringLabelB;
    private TextView batHeroText;
    private TextView hintText;
    private Button hintButton;
    private Button pickButton;
    private Button clearButton;
    private StatusText.Hint currentHint;

    // audio warning
    private LinearLayout audioCard;

    // battery details card
    private LinearLayout batteryCard;
    private TextView batSub;
    private TextView batNote;
    private Button batCheck;

    // controls card
    private LinearLayout controlsCard;
    private Button connectButton;
    private Ui.SwitchRow autoRow;
    private Ui.SwitchRow monitorRow;
    private TextView autoWarn;

    // keep-running card
    private LinearLayout keepCard;

    // attempt card
    private LinearLayout attemptCard;
    private TextView attemptText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        controller = BtController.get(this);
        buildUi();
        pendingConnect = getIntent() != null && getIntent().getBooleanExtra(EXTRA_CONNECT, false);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra(EXTRA_CONNECT, false)) {
            intent.removeExtra(EXTRA_CONNECT);
            if (holding) {
                controller.connectNow();
            } else {
                pendingConnect = true;
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!holding) {
            holding = true;
            controller.addListener(this);
            controller.acquire(true);
        }
        render(controller.snapshot());
        if (pendingConnect) {
            pendingConnect = false;
            controller.connectNow();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        orb.setRunning(true);
        if (holding) {
            render(controller.snapshot());
        }
        scheduleTick();
    }

    @Override
    protected void onPause() {
        // Nothing animates or ticks while the dashboard is not in front.
        resumed = false;
        orb.setRunning(false);
        handler.removeCallbacks(tick);
        super.onPause();
    }

    @Override
    protected void onStop() {
        handler.removeCallbacksAndMessages(null);
        if (holding) {
            holding = false;
            controller.removeListener(this);
            controller.release(true);
        }
        super.onStop();
    }

    @Override
    public void onSnapshot(Snapshot s) {
        render(s);
    }

    // ------------------------------------------------------------------ building the screen

    private void buildUi() {
        LinearLayout page = Ui.page(this, "Earbuds Auto-Connect");

        // app name row
        LinearLayout brand = Ui.row(this);
        TextView name = Ui.text(this, "EARBUDS", 26, R.color.primary, false);
        name.setTypeface(Ui.light());
        name.setLetterSpacing(0.18f);
        brand.addView(name);
        TextView sub = Ui.text(this, "  AUTO-CONNECT", 12, R.color.accent, true);
        sub.setLetterSpacing(0.18f);
        brand.addView(sub);
        page.addView(brand);

        LinearLayout nav = Ui.row(this);
        nav.addView(navChip("History", HistoryActivity.class), chipWeight(0));
        nav.addView(navChip("Treble Lab", TrebleLabActivity.class), chipWeight(6));
        nav.addView(navChip("Diagnostics", DiagnosticsActivity.class), chipWeight(6));
        nav.addView(navChip("Settings", SettingsActivity.class), chipWeight(6));
        Ui.add(page, nav, 12);

        // ---- hero card
        heroCard = Ui.card(this);
        heroCard.setBackground(Ui.glowRect(this, Ui.col(this, R.color.surface),
                Ui.col(this, R.color.outline), 0x1A00E5FF, 26));
        heroCard.addView(Ui.heading(this, "LIVE DASHBOARD"));

        FrameLayout frame = new FrameLayout(this);
        orb = new StatusOrbView(this);
        frame.addView(orb, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                Ui.dp(this, 230)));
        LinearLayout overlay = Ui.column(this);
        overlay.setGravity(Gravity.CENTER);
        timerText = Ui.text(this, "--:--:--", 34, R.color.text_primary, false);
        timerText.setTypeface(Ui.light());
        timerText.setFontFeatureSettings("tnum");
        timerText.setGravity(Gravity.CENTER);
        overlay.addView(timerText);
        timerCaption = Ui.text(this, "", 11, R.color.text_dim, true);
        timerCaption.setLetterSpacing(0.14f);
        timerCaption.setGravity(Gravity.CENTER);
        Ui.add(overlay, timerCaption, 4);
        frame.addView(overlay, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                Ui.dp(this, 230), Gravity.CENTER));
        Ui.add(heroCard, frame, 4);

        deviceName = Ui.text(this, "", 22, R.color.text_primary, false);
        deviceName.setTypeface(Ui.medium());
        deviceName.setGravity(Gravity.CENTER);
        Ui.add(heroCard, deviceName, 6);
        statusRow = Ui.row(this);
        statusRow.setGravity(Gravity.CENTER);
        statusDot = Ui.dot(this, Ui.col(this, R.color.idle));
        statusRow.addView(statusDot);
        statusText = Ui.text(this, "", 16, R.color.text_primary, true);
        statusRow.addView(statusText);
        Ui.add(heroCard, statusRow, 6);
        deviceInfo = Ui.small(this, "");
        deviceInfo.setGravity(Gravity.CENTER);
        Ui.add(heroCard, deviceInfo, 4);

        // stats: connected-since and battery
        statsRow = Ui.row(this);
        statsRow.setGravity(Gravity.TOP);
        LinearLayout sinceCol = Ui.column(this);
        sinceCol.addView(Ui.heading(this, "CONNECTED SINCE"));
        sinceValue = Ui.text(this, "", 16, R.color.text_primary, false);
        sinceValue.setTypeface(Ui.medium());
        Ui.add(sinceCol, sinceValue, 6);
        sinceNote = Ui.small(this, "");
        Ui.add(sinceCol, sinceNote, 4);
        statsRow.addView(sinceCol, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout batCol = Ui.column(this);
        batCol.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout rings = Ui.row(this);
        rings.setGravity(Gravity.CENTER);
        LinearLayout colA = Ui.column(this);
        colA.setGravity(Gravity.CENTER_HORIZONTAL);
        ringA = new BatteryRingView(this, 72);
        colA.addView(ringA);
        ringLabelA = Ui.text(this, "L", 11, R.color.text_secondary, true);
        ringLabelA.setVisibility(View.GONE);
        colA.addView(ringLabelA);
        rings.addView(colA);
        LinearLayout colB = Ui.column(this);
        colB.setGravity(Gravity.CENTER_HORIZONTAL);
        ringB = new BatteryRingView(this, 72);
        colB.addView(ringB);
        ringLabelB = Ui.text(this, "R", 11, R.color.text_secondary, true);
        colB.addView(ringLabelB);
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bLp.setMargins(Ui.dp(this, 10), 0, 0, 0);
        rings.addView(colB, bLp);
        colB.setVisibility(View.GONE);
        batCol.addView(rings);
        batHeroText = Ui.small(this, "");
        batHeroText.setGravity(Gravity.CENTER);
        Ui.add(batCol, batHeroText, 6);
        statsRow.addView(batCol, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Ui.add(heroCard, statsRow, 18);

        hintText = Ui.body(this, "");
        Ui.add(heroCard, hintText, 14);
        hintButton = Ui.button(this, "", Ui.BTN_TONAL, v -> {
            if (currentHint != null) {
                Ui.perform(this, currentHint.action);
            }
        });
        Ui.add(heroCard, hintButton, 8);
        LinearLayout deviceButtons = Ui.row(this);
        pickButton = Ui.button(this, "Choose earbuds", Ui.BTN_TONAL,
                v -> startActivity(new Intent(this, PickDeviceActivity.class)));
        deviceButtons.addView(pickButton, weight());
        clearButton = Ui.button(this, "Clear", Ui.BTN_TEXT, v -> confirmClear());
        deviceButtons.addView(clearButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        Ui.add(heroCard, deviceButtons, 14);
        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        heroLp.setMargins(0, Ui.dp(this, 14), 0, Ui.dp(this, 12));
        page.addView(heroCard, heroLp);

        // ---- audio warning
        audioCard = Ui.card(this);
        audioCard.setBackground(Ui.glowRect(this, Ui.col(this, R.color.surface),
                Ui.col(this, R.color.warn), 0x22FFB020, 22));
        audioCard.addView(Ui.text(this, "Connected, but is music reaching the earbuds?", 16,
                R.color.text_primary, true));
        Ui.add(audioCard, Ui.body(this, "Bluetooth says the earbuds are connected, but Android isn't "
                + "routing music to them right now. Sound may still be coming from the phone."), 6);
        Ui.add(audioCard, Ui.button(this, "Troubleshoot", Ui.BTN_TONAL,
                v -> startActivity(new Intent(this, DiagnosticsActivity.class))), 8);
        Ui.addCard(page, audioCard);

        // ---- battery details
        batteryCard = Ui.card(this);
        batteryCard.addView(Ui.heading(this, "BATTERY DETAILS"));
        batSub = Ui.body(this, "");
        Ui.add(batteryCard, batSub, 6);
        batNote = Ui.small(this, "");
        Ui.add(batteryCard, batNote, 6);
        batCheck = Ui.button(this, "Check again", Ui.BTN_TEXT, v -> controller.checkBatteryNow());
        Ui.add(batteryCard, batCheck, 4);
        Ui.addCard(page, batteryCard);

        // ---- controls card
        controlsCard = Ui.card(this);
        connectButton = Ui.button(this, "Connect now", Ui.BTN_PRIMARY, v -> controller.connectNow());
        controlsCard.addView(connectButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        Ui.add(controlsCard, Ui.button(this, "Open Bluetooth settings", Ui.BTN_TEXT,
                v -> Ui.openBluetoothSettings(this)), 4);

        autoRow = Ui.switchRow(this, "Auto-Connect",
                "Reconnect to your earbuds when they become available.", checked -> {
                    prefs.setAutoConnect(checked);
                    controller.onSettingsChanged();
                });
        Ui.add(controlsCard, autoRow.view, 8);
        autoWarn = Ui.small(this, "Auto-Connect only works while this app is open. Turn on Background "
                + "Monitoring to keep it working with the screen off.");
        Ui.add(controlsCard, autoWarn, 0);

        monitorRow = Ui.switchRow(this, "Background Monitoring",
                "Keeps watching with the screen off, so history and widgets stay complete. "
                        + "Shows a small notification.", checked -> {
                    if (checked) {
                        if (prefs.preferredAddress() == null) {
                            Ui.toast(this, "Choose your earbuds first.");
                            monitorRow.set(false);
                            return;
                        }
                        prefs.setMonitoring(true);
                        MonitorService.start(this);
                    } else {
                        prefs.setMonitoring(false);
                        MonitorService.stop(this);
                    }
                    controller.onSettingsChanged();
                });
        Ui.add(controlsCard, monitorRow.view, 4);
        Ui.addCard(page, controlsCard);

        // ---- keep running hint
        keepCard = Ui.card(this);
        keepCard.addView(Ui.text(this, "Keep monitoring alive", 16, R.color.text_primary, true));
        Ui.add(keepCard, Ui.body(this, "Android is allowed to pause this app when the screen is off. "
                + "If monitoring stops, allow background activity for it."), 6);
        Ui.add(keepCard, Ui.button(this, "Show me how", Ui.BTN_TONAL,
                v -> startActivity(new Intent(this, SettingsActivity.class))), 8);
        Ui.addCard(page, keepCard);

        // ---- last attempt
        attemptCard = Ui.card(this);
        attemptCard.addView(Ui.heading(this, "CONNECTION ATTEMPTS"));
        attemptText = Ui.body(this, "");
        Ui.add(attemptCard, attemptText, 6);
        Ui.addCard(page, attemptCard);
    }

    private Button navChip(String label, final Class<?> target) {
        return Ui.chip(this, label, false, v -> startActivity(new Intent(this, target)));
    }

    private LinearLayout.LayoutParams chipWeight(int leftMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(Ui.dp(this, leftMarginDp), 0, 0, 0);
        return lp;
    }

    private static LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Clear preferred earbuds?")
                .setMessage("The app will stop watching them and Background Monitoring will turn off. "
                        + "Your history stays until you clear it.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear", (d, w) -> {
                    prefs.clearPreferred();
                    prefs.setMonitoring(false);
                    MonitorService.stop(this);
                    controller.onPreferredDeviceChanged();
                    render(controller.snapshot());
                })
                .show();
    }

    // ------------------------------------------------------------------ the once-a-second timer

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateTimer();
            scheduleTick();
        }
    };

    private boolean timerLive(Snapshot s) {
        return s != null && s.isConnected() && s.connectedSince > 0L;
    }

    private void updateTimer() {
        Snapshot s = lastSnap;
        if (timerLive(s)) {
            long elapsed = Math.max(0L, System.currentTimeMillis() - s.connectedSince);
            timerText.setText(DurationFormat.clock(elapsed));
        }
    }

    /** Ticks only while the dashboard is in front and the earbuds are connected. */
    private void scheduleTick() {
        handler.removeCallbacks(tick);
        if (!resumed || !timerLive(lastSnap)) {
            return;
        }
        long elapsed = Math.max(0L, System.currentTimeMillis() - lastSnap.connectedSince);
        handler.postDelayed(tick, 1000L - (elapsed % 1000L) + 5L);
    }

    // ------------------------------------------------------------------ rendering

    private void render(Snapshot s) {
        lastSnap = s;
        final boolean hasDevice = s.deviceAddress != null;
        Snapshot.Status st = s.status();

        // orb + timer
        orb.setStatus(orbMode(st), orbColor(st), orbEnd(st));
        if (timerLive(s)) {
            updateTimer();
            timerCaption.setText(s.connectedSinceExact ? "CONNECTED FOR" : "SEEN CONNECTED FOR");
        } else {
            timerText.setText("--:--:--");
            timerCaption.setText(hasDevice ? orbWord(st) : "NO EARBUDS");
        }
        timerText.setTextColor(Ui.col(this, timerLive(s) ? R.color.text_primary : R.color.text_dim));
        scheduleTick();

        // names and status
        deviceName.setText(hasDevice ? s.deviceName : "No earbuds selected");
        statusRow.setVisibility(hasDevice ? View.VISIBLE : View.GONE);
        if (hasDevice) {
            statusText.setText(StatusText.label(s));
            statusText.setTextColor(Ui.col(this, dotColor(st)));
            Ui.setDotColor(statusDot, Ui.col(this, dotColor(st)));
        }
        List<String> info = new ArrayList<String>();
        if (hasDevice && s.deviceType != null) {
            info.add(s.deviceType);
        }
        if (hasDevice && s.transport != null) {
            info.add(s.transport);
        }
        deviceInfo.setVisibility(info.isEmpty() ? View.GONE : View.VISIBLE);
        deviceInfo.setText(join(info, " · "));

        // connected since (exact time, with an honest note)
        statsRow.setVisibility(hasDevice ? View.VISIBLE : View.GONE);
        if (timerLive(s)) {
            sinceValue.setText(StatusText.whenExact(this, s.connectedSince));
            sinceNote.setText(s.connectedSinceExact
                    ? "The app saw the connection start."
                    : "Already connected when the app began watching, so this is only when it was "
                    + "first seen. The real start was earlier.");
        } else {
            sinceValue.setText("--");
            sinceNote.setText(hasDevice ? "Shown while the earbuds are connected."
                    : "");
        }

        currentHint = StatusText.hint(this, s);
        if (currentHint != null) {
            hintText.setVisibility(View.VISIBLE);
            hintText.setText(currentHint.text);
            boolean showAction = currentHint.action != StatusText.Action.NONE
                    && currentHint.action != StatusText.Action.PICK_DEVICE;
            hintButton.setVisibility(showAction ? View.VISIBLE : View.GONE);
            if (showAction) {
                hintButton.setText(currentHint.actionLabel);
            }
        } else {
            hintText.setVisibility(View.GONE);
            hintButton.setVisibility(View.GONE);
        }
        pickButton.setText(hasDevice ? "Change earbuds" : "Choose earbuds");
        clearButton.setVisibility(hasDevice ? View.VISIBLE : View.GONE);

        // sections only make sense once earbuds are chosen
        int vis = hasDevice ? View.VISIBLE : View.GONE;
        batteryCard.setVisibility(vis);
        controlsCard.setVisibility(vis);
        attemptCard.setVisibility(vis);

        renderAudioWarning(s);
        renderBattery(s);
        renderControls(s);
        renderAttempts(s);
    }

    private static int orbMode(Snapshot.Status st) {
        switch (st) {
            case CONNECTED:
            case CALLS_ONLY:
                return StatusOrbView.MODE_CONNECTED;
            case CONNECTING:
                return StatusOrbView.MODE_CONNECTING;
            case BT_OFF:
            case BT_UNAVAILABLE:
            case NO_PERMISSION:
            case UNPAIRED:
                return StatusOrbView.MODE_ERROR;
            default:
                return StatusOrbView.MODE_IDLE;
        }
    }

    private int orbColor(Snapshot.Status st) {
        switch (st) {
            case CONNECTED:
                return Ui.col(this, R.color.primary);
            case CALLS_ONLY:
            case CONNECTING:
            case LINKED_NO_AUDIO:
                return Ui.col(this, R.color.warn);
            case BT_OFF:
            case BT_UNAVAILABLE:
            case NO_PERMISSION:
            case UNPAIRED:
                return Ui.col(this, R.color.error);
            default:
                return Ui.col(this, R.color.idle);
        }
    }

    private int orbEnd(Snapshot.Status st) {
        return st == Snapshot.Status.CONNECTED ? Ui.col(this, R.color.accent) : orbColor(st);
    }

    private static String orbWord(Snapshot.Status st) {
        switch (st) {
            case CONNECTING:
                return "CONNECTING";
            case LINKED_NO_AUDIO:
                return "NEARBY, NO AUDIO";
            case BT_OFF:
                return "BLUETOOTH OFF";
            case BT_UNAVAILABLE:
                return "NO BLUETOOTH";
            case NO_PERMISSION:
                return "PERMISSION NEEDED";
            case UNPAIRED:
                return "NOT PAIRED";
            case NO_DEVICE:
                return "NO EARBUDS";
            default:
                return "NOT CONNECTED";
        }
    }

    private static int dotColor(Snapshot.Status st) {
        switch (st) {
            case CONNECTED:
                return R.color.ok;
            case CALLS_ONLY:
            case LINKED_NO_AUDIO:
            case CONNECTING:
                return R.color.warn;
            case BT_OFF:
            case BT_UNAVAILABLE:
            case NO_PERMISSION:
            case UNPAIRED:
                return R.color.error;
            default:
                return R.color.idle;
        }
    }

    private void renderAudioWarning(Snapshot s) {
        boolean show = false;
        if (s.status() == Snapshot.Status.CONNECTED) {
            long sinceConnect = System.currentTimeMillis() - s.connectedSince;
            if (s.connectedSince > 0L && sinceConnect < AUDIO_SETTLE_MS) {
                // Android needs a moment to publish the audio output; check again shortly.
                handler.removeCallbacks(recheck);
                handler.postDelayed(recheck, AUDIO_SETTLE_MS - sinceConnect + 500L);
            } else {
                AudioRoute r = AudioRoute.check(this, s.deviceAddress);
                show = r.addressComparable && !r.a2dpRouteForDevice;
            }
        }
        audioCard.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private final Runnable recheck = new Runnable() {
        @Override
        public void run() {
            if (holding) {
                render(controller.snapshot());
            }
        }
    };

    private void renderBattery(Snapshot s) {
        batCheck.setVisibility(View.GONE);
        ringLabelA.setVisibility(View.GONE);
        ((View) ringB.getParent()).setVisibility(View.GONE);

        if (s.isConnected() && s.batSingle != null) {
            ringA.setLevel(s.batSingle.intValue());
            batHeroText.setText("Updated " + StatusText.when(this, s.batTime));
            batSub.setText(s.batSource + "\nUpdated " + StatusText.when(this, s.batTime));
            batNote.setText("These earbuds give one battery value, not separate left and right "
                    + "levels. The charging case battery is never shown.");
        } else if (s.isConnected() && (s.batLeft != null || s.batRight != null)) {
            ringA.setLevel(s.batLeft != null ? s.batLeft.intValue() : -1);
            ringB.setLevel(s.batRight != null ? s.batRight.intValue() : -1);
            ringLabelA.setVisibility(View.VISIBLE);
            ((View) ringB.getParent()).setVisibility(View.VISIBLE);
            batHeroText.setText("Updated " + StatusText.when(this, s.batTime));
            batSub.setText("Updated " + StatusText.when(this, s.batTime));
            batNote.setText("The charging case battery is never shown.");
        } else if (s.isConnected()) {
            ringA.setLevel(-1);
            batHeroText.setText("Not reported by this device");
            batSub.setText("Battery information unavailable for this device.");
            if (s.batProbeState == 1) {
                batNote.setText("Checking the earbuds for a battery level...");
            } else if (s.batProbeState == 2) {
                batNote.setText("The earbuds don't send a battery level to Android and don't offer "
                        + "a readable standard battery service. Their own app may show it, but this "
                        + "app can't read it.");
            } else if (s.batProbeState == 4) {
                batNote.setText("The earbuds don't send a battery level to Android, and a check over "
                        + "Bluetooth LE couldn't connect, so it's unknown whether they offer one. "
                        + "Nothing is estimated or guessed.");
            } else {
                batNote.setText("No battery level has been reported yet. Many earbuds never send one "
                        + "to the phone. Nothing is estimated or guessed.");
            }
            boolean canProbe = s.deviceTypeCode != android.bluetooth.BluetoothDevice.DEVICE_TYPE_CLASSIC
                    && s.batProbeState != 1;
            batCheck.setVisibility(canProbe ? View.VISIBLE : View.GONE);
        } else {
            ringA.setLevel(-1);
            batHeroText.setText("Shown while connected");
            batSub.setText("Battery is shown only while the earbuds are connected.");
            if (s.lastBatLevel >= 0 && s.lastBatTime > 0L) {
                batNote.setText("Last reading seen: " + s.lastBatLevel + "% at "
                        + StatusText.when(this, s.lastBatTime) + " (old - not current).");
            } else {
                batNote.setText("No reading has been received yet.");
            }
        }
    }

    private void renderControls(Snapshot s) {
        boolean canTry = s.adapterOn && s.permissionOk && s.bonded;
        if (s.isConnected()) {
            connectButton.setText("Connected");
            Ui.setEnabledLook(connectButton, false);
        } else if (s.attemptInFlight || s.status() == Snapshot.Status.CONNECTING) {
            connectButton.setText("Connecting...");
            Ui.setEnabledLook(connectButton, false);
        } else {
            connectButton.setText("Connect now");
            Ui.setEnabledLook(connectButton, canTry);
        }
        autoRow.set(s.autoConnect);
        monitorRow.set(prefs.monitoring());
        autoWarn.setVisibility(s.autoConnect && !prefs.monitoring() ? View.VISIBLE : View.GONE);
        keepCard.setVisibility(prefs.monitoring() && !Diagnostics.ignoringBatteryOptimizations(this)
                ? View.VISIBLE : View.GONE);
    }

    private void renderAttempts(Snapshot s) {
        StringBuilder b = new StringBuilder();
        if (s.lastAttemptTime > 0L) {
            b.append("Last attempt: ").append(StatusText.when(this, s.lastAttemptTime));
            if (s.lastAttemptResult != null) {
                b.append("\n").append(s.lastAttemptResult);
            }
        } else {
            b.append("No connection attempt yet.");
        }
        b.append("\n\nLast confirmed connection: ").append(StatusText.when(this, s.lastSuccessTime));
        attemptText.setText(b.toString());
    }

    private static String join(List<String> parts, String sep) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) {
                b.append(sep);
            }
            b.append(parts.get(i));
        }
        return b.toString();
    }
}
