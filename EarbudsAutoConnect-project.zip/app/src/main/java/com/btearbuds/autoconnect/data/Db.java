package com.btearbuds.autoconnect.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Small local database: connection log and (optional) battery history.
 * Rows are capped so storage can never grow without limit. Nothing leaves the phone.
 */
public final class Db extends SQLiteOpenHelper {

    private static final String NAME = "history.db";
    private static final int VERSION = 1;
    private static final int MAX_LOG_ROWS = 500;
    private static final int MAX_BATTERY_ROWS = 3000;
    private static final long MAX_BATTERY_AGE_MS = 60L * 24L * 60L * 60L * 1000L;

    public static final class LogRow {
        public final long time;
        public final String type;
        public final String detail;

        LogRow(long time, String type, String detail) {
            this.time = time;
            this.type = type;
            this.detail = detail;
        }
    }

    public static final class BatteryRow {
        public final long time;
        public final int level;
        public final String source;
        public final String kind;

        BatteryRow(long time, int level, String source, String kind) {
            this.time = time;
            this.level = level;
            this.source = source;
            this.kind = kind;
        }
    }

    private static Db instance;

    public static synchronized Db get(Context context) {
        if (instance == null) {
            instance = new Db(context.getApplicationContext());
        }
        return instance;
    }

    private Db(Context context) {
        super(context, NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE conn_log (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "ts INTEGER NOT NULL, type TEXT NOT NULL, detail TEXT)");
        db.execSQL("CREATE TABLE battery (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "ts INTEGER NOT NULL, level INTEGER NOT NULL, source TEXT, kind TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 only.
    }

    // ---- connection log
    public void addLog(String type, String detail) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues v = new ContentValues();
            v.put("ts", System.currentTimeMillis());
            v.put("type", type);
            v.put("detail", detail);
            db.insert("conn_log", null, v);
            db.execSQL("DELETE FROM conn_log WHERE id <= (SELECT MAX(id) FROM conn_log) - "
                    + MAX_LOG_ROWS);
        } catch (SQLiteException e) {
            // History is a convenience; never crash because of it.
        }
    }

    public List<LogRow> recentLogs(int limit) {
        List<LogRow> out = new ArrayList<LogRow>();
        Cursor c = null;
        try {
            c = getReadableDatabase().rawQuery(
                    "SELECT ts, type, detail FROM conn_log ORDER BY id DESC LIMIT " + limit, null);
            while (c.moveToNext()) {
                out.add(new LogRow(c.getLong(0), c.getString(1), c.getString(2)));
            }
        } catch (SQLiteException e) {
            // return what we have
        } finally {
            if (c != null) {
                c.close();
            }
        }
        return out;
    }

    public void clearLogs() {
        try {
            getWritableDatabase().execSQL("DELETE FROM conn_log");
        } catch (SQLiteException e) {
            // ignore
        }
    }

    // ---- battery history
    public void addBattery(long time, int level, String source, String kind) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues v = new ContentValues();
            v.put("ts", time);
            v.put("level", level);
            v.put("source", source);
            v.put("kind", kind);
            db.insert("battery", null, v);
            db.execSQL("DELETE FROM battery WHERE id <= (SELECT MAX(id) FROM battery) - "
                    + MAX_BATTERY_ROWS);
            db.execSQL("DELETE FROM battery WHERE ts < " + (time - MAX_BATTERY_AGE_MS));
        } catch (SQLiteException e) {
            // ignore
        }
    }

    public List<BatteryRow> batterySince(long sinceTime) {
        List<BatteryRow> out = new ArrayList<BatteryRow>();
        Cursor c = null;
        try {
            c = getReadableDatabase().rawQuery(
                    "SELECT ts, level, source, kind FROM battery WHERE ts >= " + sinceTime
                            + " ORDER BY ts ASC", null);
            while (c.moveToNext()) {
                out.add(new BatteryRow(c.getLong(0), c.getInt(1), c.getString(2), c.getString(3)));
            }
        } catch (SQLiteException e) {
            // return what we have
        } finally {
            if (c != null) {
                c.close();
            }
        }
        return out;
    }

    public void clearBattery() {
        try {
            getWritableDatabase().execSQL("DELETE FROM battery");
        } catch (SQLiteException e) {
            // ignore
        }
    }
}
