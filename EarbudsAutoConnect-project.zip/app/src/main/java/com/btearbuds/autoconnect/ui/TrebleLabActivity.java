package com.btearbuds.autoconnect.ui;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.treble.TrebleEngine;
import com.btearbuds.autoconnect.treble.TrebleMath;
import com.btearbuds.autoconnect.treble.TreblePrefs;
import com.btearbuds.autoconnect.treble.TrebleService;

import java.util.Locale;

/**
 * Treble Lab: a dial, a slider and presets for a treble change applied through Android's
 * equalizer. It says plainly what Android accepted and what the app cannot know. It is separate
 * from Bluetooth connection tracking and does not read any Bluetooth state.
 */
public final class TrebleLabActivity extends Activity implements TrebleEngine.Listener {

    private static final int SLIDER_STEPS = 48; // -12..+12 dB in 0.5 dB steps
    private static final long APPLY_DELAY_MS = 80L;
    private static final long START_CHECK_MS = 2500L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TreblePrefs prefs;
    private TrebleEngine engine;
    private TrebleEngine.Capability cap;
    private boolean listening;

    private TrebleDialView dial;
    private SeekBar slider;
    private TextView sliderValue;
    private Button[] chips;
    private TrebleMath.Preset[] chipPresets;
    private TextView presetNote;
    private TextView bandsText;
    private Ui.SwitchRow applyRow;
    private View statusDot;
    private TextView statusHead;
    private TextView statusBody;
    private TextView statusDetail;
    private boolean updatingUi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new TreblePrefs(this);
        engine = TrebleEngine.get(this);
        cap = engine.capability();
        buildUi();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!listening) {
            listening = true;
            engine.addListener(this);
        }
        // Treble was left on (for example the phone restarted the app): bring the service back.
        if (prefs.enabled() && cap.usable() && !TrebleService.running) {
            TrebleService.start(this);
        }
        renderAll();
        handler.postDelayed(recheck, START_CHECK_MS);
    }

    @Override
    protected void onStop() {
        handler.removeCallbacksAndMessages(null);
        if (listening) {
            listening = false;
            engine.removeListener(this);
        }
        super.onStop();
    }

    @Override
    public void onTrebleStatus(TrebleEngine.Status s) {
        renderStatus(s);
    }

    private final Runnable recheck = new Runnable() {
        @Override
        public void run() {
            renderStatus(engine.status());
        }
    };

    private final Runnable applyNow = new Runnable() {
        @Override
        public void run() {
            if (prefs.enabled()) {
                engine.reapply();
            }
        }
    };

    // ------------------------------------------------------------------ building the screen

    private void buildUi() {
        LinearLayout page = Ui.page(this, "Treble Lab");
        page.addView(Ui.title(this, "Treble Lab"));
        Ui.add(page, Ui.small(this, "Raise or lower the high-pitched part of your sound using "
                + "Android's equalizer. This is separate from Bluetooth tracking."), 4);

        // ---- dial card
        LinearLayout card = Ui.card(this);
        card.addView(Ui.heading(this, "TREBLE"));
        dial = new TrebleDialView(this);
        LinearLayout.LayoutParams dialLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        dialLp.setMargins(0, Ui.dp(this, 8), 0, 0);
        card.addView(dial, dialLp);
        int[] range = cap.rangeDb;
        if (range != null) {
            dial.setUsableRange(range[0], range[1]);
        }
        dial.setValue(prefs.db());
        dial.setListener((db, fromUser) -> onUserValue(db));

        slider = new SeekBar(this);
        slider.setMax(SLIDER_STEPS);
        Ui.styleSeekBar(this, slider);
        slider.setContentDescription("Treble amount");
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser && !updatingUi) {
                    onUserValue(TrebleMath.MIN_DB + progress * TrebleMath.STEP_DB);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        Ui.add(card, slider, 4);
        LinearLayout ends = Ui.row(this);
        ends.addView(Ui.small(this, "-12 dB"), new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        sliderValue = Ui.text(this, "", 14, R.color.primary, true);
        ends.addView(sliderValue);
        TextView right = Ui.small(this, "+12 dB");
        right.setGravity(android.view.Gravity.END);
        ends.addView(right, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Ui.add(card, ends, 0);

        // ---- presets
        chipPresets = new TrebleMath.Preset[]{TrebleMath.Preset.NEUTRAL, TrebleMath.Preset.WARM,
                TrebleMath.Preset.BALANCED, TrebleMath.Preset.BRIGHT, TrebleMath.Preset.CUSTOM};
        chips = new Button[chipPresets.length];
        LinearLayout chipRow = Ui.row(this);
        for (int i = 0; i < chips.length; i++) {
            final TrebleMath.Preset p = chipPresets[i];
            chips[i] = Ui.chip(this, p.label, false, v -> onPreset(p));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(i == 0 ? 0 : Ui.dp(this, 6), 0, 0, 0);
            chipRow.addView(chips[i], lp);
        }
        Ui.add(card, chipRow, 14);
        presetNote = Ui.small(this, "");
        Ui.add(card, presetNote, 8);
        bandsText = Ui.small(this, "");
        Ui.add(card, bandsText, 6);

        applyRow = Ui.switchRow(this, "Apply treble",
                "Turn on to apply the setting. Turn off to go back to normal sound.", checked -> {
                    if (checked) {
                        if (!cap.usable()) {
                            Ui.toast(this, cap.problem);
                            applyRow.set(false);
                            return;
                        }
                        prefs.setEnabled(true);
                        TrebleService.start(this);
                        handler.removeCallbacks(recheck);
                        handler.postDelayed(recheck, START_CHECK_MS);
                    } else {
                        prefs.setEnabled(false);
                        TrebleService.stop(this);
                        engine.stop();
                    }
                    renderStatus(engine.status());
                });
        Ui.add(card, applyRow.view, 14);
        Ui.addCard(page, card);

        // ---- status card
        LinearLayout status = Ui.card(this);
        status.addView(Ui.heading(this, "STATUS"));
        LinearLayout head = Ui.row(this);
        statusDot = Ui.dot(this, Ui.col(this, R.color.idle));
        head.addView(statusDot);
        statusHead = Ui.text(this, "", 17, R.color.text_primary, true);
        head.addView(statusHead);
        Ui.add(status, head, 8);
        statusBody = Ui.body(this, "");
        Ui.add(status, statusBody, 8);
        statusDetail = Ui.small(this, "");
        Ui.add(status, statusDetail, 8);
        Ui.addCard(page, status);

        // ---- equalizer capability card
        LinearLayout capCard = Ui.card(this);
        capCard.addView(Ui.heading(this, "YOUR PHONE'S EQUALIZER"));
        Ui.add(capCard, Ui.body(this, capabilityText()), 6);
        Ui.addCard(page, capCard);

        // ---- limits card
        LinearLayout limits = Ui.card(this);
        limits.addView(Ui.heading(this, "HONEST LIMITS"));
        Ui.add(limits, Ui.body(this,
                "• This app can't hear your audio. \"Accepted by Android\" means the equalizer "
                        + "took the setting and gave it back when asked. It does not prove you will "
                        + "hear a difference.\n"
                        + "• Some phones ignore equalizers on the main output. Some music and "
                        + "video apps never tell other apps which audio they are playing, so this "
                        + "can't reach them. When that happens the status says \"Not applied\".\n"
                        + "• It changes the sound before it is sent to your earbuds, so it works "
                        + "the same on Bluetooth or the speaker. Your earbuds' own sound settings "
                        + "can't be changed from here.\n"
                        + "• While it is on, a small notification keeps the equalizer alive. "
                        + "Turning it off releases the equalizer and the sound goes back to normal.\n"
                        + "• The range follows your phone: " + rangeSentence() + "\n"
                        + "• To check by ear, play music and flip the switch above off and on."),
                6);
        Ui.addCard(page, limits);
    }

    private String rangeSentence() {
        if (cap.rangeDb == null) {
            return "no usable range was found, so Treble Lab is unavailable.";
        }
        if (cap.rangeDb[0] == (int) TrebleMath.MIN_DB && cap.rangeDb[1] == (int) TrebleMath.MAX_DB) {
            return "-12 to +12 dB, the full range.";
        }
        return "this phone's equalizer allows " + cap.rangeDb[0] + " to +" + cap.rangeDb[1]
                + " dB, so the dial stops there.";
    }

    private String capabilityText() {
        if (!cap.usable()) {
            return cap.problem + "\n\nTreble Lab can't work on this phone, so the controls are "
                    + "switched off. Nothing is pretended.";
        }
        StringBuilder b = new StringBuilder();
        b.append("Bands: ");
        for (int i = 0; i < cap.centerHz.length; i++) {
            if (i > 0) {
                b.append(", ");
            }
            b.append(freq(cap.centerHz[i]));
        }
        b.append(String.format(Locale.US, "\nEach band can move %.0f dB down and %.0f dB up.",
                -cap.minMb / 100.0, cap.maxMb / 100.0));
        b.append("\nTreble means the bands from 2 kHz upward; lower bands stay flat.");
        return b.toString();
    }

    private static String freq(int hz) {
        if (hz >= 1000) {
            double k = hz / 1000.0;
            return (Math.abs(k - Math.round(k)) < 0.05
                    ? String.format(Locale.US, "%.0f kHz", k)
                    : String.format(Locale.US, "%.1f kHz", k));
        }
        return hz + " Hz";
    }

    // ------------------------------------------------------------------ user input

    private void onUserValue(double db) {
        double v = TrebleMath.clamp(TrebleMath.snap(db), cap.rangeDb);
        prefs.setDb(v);
        prefs.setCustomDb(v);
        prefs.setPreset(TrebleMath.Preset.CUSTOM);
        updateControls(v);
        scheduleApply();
    }

    private void onPreset(TrebleMath.Preset p) {
        double v;
        if (p == TrebleMath.Preset.CUSTOM) {
            v = prefs.hasCustom() ? prefs.customDb() : prefs.db();
        } else {
            v = p.db;
        }
        double clamped = TrebleMath.clamp(v, cap.rangeDb);
        prefs.setDb(clamped);
        prefs.setPreset(p);
        if (p == TrebleMath.Preset.CUSTOM) {
            prefs.setCustomDb(clamped);
        }
        updateControls(clamped);
        if (clamped != v) {
            presetNote.setVisibility(View.VISIBLE);
            presetNote.setText(p.label + " wants " + TrebleMath.formatDb(v) + " but this phone "
                    + "allows up to " + TrebleMath.formatDb(clamped) + ", so that is what is used.");
        }
        scheduleApply();
    }

    private void scheduleApply() {
        handler.removeCallbacks(applyNow);
        handler.postDelayed(applyNow, APPLY_DELAY_MS);
    }

    // ------------------------------------------------------------------ rendering

    private void renderAll() {
        updateControls(TrebleMath.clamp(prefs.db(), cap.rangeDb));
        renderStatus(engine.status());
    }

    private void updateControls(double db) {
        updatingUi = true;
        boolean usable = cap.usable();
        dial.setDialEnabled(usable);
        dial.setValue(db);
        slider.setEnabled(usable);
        slider.setAlpha(usable ? 1f : 0.45f);
        slider.setProgress((int) Math.round((db - TrebleMath.MIN_DB) / TrebleMath.STEP_DB));
        sliderValue.setText(TrebleMath.formatDb(db));
        TrebleMath.Preset selected = prefs.preset();
        for (int i = 0; i < chips.length; i++) {
            Ui.setChipSelected(this, chips[i], chipPresets[i] == selected);
            chips[i].setEnabled(usable);
            chips[i].setAlpha(usable ? 1f : 0.45f);
        }
        if (selected != TrebleMath.Preset.CUSTOM
                && TrebleMath.clamp(selected.db, cap.rangeDb) == selected.db) {
            presetNote.setVisibility(View.GONE);
        }
        if (usable) {
            int[] levels = TrebleMath.bandLevelsMb(cap.centerHz, db, cap.minMb, cap.maxMb);
            StringBuilder b = new StringBuilder("Sent to the equalizer: ");
            for (int i = 0; i < levels.length; i++) {
                if (i > 0) {
                    b.append("  ·  ");
                }
                b.append(freq(cap.centerHz[i])).append(' ')
                        .append(String.format(Locale.US, "%+.1f", levels[i] / 100.0));
            }
            b.append(" dB");
            bandsText.setText(b.toString());
        } else {
            bandsText.setText("");
        }
        updatingUi = false;
    }

    private void renderStatus(TrebleEngine.Status s) {
        applyRow.set(prefs.enabled() && cap.usable());
        int dotColor;
        String head;
        String body;
        StringBuilder detail = new StringBuilder();

        if (!cap.usable()) {
            dotColor = R.color.error;
            head = "Unavailable on this phone";
            body = cap.problem;
        } else if (!prefs.enabled()) {
            dotColor = R.color.idle;
            head = "Off";
            body = "Sound is unchanged. Your setting is saved and will be used when you turn "
                    + "Apply treble on.";
        } else if (!s.running) {
            dotColor = R.color.warn;
            head = "Starting...";
            body = "Waiting for Android to start the equalizer service. If this stays here, turn "
                    + "the switch off and on again.";
        } else if (s.applied()) {
            dotColor = R.color.ok;
            head = "Accepted by Android";
            body = "The equalizer took " + TrebleMath.formatDb(s.db) + " of treble and reported it "
                    + "back correctly. The app can't hear your audio, so whether you notice it "
                    + "depends on your phone and the app playing. Flip the switch to compare.";
        } else {
            dotColor = R.color.warn;
            head = "Not applied";
            body = "Android did not confirm the equalizer on any audio. Nothing is changing your "
                    + "sound right now.";
        }

        if (cap.usable() && prefs.enabled() && s.running) {
            if (s.globalVerified) {
                detail.append("System output: accepted.\n");
            } else {
                detail.append("System output: ").append(s.globalProblem != null
                        ? s.globalProblem : "not confirmed.").append("\n");
            }
            if (s.appSessions == 0) {
                detail.append("Music apps: none have announced their audio yet. Start playing in an "
                        + "app that supports equalizers.");
            } else {
                detail.append("Music apps announcing audio: ").append(s.appSessions)
                        .append(" (accepted on ").append(s.appSessionsVerified).append(").");
            }
            if (s.controlLost) {
                detail.append("\nAnother app or the system took over an equalizer. Your setting "
                        + "may be overridden there.");
            }
        }

        Ui.setDotColor(statusDot, Ui.col(this, dotColor));
        statusHead.setText(head);
        statusBody.setText(body);
        statusDetail.setText(detail.toString());
        statusDetail.setVisibility(detail.length() == 0 ? View.GONE : View.VISIBLE);
    }
}
