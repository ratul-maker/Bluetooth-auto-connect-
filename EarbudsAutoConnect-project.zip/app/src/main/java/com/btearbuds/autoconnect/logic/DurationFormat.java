package com.btearbuds.autoconnect.logic;

/** Formats elapsed time for the live dashboard and the widgets. Pure Java, easy to test. */
public final class DurationFormat {

    private DurationFormat() {
    }

    /** "HH:MM:SS", or "Nd HH:MM:SS" from one full day up. Negative values count as zero. */
    public static String clock(long ms) {
        long total = ms < 0L ? 0L : ms / 1000L;
        long s = total % 60L;
        long m = (total / 60L) % 60L;
        long h = (total / 3600L) % 24L;
        long d = total / 86400L;
        String hms = two(h) + ":" + two(m) + ":" + two(s);
        return d > 0L ? d + "d " + hms : hms;
    }

    /** "under 1 min", "45 min", "2 h", "2 h 10 min". */
    public static String compact(long ms) {
        return InsightCalculator.formatDuration(ms < 0L ? 0L : ms);
    }

    private static String two(long v) {
        return v < 10L ? "0" + v : String.valueOf(v);
    }
}
