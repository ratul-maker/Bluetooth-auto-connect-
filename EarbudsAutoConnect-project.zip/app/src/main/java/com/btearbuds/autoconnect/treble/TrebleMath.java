package com.btearbuds.autoconnect.treble;

import java.util.Locale;

/**
 * The maths behind Treble Lab, kept free of Android so it can be tested on any computer.
 *
 * The user dials a "treble" amount in dB. Android's equalizer has a few fixed bands (each with a
 * centre frequency) and a limited gain range (in millibels, 100 mB = 1 dB). This class maps the
 * dial onto a high-shelf-like curve: nothing below 2 kHz, rising to the full amount at the
 * highest band, and never beyond what the equalizer reports it can do.
 */
public final class TrebleMath {

    public static final double MIN_DB = -12.0;
    public static final double MAX_DB = 12.0;
    public static final double STEP_DB = 0.5;

    /** Below this frequency the treble control leaves the sound alone. */
    public static final double SHELF_START_HZ = 2000.0;
    /** The highest band must be at least this high for a treble control to make sense. */
    public static final int MIN_TOP_BAND_HZ = 3000;

    public enum Preset {
        NEUTRAL("Neutral", 0.0),
        WARM("Warm", -4.0),
        BALANCED("Balanced", 2.0),
        BRIGHT("Bright", 6.0),
        CUSTOM("Custom", Double.NaN);

        public final String label;
        public final double db;

        Preset(String label, double db) {
            this.label = label;
            this.db = db;
        }
    }

    private TrebleMath() {
    }

    /**
     * The whole-dB range the user may pick, limited by both the -12..+12 design range and what
     * the equalizer says it supports. Null if the equalizer cannot move at least 1 dB each way.
     */
    public static int[] usableRangeDb(int minMillibel, int maxMillibel) {
        int lo = (int) Math.ceil(minMillibel / 100.0);
        int hi = (int) Math.floor(maxMillibel / 100.0);
        lo = Math.max(lo, (int) MIN_DB);
        hi = Math.min(hi, (int) MAX_DB);
        if (lo > -1 || hi < 1) {
            return null;
        }
        return new int[]{lo, hi};
    }

    public static double snap(double db) {
        return Math.round(db / STEP_DB) * STEP_DB;
    }

    public static double clamp(double db, int[] range) {
        double lo = range == null ? MIN_DB : range[0];
        double hi = range == null ? MAX_DB : range[1];
        if (db < lo) {
            return lo;
        }
        if (db > hi) {
            return hi;
        }
        return db;
    }

    public static boolean hasTrebleBand(int[] centerHz) {
        if (centerHz == null) {
            return false;
        }
        for (int f : centerHz) {
            if (f >= MIN_TOP_BAND_HZ) {
                return true;
            }
        }
        return false;
    }

    /** 0..1 per band: 0 up to 2 kHz, rising per octave, scaled so the highest band gets 1. */
    public static double[] shelfWeights(int[] centerHz) {
        double[] w = new double[centerHz.length];
        double max = 0.0;
        for (int i = 0; i < centerHz.length; i++) {
            double f = centerHz[i];
            double raw = 0.0;
            if (f > SHELF_START_HZ) {
                raw = (Math.log(f / SHELF_START_HZ) / Math.log(2.0)) / 2.0;
                if (raw > 1.0) {
                    raw = 1.0;
                }
            }
            w[i] = raw;
            if (raw > max) {
                max = raw;
            }
        }
        if (max <= 0.0) {
            return new double[centerHz.length];
        }
        for (int i = 0; i < w.length; i++) {
            w[i] = w[i] / max;
        }
        return w;
    }

    /** Millibel gain per equalizer band for the chosen treble amount, clamped to the device range. */
    public static int[] bandLevelsMb(int[] centerHz, double db, int minMillibel, int maxMillibel) {
        double[] w = shelfWeights(centerHz);
        int[] out = new int[centerHz.length];
        for (int i = 0; i < out.length; i++) {
            long mb = Math.round(db * 100.0 * w[i]);
            if (mb < minMillibel) {
                mb = minMillibel;
            }
            if (mb > maxMillibel) {
                mb = maxMillibel;
            }
            out[i] = (int) mb;
        }
        return out;
    }

    public static Preset presetFor(double db) {
        for (Preset p : Preset.values()) {
            if (p != Preset.CUSTOM && Math.abs(p.db - db) < 0.01) {
                return p;
            }
        }
        return Preset.CUSTOM;
    }

    public static String formatDb(double db) {
        if (Math.abs(db) < 0.05) {
            return "0.0 dB";
        }
        return String.format(Locale.US, "%+.1f dB", db);
    }
}
