package com.btearbuds.autoconnect.logic;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * Decides when a low-battery alert should be shown.
 *
 * Rules:
 *  - Readings outside 0..100 are ignored (they are "unknown", never alerted on).
 *  - Readings received while the device is not connected are ignored.
 *  - One alert per "low episode" per battery key ("single", "left", "right").
 *  - The key is re-armed only after the level recovers to threshold + REARM_MARGIN or more.
 */
public final class BatteryAlertEngine {

    public static final int REARM_MARGIN = 3;

    private final Set<String> alerted = new HashSet<String>();

    public BatteryAlertEngine(Collection<String> initiallyAlerted) {
        if (initiallyAlerted != null) {
            alerted.addAll(initiallyAlerted);
        }
    }

    public static boolean isValidLevel(int level) {
        return level >= 0 && level <= 100;
    }

    /**
     * @return true if a low-battery alert should be shown right now for this key
     */
    public boolean onReading(String key, int level, int threshold,
                             boolean alertsEnabled, boolean deviceConnected) {
        if (!isValidLevel(level) || !deviceConnected) {
            return false;
        }
        int rearmAt = Math.min(100, threshold + REARM_MARGIN);
        if (level >= rearmAt) {
            alerted.remove(key);
            return false;
        }
        if (level <= threshold) {
            if (alerted.contains(key) || !alertsEnabled) {
                return false;
            }
            alerted.add(key);
            return true;
        }
        return false;
    }

    public void reset() {
        alerted.clear();
    }

    public Set<String> snapshot() {
        return new HashSet<String>(alerted);
    }
}
