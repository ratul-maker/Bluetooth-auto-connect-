package com.btearbuds.autoconnect.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;

import com.btearbuds.autoconnect.R;

import java.util.Random;

/**
 * The dashboard's ambient background: a very faint HUD grid, a few slowly rising cyan and violet
 * data motes, and a soft scan line that drifts down the screen now and then. It is decoration only
 * and shows nothing about the earbuds.
 *
 * Battery notes: it runs at about 30 frames a second, only while the dashboard is in front, and not
 * at all when Android's animations are off (Battery Saver, or "Remove animations"); then it draws
 * once, as a still picture. It draws about two dozen small circles and one gradient, no blur.
 */
public final class AmbientBackdropView extends View {

    private static final long FRAME_MS = 33L;
    private static final int MOTES = 24;
    private static final long SCAN_PERIOD_MS = 9500L;

    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gridPaint = new Paint();
    private final Paint scanPaint = new Paint();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random(42L);

    private final float[] mx = new float[MOTES];
    private final float[] my = new float[MOTES];
    private final float[] mr = new float[MOTES];
    private final float[] mv = new float[MOTES];
    private final float[] mph = new float[MOTES];
    private final boolean[] violet = new boolean[MOTES];

    private final int cyan;
    private final int purple;
    private final float density;
    private float[] gridLines = new float[0];
    private float scanH;
    private int w;
    private int h;
    private boolean running = true;
    private long lastFrame;
    private long clock;

    public AmbientBackdropView(Context c) {
        super(c);
        cyan = c.getColor(R.color.primary);
        purple = c.getColor(R.color.accent);
        density = c.getResources().getDisplayMetrics().density;
        gridPaint.setColor((cyan & 0x00FFFFFF) | 0x0E000000);
        gridPaint.setStrokeWidth(Math.max(1f, density * 0.7f));
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        setWillNotDraw(false);
    }

    /** The activity calls this from onResume/onPause so nothing animates in the background. */
    public void setRunning(boolean running) {
        this.running = running;
        update();
    }

    @Override
    protected void onSizeChanged(int nw, int nh, int ow, int oh) {
        w = nw;
        h = nh;
        float step = 44f * density;
        int cols = (int) (w / step) + 1;
        int rows = (int) (h / step) + 1;
        gridLines = new float[(cols + rows) * 4];
        int k = 0;
        for (int i = 1; i <= cols; i++) {
            float x = i * step;
            gridLines[k++] = x;
            gridLines[k++] = 0f;
            gridLines[k++] = x;
            gridLines[k++] = h;
        }
        for (int j = 1; j <= rows; j++) {
            float y = j * step;
            gridLines[k++] = 0f;
            gridLines[k++] = y;
            gridLines[k++] = w;
            gridLines[k++] = y;
        }
        for (int i = 0; i < MOTES; i++) {
            mx[i] = rnd.nextFloat() * w;
            my[i] = rnd.nextFloat() * h;
            mr[i] = (0.7f + rnd.nextFloat() * 1.3f) * density;
            mv[i] = (5f + rnd.nextFloat() * 12f) * density;
            mph[i] = rnd.nextFloat() * 6.2832f;
            violet[i] = rnd.nextFloat() < 0.35f;
        }
        scanH = 110f * density;
        scanPaint.setShader(new LinearGradient(0f, 0f, 0f, scanH,
                new int[]{(cyan & 0x00FFFFFF), (cyan & 0x00FFFFFF) | 0x26000000,
                        (cyan & 0x00FFFFFF)}, null, Shader.TileMode.CLAMP));
    }

    // ------------------------------------------------------------------ animation

    private boolean shouldAnimate() {
        return running && isAttachedToWindow() && getWindowVisibility() == VISIBLE && isShown()
                && ValueAnimator.areAnimatorsEnabled();
    }

    private void update() {
        handler.removeCallbacks(frame);
        if (shouldAnimate()) {
            lastFrame = SystemClock.uptimeMillis();
            handler.postDelayed(frame, FRAME_MS);
        } else {
            invalidate();
        }
    }

    private final Runnable frame = new Runnable() {
        @Override
        public void run() {
            long now = SystemClock.uptimeMillis();
            long dt = Math.min(100L, Math.max(0L, now - lastFrame));
            lastFrame = now;
            clock += dt;
            float sec = dt / 1000f;
            for (int i = 0; i < MOTES; i++) {
                my[i] -= mv[i] * sec;
                if (my[i] < -8f * density) {
                    my[i] = h + 8f * density;
                    mx[i] = rnd.nextFloat() * w;
                }
            }
            invalidate();
            if (shouldAnimate()) {
                handler.postDelayed(this, FRAME_MS);
            }
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        update();
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacks(frame);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        update();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        update();
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas canvas) {
        if (w <= 0 || h <= 0) {
            return;
        }
        canvas.drawLines(gridLines, gridPaint);

        boolean moving = shouldAnimate();
        if (moving) {
            float t = (clock % SCAN_PERIOD_MS) / (float) SCAN_PERIOD_MS;
            float y = t * (h + scanH) - scanH;
            canvas.save();
            canvas.translate(0f, y);
            canvas.drawRect(0f, 0f, w, scanH, scanPaint);
            canvas.restore();
        }

        float seconds = clock / 1000f;
        for (int i = 0; i < MOTES; i++) {
            float twinkle = 0.5f + 0.5f * (float) Math.sin(seconds * 1.3f + mph[i]);
            int a = 0x1A + (int) (twinkle * 0x4A);
            int base = violet[i] ? purple : cyan;
            dotPaint.setColor((base & 0x00FFFFFF) | (a << 24));
            canvas.drawCircle(mx[i], my[i], mr[i], dotPaint);
        }
    }
}
