package com.btearbuds.autoconnect.bt;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.ParcelUuid;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/** Small, defensive helpers around public Bluetooth APIs. */
public final class BtUtil {

    private static final String UUID_A2DP_SINK = "0000110b";
    private static final String UUID_HANDSFREE = "0000111e";
    private static final String UUID_HEADSET = "00001108";

    private BtUtil() {
    }

    public static BluetoothAdapter adapter(Context context) {
        try {
            BluetoothManager m = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            return m == null ? null : m.getAdapter();
        } catch (RuntimeException e) {
            return null;
        }
    }

    /**
     * On Android 11 the install-time BLUETOOTH permission is enough. On Android 12+ the system
     * maps it to BLUETOOTH_CONNECT for apps like this one; we check it so we can explain clearly
     * instead of crashing if it is ever missing.
     */
    public static boolean hasPermission(Context context) {
        if (Build.VERSION.SDK_INT >= 31) {
            return context.checkSelfPermission("android.permission.BLUETOOTH_CONNECT")
                    == PackageManager.PERMISSION_GRANTED;
        }
        return context.checkSelfPermission(android.Manifest.permission.BLUETOOTH)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static String safeName(BluetoothDevice d) {
        if (d == null) {
            return "Unknown device";
        }
        try {
            String n = d.getName();
            if (n != null && n.trim().length() > 0) {
                return n;
            }
        } catch (SecurityException e) {
            // fall through
        }
        return "Unnamed device";
    }

    private static boolean hasUuidPrefix(BluetoothDevice d, String prefix) {
        try {
            ParcelUuid[] uuids = d.getUuids();
            if (uuids == null) {
                return false;
            }
            for (int i = 0; i < uuids.length; i++) {
                if (uuids[i] != null && uuids[i].toString().toLowerCase().startsWith(prefix)) {
                    return true;
                }
            }
        } catch (SecurityException e) {
            // ignore
        }
        return false;
    }

    /** Null when Android has not cached the device's service list, true/false otherwise. */
    public static Boolean advertisesA2dp(BluetoothDevice d) {
        try {
            if (d.getUuids() == null) {
                return null;
            }
        } catch (SecurityException e) {
            return null;
        }
        return Boolean.valueOf(hasUuidPrefix(d, UUID_A2DP_SINK));
    }

    public static Boolean advertisesHandsFree(BluetoothDevice d) {
        try {
            if (d.getUuids() == null) {
                return null;
            }
        } catch (SecurityException e) {
            return null;
        }
        return Boolean.valueOf(hasUuidPrefix(d, UUID_HANDSFREE) || hasUuidPrefix(d, UUID_HEADSET));
    }

    public static boolean isAudioDevice(BluetoothDevice d) {
        try {
            BluetoothClass bc = d.getBluetoothClass();
            if (bc != null) {
                if (bc.getMajorDeviceClass() == BluetoothClass.Device.Major.AUDIO_VIDEO) {
                    return true;
                }
                if (bc.hasService(BluetoothClass.Service.AUDIO)) {
                    return true;
                }
            }
        } catch (SecurityException e) {
            // fall through to UUID check
        }
        return hasUuidPrefix(d, UUID_A2DP_SINK) || hasUuidPrefix(d, UUID_HANDSFREE)
                || hasUuidPrefix(d, UUID_HEADSET);
    }

    /** A plain-language type, only when Android reports it. */
    public static String typeLabel(BluetoothDevice d) {
        try {
            BluetoothClass bc = d.getBluetoothClass();
            if (bc != null) {
                switch (bc.getDeviceClass()) {
                    case BluetoothClass.Device.AUDIO_VIDEO_HEADPHONES:
                        return "Headphones";
                    case BluetoothClass.Device.AUDIO_VIDEO_WEARABLE_HEADSET:
                        return "Headset / earbuds";
                    case BluetoothClass.Device.AUDIO_VIDEO_HANDSFREE:
                        return "Hands-free";
                    case BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER:
                    case BluetoothClass.Device.AUDIO_VIDEO_PORTABLE_AUDIO:
                    case BluetoothClass.Device.AUDIO_VIDEO_HIFI_AUDIO:
                        return "Speaker";
                    case BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO:
                        return "Car audio";
                    default:
                        break;
                }
            }
        } catch (SecurityException e) {
            // fall through
        }
        return isAudioDevice(d) ? "Audio device" : "Other Bluetooth device";
    }

    /** "Classic only", "Bluetooth LE", "Classic + LE" or null if Android does not say. */
    public static String transportLabel(BluetoothDevice d) {
        try {
            switch (d.getType()) {
                case BluetoothDevice.DEVICE_TYPE_CLASSIC:
                    return "Classic only";
                case BluetoothDevice.DEVICE_TYPE_LE:
                    return "Bluetooth LE";
                case BluetoothDevice.DEVICE_TYPE_DUAL:
                    return "Classic + LE";
                default:
                    return null;
            }
        } catch (SecurityException e) {
            return null;
        }
    }

    /** Paired devices, audio devices first (or all if {@code includeOthers}). */
    public static List<BluetoothDevice> pairedDevices(Context context, boolean includeOthers) {
        List<BluetoothDevice> out = new ArrayList<BluetoothDevice>();
        BluetoothAdapter a = adapter(context);
        if (a == null) {
            return out;
        }
        try {
            if (!a.isEnabled()) {
                return out;
            }
            Set<BluetoothDevice> bonded = a.getBondedDevices();
            if (bonded == null) {
                return out;
            }
            for (BluetoothDevice d : bonded) {
                if (includeOthers || isAudioDevice(d)) {
                    out.add(d);
                }
            }
        } catch (SecurityException e) {
            return new ArrayList<BluetoothDevice>();
        }
        Collections.sort(out, new Comparator<BluetoothDevice>() {
            @Override
            public int compare(BluetoothDevice x, BluetoothDevice y) {
                boolean ax = isAudioDevice(x);
                boolean ay = isAudioDevice(y);
                if (ax != ay) {
                    return ax ? -1 : 1;
                }
                return safeName(x).compareToIgnoreCase(safeName(y));
            }
        });
        return out;
    }
}
