package com.btearbuds.autoconnect.treble;

import android.content.Context;
import android.content.SharedPreferences;

/** Treble Lab settings. Kept in their own file so they stay separate from Bluetooth settings. */
public final class TreblePrefs {

    private static final String FILE = "treble";
    private static final String K_ENABLED = "enabled";
    private static final String K_HALF_DB = "half_db";
    private static final String K_PRESET = "preset";
    private static final String K_CUSTOM_HALF_DB = "custom_half_db";

    private final SharedPreferences sp;

    public TreblePrefs(Context context) {
        sp = context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public boolean enabled() {
        return sp.getBoolean(K_ENABLED, false);
    }

    public void setEnabled(boolean v) {
        sp.edit().putBoolean(K_ENABLED, v).apply();
    }

    /** The chosen treble amount in dB (0.5 dB steps). The default is neutral. */
    public double db() {
        return sp.getInt(K_HALF_DB, 0) / 2.0;
    }

    public void setDb(double db) {
        sp.edit().putInt(K_HALF_DB, (int) Math.round(TrebleMath.snap(db) * 2.0)).apply();
    }

    /** Which preset chip is selected. Moving the dial by hand switches to Custom. */
    public TrebleMath.Preset preset() {
        try {
            return TrebleMath.Preset.valueOf(sp.getString(K_PRESET, TrebleMath.Preset.NEUTRAL.name()));
        } catch (IllegalArgumentException e) {
            return TrebleMath.Preset.NEUTRAL;
        }
    }

    public void setPreset(TrebleMath.Preset p) {
        sp.edit().putString(K_PRESET, p.name()).apply();
    }

    /** The last value the user set by hand, restored when "Custom" is tapped. */
    public double customDb() {
        return sp.getInt(K_CUSTOM_HALF_DB, 0) / 2.0;
    }

    public boolean hasCustom() {
        return sp.contains(K_CUSTOM_HALF_DB);
    }

    public void setCustomDb(double db) {
        sp.edit().putInt(K_CUSTOM_HALF_DB, (int) Math.round(TrebleMath.snap(db) * 2.0)).apply();
    }
}
