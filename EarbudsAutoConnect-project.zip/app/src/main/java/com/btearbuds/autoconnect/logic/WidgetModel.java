package com.btearbuds.autoconnect.logic;

/**
 * Decides what a home-screen widget may honestly show. The widget cannot watch Bluetooth by
 * itself: it only shows what the app last saw. When the app is not watching right now, the
 * widget says "last known" and shows no live timer and no battery number. Pure Java.
 */
public final class WidgetModel {

    public enum Mode {
        NO_DEVICE, LIVE, LAST_KNOWN
    }

    /** Colour tone for the status dot / text. */
    public static final int TONE_IDLE = 0;
    public static final int TONE_OK = 1;
    public static final int TONE_WARN = 2;
    public static final int TONE_ERROR = 3;

    public final Mode mode;
    public final String name;
    public final String statusLabel;
    public final int tone;
    public final boolean connected;
    public final long connectedSince;
    public final boolean sinceExact;
    public final int batteryPercent;
    /** Exact text when the earbuds report left/right separately, e.g. "L 80% · R 75%"; else null. */
    public final String batteryDetail;
    public final long updatedAt;

    private WidgetModel(Mode mode, String name, String statusLabel, int tone, boolean connected,
                        long connectedSince, boolean sinceExact, int batteryPercent,
                        String batteryDetail, long updatedAt) {
        this.mode = mode;
        this.name = name;
        this.statusLabel = statusLabel;
        this.tone = tone;
        this.connected = connected;
        this.connectedSince = connectedSince;
        this.sinceExact = sinceExact;
        this.batteryPercent = batteryPercent;
        this.batteryDetail = batteryDetail;
        this.updatedAt = updatedAt;
    }

    /**
     * @param batteryPercent the live reading, or -1 when the earbuds report none
     * @param batteryDetail  exact left/right text when no single value exists, else null
     * @param observing      true only while the app is watching Bluetooth right now
     */
    public static WidgetModel from(boolean hasDevice, String name, String statusLabel, int tone,
                                   boolean connected, long connectedSince, boolean sinceExact,
                                   int batteryPercent, String batteryDetail, boolean observing,
                                   long updatedAt) {
        if (!hasDevice) {
            return new WidgetModel(Mode.NO_DEVICE, null, "No earbuds selected", TONE_IDLE, false,
                    0L, false, -1, null, updatedAt);
        }
        int bat = (batteryPercent >= 0 && batteryPercent <= 100) ? batteryPercent : -1;
        if (!observing) {
            return new WidgetModel(Mode.LAST_KNOWN, name, statusLabel, TONE_IDLE, connected,
                    connectedSince, sinceExact, -1, null, updatedAt);
        }
        String detail = (connected && bat < 0 && batteryDetail != null && batteryDetail.length() > 0)
                ? batteryDetail : null;
        return new WidgetModel(Mode.LIVE, name, statusLabel, tone, connected,
                connected ? connectedSince : 0L, sinceExact, connected ? bat : -1, detail,
                updatedAt);
    }

    /** A running timer is only honest while live, connected and the start time is known. */
    public boolean showElapsed() {
        return mode == Mode.LIVE && connected && connectedSince > 0L;
    }

    public boolean showSince() {
        return mode != Mode.NO_DEVICE && connected && connectedSince > 0L;
    }

    /** True when there is a real reading (single value, or left/right text) to show. */
    public boolean showBattery() {
        return mode == Mode.LIVE && connected && (batteryPercent >= 0 || batteryDetail != null);
    }

    /** "87%", or a short honest placeholder. */
    public String batteryText() {
        if (mode == Mode.NO_DEVICE) {
            return "";
        }
        if (showBattery()) {
            return batteryPercent >= 0 ? batteryPercent + "%" : batteryDetail;
        }
        if (mode == Mode.LAST_KNOWN) {
            return "Battery --";
        }
        return connected ? "No battery data" : "";
    }
}
