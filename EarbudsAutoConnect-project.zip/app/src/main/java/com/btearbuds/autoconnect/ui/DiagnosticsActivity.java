package com.btearbuds.autoconnect.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.LinearLayout;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.bt.BtController;
import com.btearbuds.autoconnect.bt.Compat;
import com.btearbuds.autoconnect.bt.Diagnostics;
import com.btearbuds.autoconnect.bt.Snapshot;
import com.btearbuds.autoconnect.data.Prefs;

import java.util.List;

/** Self-diagnostics and the feature-compatibility table, all computed from live state. */
public final class DiagnosticsActivity extends Activity implements BtController.Listener {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private BtController controller;
    private Prefs prefs;
    private boolean holding;
    private LinearLayout page;
    private List<Diagnostics.Item> items;
    private List<Compat.Row> compat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        controller = BtController.get(this);
        page = Ui.page(this, "Diagnostics");
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!holding) {
            holding = true;
            controller.addListener(this);
            controller.acquire(false);
        }
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    @Override
    protected void onStop() {
        handler.removeCallbacksAndMessages(null);
        if (holding) {
            holding = false;
            controller.removeListener(this);
            controller.release(false);
        }
        super.onStop();
    }

    @Override
    public void onSnapshot(Snapshot s) {
        handler.removeCallbacks(renderRunnable);
        handler.postDelayed(renderRunnable, 400L);
    }

    private final Runnable renderRunnable = new Runnable() {
        @Override
        public void run() {
            render();
        }
    };

    private void render() {
        Snapshot s = controller.snapshot();
        items = Diagnostics.run(this, s, prefs);
        compat = Compat.evaluate(s, Diagnostics.ignoringBatteryOptimizations(this));

        page.removeAllViews();
        page.addView(Ui.title(this, "Diagnostics"));
        Ui.add(page, Ui.small(this, "Everything here is read live from Android. If something can't "
                + "be known, it says so instead of guessing."), 4);

        LinearLayout actions = Ui.row(this);
        actions.addView(Ui.button(this, "Copy report", Ui.BTN_TONAL, v -> copyReport()),
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        actions.addView(Ui.button(this, "Bluetooth settings", Ui.BTN_TEXT,
                v -> Ui.openBluetoothSettings(this)),
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Ui.add(page, actions, 8);

        Ui.add(page, Ui.heading(this, "STATUS CHECKS"), 16);
        for (Diagnostics.Item i : items) {
            LinearLayout card = Ui.card(this);
            LinearLayout head = Ui.row(this);
            head.addView(Ui.dot(this, Ui.col(this, sevColor(i.sev))));
            head.addView(Ui.text(this, i.title + "  ·  " + sevLabel(i.sev), 15,
                    R.color.text_primary, true));
            card.addView(head);
            Ui.add(card, Ui.body(this, i.text), 6);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, Ui.dp(this, 8), 0, 0);
            page.addView(card, lp);
        }

        Ui.add(page, Ui.heading(this, "WHAT WORKS ON THIS PHONE AND THESE EARBUDS"), 20);
        LinearLayout table = Ui.card(this);
        boolean first = true;
        for (Compat.Row r : compat) {
            LinearLayout row = Ui.column(this);
            LinearLayout head = Ui.row(this);
            head.addView(Ui.dot(this, Ui.col(this, levelColor(r.level))));
            head.addView(Ui.text(this, r.title, 14, R.color.text_primary, true));
            row.addView(head);
            Ui.add(row, Ui.small(this, r.level.label + " - " + r.detail), 2);
            Ui.add(table, row, first ? 0 : 14);
            first = false;
        }
        Ui.add(page, table, 8);
    }

    private static int sevColor(Diagnostics.Sev s) {
        switch (s) {
            case OK:
                return R.color.ok;
            case WARN:
                return R.color.warn;
            case ERROR:
                return R.color.error;
            default:
                return R.color.idle;
        }
    }

    private static String sevLabel(Diagnostics.Sev s) {
        switch (s) {
            case OK:
                return "OK";
            case WARN:
                return "Check";
            case ERROR:
                return "Problem";
            default:
                return "Info";
        }
    }

    private static int levelColor(Compat.Level l) {
        switch (l) {
            case SUPPORTED:
                return R.color.ok;
            case PARTIAL:
                return R.color.warn;
            case UNAVAILABLE:
                return R.color.error;
            default:
                return R.color.idle;
        }
    }

    private void copyReport() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null) {
            Ui.toast(this, "Clipboard isn't available.");
            return;
        }
        cm.setPrimaryClip(ClipData.newPlainText("Earbuds Auto-Connect diagnostics",
                Diagnostics.report(this, items, compat)));
        Ui.toast(this, "Report copied. It includes your earbuds' name and your phone model - "
                + "check it before sharing.");
    }
}
