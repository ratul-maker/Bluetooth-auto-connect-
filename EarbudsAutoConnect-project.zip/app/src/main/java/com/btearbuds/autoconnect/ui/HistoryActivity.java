package com.btearbuds.autoconnect.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.bt.StatusText;
import com.btearbuds.autoconnect.data.Db;
import com.btearbuds.autoconnect.data.Prefs;
import com.btearbuds.autoconnect.logic.DurationFormat;
import com.btearbuds.autoconnect.logic.InsightCalculator;
import com.btearbuds.autoconnect.logic.ListenStats;
import com.btearbuds.autoconnect.logic.SessionTimeline;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * Local-only history: connection sessions (with a clear line between what the app recorded and the
 * time it could not observe), listening time per day, stored battery readings with observed
 * changes, and a connection log.
 */
public final class HistoryActivity extends Activity {

    private static final long WINDOW_MS = 14L * 24L * 60L * 60L * 1000L;
    private static final int MAX_SESSIONS_SHOWN = 6;
    private static final int MAX_CONNECTION_SESSIONS_SHOWN = 60;
    private static final long MIN_GAP_SHOWN_MS = 60L * 1000L;

    private Db db;
    private Prefs prefs;
    private LinearLayout page;
    /** Streaming spans for the sessions on screen (filled by renderSessions). */
    private List<ListenStats.Span> sessionListen = new ArrayList<ListenStats.Span>();
    private long listenTrackingSince;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = Db.get(this);
        prefs = new Prefs(this);
        page = Ui.page(this, "History");
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        page.removeAllViews();
        page.addView(Ui.title(this, "History"));
        Ui.add(page, Ui.small(this, "Stored only on this phone. Nothing is sent anywhere."), 4);

        renderSessions();
        renderListening();
        renderBattery();
        renderLog();
    }

    // ------------------------------------------------------------------ connection sessions

    private void renderSessions() {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.heading(this, "CONNECTION SESSIONS"));
        Ui.add(card, Ui.small(this, "Each block is one connection of your earbuds. The app can only "
                + "record what it sees while it is running, so the gaps are shown instead of guessed."),
                6);

        LinearLayout legend = Ui.column(this);
        legend.addView(legendRow(R.color.primary, "Recorded: the app saw it start and end."));
        legend.addView(legendRow(R.color.accent, "Partly seen: the app missed the start or the end."));
        legend.addView(legendRow(R.color.text_dim, "Not observed: the app wasn't watching."));
        Ui.add(card, legend, 10);

        List<Db.SessionRow> rows = db.recentSessions(MAX_CONNECTION_SESSIONS_SHOWN);
        if (rows.isEmpty()) {
            Ui.add(card, Ui.body(this, "No sessions yet. One is saved each time your earbuds connect "
                    + "while this app is watching (open, or Background Monitoring on)."), 12);
            Ui.addCard(page, card);
            return;
        }

        long now = System.currentTimeMillis();
        List<SessionTimeline.Session> sessions = new ArrayList<SessionTimeline.Session>();
        for (Db.SessionRow r : rows) {
            sessions.add(new SessionTimeline.Session(r.name, r.start, r.end, r.startExact,
                    r.endExact));
        }
        long oldest = rows.get(rows.size() - 1).start;
        listenTrackingSince = prefs.listenTrackingSince();
        sessionListen = new ArrayList<ListenStats.Span>();
        for (Db.ListenRow r : db.listenSince(oldest - 1L)) {
            sessionListen.add(new ListenStats.Span(r.start, r.end, r.startExact, r.endExact));
        }
        List<SessionTimeline.Window> windows = new ArrayList<SessionTimeline.Window>();
        for (Db.WindowRow w : db.windowsSince(oldest - 1L)) {
            windows.add(new SessionTimeline.Window(w.start, w.end));
        }
        List<SessionTimeline.Item> items = SessionTimeline.build(sessions, windows, now,
                MIN_GAP_SHOWN_MS);
        for (SessionTimeline.Item item : items) {
            Ui.add(card, item.isGap() ? gapView(item) : sessionView(item.session, now), 10);
        }
        Ui.add(card, Ui.small(this, "Times are shown to the second. \"At least\" means the real value "
                + "may be longer."), 12);
        Ui.add(card, Ui.button(this, "Clear session history", Ui.BTN_TEXT, v -> confirm(
                "Clear session history?", "Finished sessions and their gap information will be "
                        + "deleted. A connection that is happening right now is kept.",
                () -> {
                    db.clearSessions();
                    render();
                })), 6);
        Ui.addCard(page, card);
    }

    private LinearLayout legendRow(int colorRes, String text) {
        LinearLayout row = Ui.row(this);
        row.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 2));
        row.addView(Ui.dot(this, Ui.col(this, colorRes)));
        row.addView(Ui.small(this, text));
        return row;
    }

    private LinearLayout sessionView(SessionTimeline.Session s, long now) {
        boolean open = s.isOpen();
        boolean full = s.fullyRecorded();
        int accent = Ui.col(this, open && s.startExact ? R.color.ok : (full ? R.color.primary
                : R.color.accent));
        LinearLayout box = Ui.column(this);
        box.setBackground(Ui.rect(this, Ui.col(this, R.color.surface_variant),
                (accent & 0x00FFFFFF) | 0x99000000, 1, 16));
        box.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));

        LinearLayout head = Ui.row(this);
        TextView name = Ui.text(this, s.name != null ? s.name : "Earbuds", 15, R.color.text_primary, true);
        head.addView(name, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        String badge = open ? "ONGOING" : (full ? "RECORDED" : "PARTLY SEEN");
        TextView b = Ui.text(this, badge, 10, open ? R.color.ok : (full ? R.color.primary
                : R.color.accent), true);
        b.setLetterSpacing(0.12f);
        head.addView(b);
        box.addView(head);

        StringBuilder start = new StringBuilder("Start   ").append(StatusText.whenExact(this, s.start));
        if (!s.startExact) {
            start.append("\n          first seen: already connected when the app began watching");
        }
        Ui.add(box, Ui.body(this, start.toString()), 8);

        StringBuilder end = new StringBuilder("End     ");
        if (open) {
            end.append("still connected");
        } else {
            end.append(StatusText.whenExact(this, s.end));
            if (!s.endExact) {
                end.append("\n          last seen: the app stopped watching, so the connection "
                        + "may have lasted longer");
            }
        }
        Ui.add(box, Ui.body(this, end.toString()), 4);

        String dur = InsightCalculator.formatDuration(s.durationMs(now));
        String durLine;
        if (open) {
            durLine = s.startExact ? "Duration so far   " + dur : "Duration   at least " + dur + " so far";
        } else if (s.startExact && s.endExact) {
            durLine = "Duration   " + dur + "  (" + DurationFormat.clock(s.durationMs(now)) + ")";
        } else {
            durLine = "Duration   at least " + dur;
        }
        Ui.add(box, Ui.text(this, durLine, 14, R.color.text_primary, true), 8);

        // Only sessions that began after listening-time tracking existed get a figure.
        if (listenTrackingSince > 0L && s.start >= listenTrackingSince) {
            ListenStats.Total t = ListenStats.duringSession(sessionListen, s.start, s.end, now);
            boolean atLeast = t.partial || !s.startExact || (!open && !s.endExact);
            String line;
            if (t.ms <= 0L) {
                line = "Listened   no streaming seen";
            } else {
                line = "Listened   " + (atLeast ? "at least " : "")
                        + InsightCalculator.formatDuration(t.ms) + "  ("
                        + DurationFormat.clock(t.ms) + ")";
            }
            Ui.add(box, Ui.text(this, line, 14, R.color.accent, true), 4);
        }
        return box;
    }

    private LinearLayout gapView(SessionTimeline.Item gap) {
        LinearLayout box = Ui.column(this);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x00000000);
        g.setCornerRadius(Ui.dp(this, 16));
        g.setStroke(Ui.dp(this, 1), Ui.col(this, R.color.text_dim), Ui.dp(this, 5), Ui.dp(this, 4));
        box.setBackground(g);
        box.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));

        long un = gap.unobservedMs;
        long seen = gap.observedMs();
        String title;
        String detail;
        if (un <= 0L) {
            title = "Watched, nothing connected \u00b7 " + InsightCalculator.formatDuration(gap.gapMs());
            detail = "The app was watching the whole time and saw no connection.";
        } else {
            title = "Not observed \u00b7 " + InsightCalculator.formatDuration(un);
            detail = "Between " + StatusText.when(this, gap.gapStart) + " and "
                    + StatusText.when(this, gap.gapEnd) + " the app wasn't running, so nothing is "
                    + "known about the earbuds for that time.";
            if (seen >= MIN_GAP_SHOWN_MS) {
                detail += " It was watching for " + InsightCalculator.formatDuration(seen)
                        + " of it and saw no connection.";
            }
        }
        box.addView(Ui.text(this, title, 13, R.color.text_secondary, true));
        Ui.add(box, Ui.small(this, detail), 4);
        return box;
    }

    // ------------------------------------------------------------------ listening time

    private void renderListening() {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.heading(this, "LISTENING TIME"));
        Ui.add(card, Ui.small(this, "How long Android sent audio to your earbuds, per day. It counts "
                + "any sound - music, video, games - and can't tell which app made it. Only time "
                + "this app was watching is counted, so a day can be longer than shown."), 6);

        // Day k (0 = today) covers [starts[k + 1], starts[k]).
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        long[] starts = new long[8];
        cal.add(Calendar.DAY_OF_YEAR, 1);
        starts[0] = cal.getTimeInMillis();
        for (int i = 1; i <= 7; i++) {
            cal.add(Calendar.DAY_OF_YEAR, -1);
            starts[i] = cal.getTimeInMillis();
        }

        long now = System.currentTimeMillis();
        List<ListenStats.Span> spans = new ArrayList<ListenStats.Span>();
        for (Db.ListenRow r : db.listenSince(starts[7])) {
            spans.add(new ListenStats.Span(r.start, r.end, r.startExact, r.endExact));
        }
        ListenStats.Total[] totals = new ListenStats.Total[7];
        long max = 0L;
        boolean any = false;
        for (int k = 0; k < 7; k++) {
            totals[k] = ListenStats.total(spans, starts[k + 1], starts[k], now);
            max = Math.max(max, totals[k].ms);
            any |= totals[k].ms > 0L;
        }

        if (!any) {
            Ui.add(card, Ui.body(this, "No streaming recorded yet. It is counted while your earbuds "
                    + "are connected and this app is watching (open, or Background Monitoring on)."),
                    10);
            Ui.addCard(page, card);
            return;
        }

        SimpleDateFormat dayFmt = new SimpleDateFormat("EEE, MMM d", Locale.getDefault());
        for (int k = 0; k < 7; k++) {
            String label = k == 0 ? "Today" : (k == 1 ? "Yesterday"
                    : dayFmt.format(new java.util.Date(starts[k + 1])));
            Ui.add(card, dayRow(label, totals[k], max), 10);
        }
        Ui.add(card, Ui.small(this, "A + after a time means at least that much: part of it wasn't "
                + "fully seen."), 10);

        // How much of today the app was really watching, so the numbers can be read in context.
        long watched = 0L;
        List<SessionTimeline.Window> windows = new ArrayList<SessionTimeline.Window>();
        for (Db.WindowRow w : db.windowsSince(starts[1])) {
            windows.add(new SessionTimeline.Window(w.start, w.end));
        }
        watched = SessionTimeline.coveredMs(windows, starts[1], now, now);
        Ui.add(card, Ui.small(this, "Today the app was watching for "
                + InsightCalculator.formatDuration(watched) + " so far."), 4);

        Ui.add(card, Ui.button(this, "Clear listening history", Ui.BTN_TEXT, v -> confirm(
                "Clear listening history?", "Stored listening time will be deleted. Streaming "
                        + "that is happening right now is kept.", () -> {
                    db.clearListen();
                    render();
                })), 6);
        Ui.addCard(page, card);
    }

    private LinearLayout dayRow(String label, ListenStats.Total t, long max) {
        LinearLayout row = Ui.row(this);
        TextView l = Ui.text(this, label, 13, R.color.text_secondary, false);
        row.addView(l, new LinearLayout.LayoutParams(Ui.dp(this, 92),
                LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout track = new LinearLayout(this);
        track.setOrientation(LinearLayout.HORIZONTAL);
        track.setBackground(Ui.rect(this, Ui.col(this, R.color.surface_variant), 0, 0, 6));
        float frac = max > 0L ? t.ms / (float) max : 0f;
        int fillW = t.ms > 0L ? Math.max(6, Math.round(frac * 1000f)) : 0;
        if (fillW > 0) {
            View fill = new View(this);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Ui.col(this, R.color.primary), Ui.col(this, R.color.accent)});
            g.setCornerRadius(Ui.dp(this, 6));
            fill.setBackground(g);
            track.addView(fill, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT,
                    fillW));
        }
        View rest = new View(this);
        track.addView(rest, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT,
                Math.max(1, 1000 - fillW)));
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, Ui.dp(this, 12), 1f);
        tl.setMargins(Ui.dp(this, 6), 0, Ui.dp(this, 10), 0);
        row.addView(track, tl);

        String v = t.ms > 0L ? InsightCalculator.formatDuration(t.ms) + (t.partial ? "+" : "") : "-";
        TextView val = Ui.text(this, v, 13, R.color.text_primary, true);
        val.setGravity(android.view.Gravity.END);
        row.addView(val, new LinearLayout.LayoutParams(Ui.dp(this, 82),
                LinearLayout.LayoutParams.WRAP_CONTENT));
        return row;
    }

    // ------------------------------------------------------------------ battery

    private void renderBattery() {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.heading(this, "BATTERY HISTORY"));

        if (!prefs.batteryHistory()) {
            Ui.add(card, Ui.body(this, "Battery history is turned off. You can turn it on in "
                    + "Settings."), 6);
            Ui.addCard(page, card);
            return;
        }

        long now = System.currentTimeMillis();
        List<Db.BatteryRow> rows = db.batterySince(now - WINDOW_MS);
        List<InsightCalculator.Point> points = new ArrayList<InsightCalculator.Point>();
        boolean coarse = false;
        for (Db.BatteryRow r : rows) {
            if ("single".equals(r.kind)) {
                points.add(new InsightCalculator.Point(r.time, r.level));
                if (r.source != null && r.source.contains("10%")) {
                    coarse = true;
                }
            }
        }
        List<InsightCalculator.Session> sessions = InsightCalculator.split(points);
        List<InsightCalculator.Session> good = new ArrayList<InsightCalculator.Session>();
        for (InsightCalculator.Session s : sessions) {
            if (s.isSufficient()) {
                good.add(s);
            }
        }

        if (good.isEmpty()) {
            String msg = points.isEmpty()
                    ? "No battery readings have been stored yet. Readings are saved only when your "
                    + "earbuds actually report a battery level."
                    : "Not enough real data yet: " + points.size() + " reading(s) stored. A trend "
                    + "needs at least two readings about 10 minutes apart in the same session.";
            Ui.add(card, Ui.body(this, msg), 6);
        } else {
            InsightCalculator.Session latest = good.get(good.size() - 1);
            long[] t = new long[latest.points.size()];
            int[] v = new int[latest.points.size()];
            for (int i = 0; i < t.length; i++) {
                t[i] = latest.points.get(i).time;
                v[i] = latest.points.get(i).level;
            }
            LineChartView chart = new LineChartView(this);
            chart.setData(t, v);
            chart.setContentDescription("Battery went from " + latest.startLevel() + " to "
                    + latest.endLevel() + " percent");
            Ui.add(card, chart, 8);

            Ui.add(card, Ui.body(this, "Latest session: " + latest.startLevel() + "% to "
                    + latest.endLevel() + "% over "
                    + InsightCalculator.formatDuration(latest.spanMs()) + " ("
                    + signed(latest.change()) + " points)."), 8);

            StringBuilder list = new StringBuilder();
            int shown = 0;
            for (int i = good.size() - 1; i >= 0 && shown < MAX_SESSIONS_SHOWN; i--, shown++) {
                InsightCalculator.Session s = good.get(i);
                if (list.length() > 0) {
                    list.append("\n");
                }
                list.append(StatusText.when(this, s.startTime())).append(": ")
                        .append(s.startLevel()).append("% → ").append(s.endLevel()).append("% (")
                        .append(InsightCalculator.formatDuration(s.spanMs())).append(")");
            }
            Ui.add(card, Ui.heading(this, "RECENT SESSIONS"), 14);
            Ui.add(card, Ui.body(this, list.toString()), 4);
        }

        String caveat = "This only shows what was actually recorded. It is not a prediction of "
                + "remaining playtime.";
        if (coarse) {
            caveat += " Your earbuds report in 10% steps, so small changes can't be seen.";
        }
        Ui.add(card, Ui.small(this, caveat), 10);

        if (!points.isEmpty()) {
            Ui.add(card, Ui.button(this, "Clear battery history", Ui.BTN_TEXT, v -> confirm(
                    "Clear battery history?", "All stored battery readings will be deleted.",
                    () -> {
                        db.clearBattery();
                        render();
                    })), 6);
        }
        Ui.addCard(page, card);
    }

    private static String signed(int v) {
        return v > 0 ? "+" + v : String.valueOf(v);
    }

    // ------------------------------------------------------------------ connection log

    private void renderLog() {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.heading(this, "CONNECTION LOG"));

        List<Db.LogRow> logs = db.recentLogs(200);
        if (logs.isEmpty()) {
            Ui.add(card, Ui.body(this, "Nothing logged yet. Connections, disconnections and failed "
                    + "attempts will appear here."), 6);
        } else {
            for (Db.LogRow r : logs) {
                LinearLayout row = Ui.column(this);
                TextView head = Ui.text(this, label(r.type) + "  ·  "
                        + StatusText.when(this, r.time), 13, colorFor(r.type), true);
                row.addView(head);
                if (r.detail != null && r.detail.length() > 0) {
                    row.addView(Ui.small(this, r.detail));
                }
                Ui.add(card, row, 10);
            }
            Ui.add(card, Ui.button(this, "Clear connection history", Ui.BTN_TEXT, v -> confirm(
                    "Clear connection history?", "The log of connections and attempts will be deleted.",
                    () -> {
                        db.clearLogs();
                        render();
                    })), 12);
        }
        Ui.addCard(page, card);
    }

    private static String label(String type) {
        if (type == null) {
            return "Event";
        }
        switch (type) {
            case "CONNECTED":
                return "Connected";
            case "DISCONNECTED":
                return "Disconnected";
            case "ATTEMPT":
                return "Attempt";
            case "ATTEMPT_FAILED":
                return "Attempt failed";
            case "GAVE_UP":
                return "Retries paused";
            case "SKIPPED":
                return "Skipped";
            case "CANNOT_REQUEST":
                return "Can't request";
            case "LINK_UP":
                return "Link up";
            case "LINK_DOWN":
                return "Link down";
            case "LINKED_NO_AUDIO":
                return "Nearby, no audio";
            case "BT_ON":
                return "Bluetooth on";
            case "BT_OFF":
                return "Bluetooth off";
            case "UNPAIRED":
                return "Unpaired";
            case "DEVICE_SELECTED":
                return "Device selected";
            default:
                return type;
        }
    }

    private static int colorFor(String type) {
        if (type == null) {
            return R.color.text_secondary;
        }
        switch (type) {
            case "CONNECTED":
                return R.color.ok;
            case "ATTEMPT_FAILED":
            case "UNPAIRED":
                return R.color.error;
            case "GAVE_UP":
            case "LINKED_NO_AUDIO":
            case "CANNOT_REQUEST":
            case "SKIPPED":
                return R.color.warn;
            default:
                return R.color.text_secondary;
        }
    }

    private void confirm(String title, String message, final Runnable onYes) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear", (d, w) -> onYes.run())
                .show();
    }
}
