package com.btearbuds.autoconnect.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.animation.DecelerateInterpolator;
import android.view.View;

import com.btearbuds.autoconnect.R;

/**
 * A ring that shows a battery percentage the earbuds really reported. With no reading it shows a
 * dashed, empty ring and "--": it never draws a made-up level.
 */
public final class BatteryRingView extends View {

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();

    private int target = -2; // -2 = nothing set yet, -1 = set to "not reported"
    private float shown;
    private ValueAnimator anim;
    private final int sizeDp;

    public BatteryRingView(Context c, int sizeDp) {
        super(c);
        this.sizeDp = sizeDp;
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        text.setColor(c.getColor(R.color.text_primary));
        setLevel(-1);
    }

    /** @param percent 0..100, or -1 when the earbuds report nothing */
    public void setLevel(int percent) {
        int p = (percent < 0 || percent > 100) ? -1 : percent;
        if (p == target) {
            return;
        }
        int old = target;
        target = p;
        setContentDescription(p < 0 ? "Battery not reported" : "Battery " + p + " percent");
        if (anim != null) {
            anim.cancel();
        }
        if (p < 0 || old < 0 || !isAttachedToWindow() || !ValueAnimator.areAnimatorsEnabled()) {
            shown = Math.max(0, p);
            invalidate();
            return;
        }
        anim = ValueAnimator.ofFloat(shown, p);
        anim.setDuration(450L);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            shown = (Float) a.getAnimatedValue();
            invalidate();
        });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.cancel();
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int px = Ui.dp(getContext(), sizeDp);
        setMeasuredDimension(px, px);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        float stroke = Math.max(Ui.dp(getContext(), 4), w * 0.09f);
        track.setStrokeWidth(stroke);
        arc.setStrokeWidth(stroke);
        float inset = stroke / 2f + Ui.dp(getContext(), 1);
        oval.set(inset, inset, w - inset, h - inset);
        text.setTextSize(w * 0.30f);
        Context c = getContext();
        arc.setShader(new SweepGradient(w / 2f, h / 2f,
                new int[]{c.getColor(R.color.accent), c.getColor(R.color.primary),
                        c.getColor(R.color.primary)},
                new float[]{0f, 0.7f, 1f}));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Context c = getContext();
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        if (target < 0) {
            track.setColor(c.getColor(R.color.text_dim));
            track.setAlpha(0x80);
            float dash = Math.max(Ui.dp(c, 3), getWidth() * 0.05f);
            track.setPathEffect(new DashPathEffect(new float[]{dash, dash * 1.6f}, 0f));
            canvas.drawArc(oval, 0f, 360f, false, track);
            track.setPathEffect(null);
            text.setColor(c.getColor(R.color.text_dim));
            canvas.drawText("--", cx, cy - (text.descent() + text.ascent()) / 2f, text);
            return;
        }
        track.setColor(c.getColor(R.color.surface_high));
        track.setAlpha(0xFF);
        canvas.drawArc(oval, 0f, 360f, false, track);

        float sweep = 360f * Math.max(0f, Math.min(100f, shown)) / 100f;
        if (target <= 15) {
            arc.setShader(null);
            arc.setColor(c.getColor(R.color.error));
        } else if (target <= 30) {
            arc.setShader(null);
            arc.setColor(c.getColor(R.color.warn));
        } else if (arc.getShader() == null) {
            arc.setShader(new SweepGradient(cx, cy,
                    new int[]{c.getColor(R.color.accent), c.getColor(R.color.primary),
                            c.getColor(R.color.primary)}, new float[]{0f, 0.7f, 1f}));
        }
        canvas.save();
        canvas.rotate(-90f, cx, cy);
        if (sweep > 0f) {
            canvas.drawArc(oval, 0f, sweep, false, arc);
        }
        canvas.restore();

        text.setColor(c.getColor(R.color.text_primary));
        canvas.drawText(target + "%", cx, cy - (text.descent() + text.ascent()) / 2f, text);
    }
}
