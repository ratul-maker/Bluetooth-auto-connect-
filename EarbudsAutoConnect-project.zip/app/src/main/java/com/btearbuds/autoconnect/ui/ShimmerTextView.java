package com.btearbuds.autoconnect.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;

import com.btearbuds.autoconnect.R;

/**
 * A line of text with a slow cyan-to-violet light sweep. The sweep runs only while the screen is in
 * front and only if Android's animations are on (it is off in Battery Saver); otherwise the text
 * simply wears a still cyan-to-violet gradient. It is a plain shader on the text, so it is cheap.
 */
public final class ShimmerTextView extends TextView {

    private static final long PERIOD_MS = 4600L;
    /** Share of each period spent sweeping; the rest is a rest pause. */
    private static final float SWEEP_SHARE = 0.7f;

    private final Matrix matrix = new Matrix();
    private final int baseColor;
    private final int midA;
    private final int midB;
    private LinearGradient sweep;
    private LinearGradient still;
    private float textW = -1f;
    private float bandW;
    private float progress;
    private boolean running = true;
    private ValueAnimator anim;

    public ShimmerTextView(Context c) {
        super(c);
        baseColor = c.getColor(R.color.text_secondary);
        midA = c.getColor(R.color.primary);
        midB = c.getColor(R.color.accent);
        setTextColor(baseColor);
        setSingleLine(true);
    }

    /**
     * Shows {@code full} if the phone can draw every character of it, otherwise {@code plain}
     * (so an unsupported font never shows empty boxes). The spoken description is always plain.
     */
    public void setCredit(String full, String plain, String emoji) {
        CharSequence use = full;
        if (!canDraw(full)) {
            use = canDraw(emoji) ? plain + " " + emoji : plain;
        }
        setText(use);
        setContentDescription(plain);
    }

    private boolean canDraw(String s) {
        int i = 0;
        while (i < s.length()) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if (Character.isWhitespace(cp)) {
                continue;
            }
            if (!getPaint().hasGlyph(new String(Character.toChars(cp)))) {
                return false;
            }
        }
        return true;
    }

    /** The activity calls this from onResume/onPause so nothing animates in the background. */
    public void setRunning(boolean running) {
        this.running = running;
        updateAnimation();
    }

    private boolean shouldAnimate() {
        return running && isAttachedToWindow() && isShown() && ValueAnimator.areAnimatorsEnabled();
    }

    private boolean animating() {
        return anim != null && anim.isRunning();
    }

    private void updateAnimation() {
        if (shouldAnimate()) {
            if (anim == null) {
                anim = ValueAnimator.ofFloat(0f, 1f);
                anim.setDuration(PERIOD_MS);
                anim.setInterpolator(new LinearInterpolator());
                anim.setRepeatCount(ValueAnimator.INFINITE);
                anim.addUpdateListener(a -> {
                    float v = (Float) a.getAnimatedValue();
                    progress = Math.min(1f, v / SWEEP_SHARE);
                    applyShader();
                    invalidate();
                });
            }
            if (!anim.isStarted()) {
                anim.start();
            }
        } else if (anim != null) {
            anim.cancel();
            applyShader();
            invalidate();
        }
    }

    private void applyShader() {
        if (sweep == null || still == null) {
            return;
        }
        if (animating()) {
            float x = -bandW + progress * (textW + bandW);
            matrix.setTranslate(x, 0f);
            sweep.setLocalMatrix(matrix);
            getPaint().setShader(sweep);
        } else {
            getPaint().setShader(still);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        CharSequence t = getText();
        float w = Math.max(1f, getPaint().measureText(t, 0, t.length()));
        if (Math.abs(w - textW) > 0.5f) {
            textW = w;
            bandW = Math.max(w * 0.6f, 1f);
            sweep = new LinearGradient(0f, 0f, bandW, 0f,
                    new int[]{baseColor, midA, midB, baseColor},
                    new float[]{0f, 0.42f, 0.58f, 1f}, Shader.TileMode.CLAMP);
            still = new LinearGradient(0f, 0f, w, 0f, midA, midB, Shader.TileMode.CLAMP);
            applyShader();
        }
        super.onDraw(canvas);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        updateAnimation();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.cancel();
            anim = null;
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        updateAnimation();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        updateAnimation();
    }
}
