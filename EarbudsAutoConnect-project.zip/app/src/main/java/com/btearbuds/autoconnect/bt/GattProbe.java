package com.btearbuds.autoconnect.bt;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.UUID;

/**
 * A short-lived Bluetooth LE (GATT) connection to the chosen device. It is used for two things:
 *
 *  1. As the "connection request" Android 11 lets third-party apps make for dual-mode/LE devices
 *     (there is no public API to start an A2DP connection directly).
 *  2. Optionally, to read the standard GATT Battery Service (0x180F / 0x2A19) if - and only if -
 *     the device exposes exactly one such service. Multiple battery services are NOT guessed at.
 *
 * It never scans, never runs longer than the timeout, and always closes the GATT handle.
 * All listener callbacks arrive on the main thread.
 */
public final class GattProbe {

    public interface Listener {
        void onLinkUp();

        void onBattery(int level);

        void onFinished(boolean linkEstablished, int status, boolean batteryServiceFound);
    }

    private static final UUID BATTERY_SERVICE =
            UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb");
    private static final UUID BATTERY_LEVEL =
            UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb");

    private final Context context;
    private final BluetoothDevice device;
    private final boolean readBattery;
    private final long timeoutMs;
    private final Listener listener;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private BluetoothGatt gatt;
    private boolean finished;
    private boolean silent;
    private boolean linkUp;
    private boolean batteryServiceFound;
    private int lastStatus = -1;

    private final Runnable timeoutRunnable = new Runnable() {
        @Override
        public void run() {
            finish();
        }
    };

    public GattProbe(Context context, BluetoothDevice device, boolean readBattery,
                     long timeoutMs, Listener listener) {
        this.context = context.getApplicationContext();
        this.device = device;
        this.readBattery = readBattery;
        this.timeoutMs = timeoutMs;
        this.listener = listener;
    }

    public void start() {
        try {
            gatt = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_AUTO);
        } catch (SecurityException e) {
            gatt = null;
        } catch (IllegalArgumentException e) {
            gatt = null;
        }
        if (gatt == null) {
            finish();
            return;
        }
        handler.postDelayed(timeoutRunnable, timeoutMs);
    }

    /** Stops quietly without calling the listener. */
    public void cancel() {
        silent = true;
        finish();
    }

    private void finish() {
        if (finished) {
            return;
        }
        finished = true;
        handler.removeCallbacks(timeoutRunnable);
        closeGatt();
        if (!silent) {
            listener.onFinished(linkUp, lastStatus, batteryServiceFound);
        }
    }

    private void closeGatt() {
        BluetoothGatt g = gatt;
        gatt = null;
        if (g == null) {
            return;
        }
        try {
            g.disconnect();
        } catch (RuntimeException e) {
            // ignore
        }
        try {
            g.close();
        } catch (RuntimeException e) {
            // ignore
        }
    }

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(final BluetoothGatt g, final int status,
                                            final int newState) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    if (finished) {
                        return;
                    }
                    lastStatus = status;
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        linkUp = true;
                        listener.onLinkUp();
                        if (readBattery) {
                            try {
                                if (!g.discoverServices()) {
                                    finish();
                                }
                            } catch (SecurityException e) {
                                finish();
                            }
                        } else {
                            finish();
                        }
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        finish();
                    }
                }
            });
        }

        @Override
        public void onServicesDiscovered(final BluetoothGatt g, final int status) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    if (finished) {
                        return;
                    }
                    if (status != BluetoothGatt.GATT_SUCCESS) {
                        finish();
                        return;
                    }
                    try {
                        List<BluetoothGattService> all = g.getServices();
                        BluetoothGattService only = null;
                        int count = 0;
                        for (int i = 0; i < all.size(); i++) {
                            if (BATTERY_SERVICE.equals(all.get(i).getUuid())) {
                                only = all.get(i);
                                count++;
                            }
                        }
                        batteryServiceFound = count > 0;
                        if (count != 1) {
                            // none: nothing to read. several: cannot tell which is which -> do not guess.
                            finish();
                            return;
                        }
                        BluetoothGattCharacteristic ch = only.getCharacteristic(BATTERY_LEVEL);
                        if (ch == null || !g.readCharacteristic(ch)) {
                            finish();
                        }
                    } catch (SecurityException e) {
                        finish();
                    }
                }
            });
        }

        @Override
        @SuppressWarnings("deprecation")
        public void onCharacteristicRead(final BluetoothGatt g,
                                         final BluetoothGattCharacteristic characteristic,
                                         final int status) {
            final byte[] value = characteristic == null ? null : characteristic.getValue();
            final UUID uuid = characteristic == null ? null : characteristic.getUuid();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    if (finished) {
                        return;
                    }
                    if (status == BluetoothGatt.GATT_SUCCESS && BATTERY_LEVEL.equals(uuid)
                            && value != null && value.length >= 1) {
                        int level = value[0] & 0xFF;
                        if (level >= 0 && level <= 100) {
                            listener.onBattery(level);
                        }
                    }
                    finish();
                }
            });
        }
    };
}
