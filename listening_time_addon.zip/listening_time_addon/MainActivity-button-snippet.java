// 1) Add these imports if missing:
import android.content.Intent;
import android.widget.Button;
import com.btearbuds.autoconnect.ui.ListeningTimeActivity;

// 2) In MainActivity.onCreate(), add the following beside the other screen/navigation actions.
// Use the same layout container variable that the existing buttons use; do not paste the
// placeholder name literally. Example: rootLayout.addView(listeningTimeButton);
Button listeningTimeButton = new Button(this);
listeningTimeButton.setText("Music listening time");
listeningTimeButton.setOnClickListener(view ->
        startActivity(new Intent(MainActivity.this, ListeningTimeActivity.class)));
existingLayoutContainer.addView(listeningTimeButton);

// If MainActivity uses a helper method to build navigation buttons, add an equivalent action
// there instead of adding a second layout or replacing the current screen.
