package com.btearbuds.autoconnect.bt;

import android.content.Context;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Build;

/**
 * Looks at Android's audio output list to tell "Bluetooth says connected" apart from
 * "audio is actually routed to these earbuds". Uses only public AudioManager APIs.
 */
public final class AudioRoute {

    /** An A2DP (music) output exists for this device's address. */
    public final boolean a2dpRouteForDevice;
    /** Some Bluetooth A2DP output exists (possibly another device). */
    public final boolean anyA2dpRoute;
    /** A Bluetooth call (SCO) output exists. */
    public final boolean scoRoute;
    /** Android 9+ reports addresses so routes can be matched to a device. */
    public final boolean addressComparable;

    private AudioRoute(boolean a2dpRouteForDevice, boolean anyA2dpRoute, boolean scoRoute,
                       boolean addressComparable) {
        this.a2dpRouteForDevice = a2dpRouteForDevice;
        this.anyA2dpRoute = anyA2dpRoute;
        this.scoRoute = scoRoute;
        this.addressComparable = addressComparable;
    }

    public static AudioRoute check(Context context, String deviceAddress) {
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) {
            return new AudioRoute(false, false, false, false);
        }
        boolean forDevice = false;
        boolean anyA2dp = false;
        boolean sco = false;
        boolean comparable = Build.VERSION.SDK_INT >= 28;
        try {
            AudioDeviceInfo[] outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
            if (outs != null) {
                for (int i = 0; i < outs.length; i++) {
                    AudioDeviceInfo info = outs[i];
                    int type = info.getType();
                    boolean addrMatch = false;
                    if (comparable && deviceAddress != null) {
                        String a = info.getAddress();
                        addrMatch = a != null && a.equalsIgnoreCase(deviceAddress);
                    }
                    if (type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) {
                        anyA2dp = true;
                        if (addrMatch) {
                            forDevice = true;
                        }
                    } else if (type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
                        if (!comparable || addrMatch) {
                            sco = true;
                        }
                    }
                }
            }
        } catch (RuntimeException e) {
            // leave defaults
        }
        return new AudioRoute(forDevice, anyA2dp, sco, comparable);
    }
}
