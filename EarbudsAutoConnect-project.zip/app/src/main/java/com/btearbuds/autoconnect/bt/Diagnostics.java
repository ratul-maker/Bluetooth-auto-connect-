package com.btearbuds.autoconnect.bt;

import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Build;
import android.os.PowerManager;

import com.btearbuds.autoconnect.data.Prefs;
import com.btearbuds.autoconnect.service.MonitorService;

import java.util.ArrayList;
import java.util.List;

/** Builds the self-diagnostic checklist and a plain-text report from live state. */
public final class Diagnostics {

    public enum Sev {
        OK, WARN, ERROR, INFO
    }

    public static final class Item {
        public final String title;
        public final Sev sev;
        public final String text;

        Item(String title, Sev sev, String text) {
            this.title = title;
            this.sev = sev;
            this.text = text;
        }
    }

    private Diagnostics() {
    }

    public static boolean ignoringBatteryOptimizations(Context ctx) {
        try {
            PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            return pm != null && pm.isIgnoringBatteryOptimizations(ctx.getPackageName());
        } catch (RuntimeException e) {
            return false;
        }
    }

    private static String profileState(int st) {
        switch (st) {
            case BluetoothProfile.STATE_CONNECTED:
                return "connected";
            case BluetoothProfile.STATE_CONNECTING:
                return "connecting";
            case BluetoothProfile.STATE_DISCONNECTING:
                return "disconnecting";
            default:
                return "not connected";
        }
    }

    public static List<Item> run(Context ctx, Snapshot s, Prefs prefs) {
        List<Item> out = new ArrayList<Item>();

        // Bluetooth adapter
        if (!s.adapterPresent) {
            out.add(new Item("Bluetooth", Sev.ERROR, "No Bluetooth adapter is available."));
        } else if (!s.adapterOn) {
            out.add(new Item("Bluetooth", Sev.ERROR, "Bluetooth is off. Turn it on to connect."));
        } else {
            out.add(new Item("Bluetooth", Sev.OK, "Bluetooth is on."));
        }

        // Permission
        out.add(new Item("Permission", s.permissionOk ? Sev.OK : Sev.ERROR,
                s.permissionOk
                        ? "Bluetooth permission is granted. (On Android 11 it is granted when the app "
                        + "is installed. No location, microphone or internet permission is used.)"
                        : "Bluetooth permission is missing. Open App info > Permissions."));

        // Device
        if (s.deviceAddress == null) {
            out.add(new Item("Selected earbuds", Sev.WARN, "None selected yet."));
            addEnvironment(out, ctx, s, prefs);
            return out;
        }
        out.add(new Item("Selected earbuds", s.bonded ? Sev.OK : Sev.ERROR,
                s.deviceName + (s.bonded ? " - paired." : " - NOT paired any more. Pair again in "
                        + "Bluetooth settings.")
                        + (s.deviceType != null ? "\nType: " + s.deviceType : "")
                        + (s.transport != null ? "\nBluetooth kind: " + s.transport : "")));

        // Profiles
        StringBuilder prof = new StringBuilder();
        prof.append("Music (A2DP): ").append(s.a2dpProxyReady ? profileState(s.a2dpState) : "checking...");
        prof.append("\nCalls (hands-free): ").append(s.hfpProxyReady ? profileState(s.hfpState) : "checking...");
        if (s.advertisesA2dp != null) {
            prof.append("\nEarbuds advertise music profile: ").append(s.advertisesA2dp ? "yes" : "no");
        } else {
            prof.append("\nEarbuds advertise music profile: Android hasn't cached this");
        }
        if (s.advertisesHandsFree != null) {
            prof.append("\nEarbuds advertise call profile: ").append(s.advertisesHandsFree ? "yes" : "no");
        }
        Sev connSev = s.status() == Snapshot.Status.CONNECTED ? Sev.OK
                : (s.status() == Snapshot.Status.CALLS_ONLY || s.status() == Snapshot.Status.LINKED_NO_AUDIO
                ? Sev.WARN : Sev.INFO);
        out.add(new Item("Connection", connSev, StatusText.label(s) + "\n" + prof));

        if (s.aclState == Snapshot.ACL_UP) {
            out.add(new Item("Bluetooth link", Sev.INFO,
                    "Link established " + StatusText.when(ctx, s.aclTime) + "."));
        } else if (s.aclState == Snapshot.ACL_DOWN) {
            out.add(new Item("Bluetooth link", Sev.INFO,
                    "Link ended " + StatusText.when(ctx, s.aclTime) + "."));
        }

        // Audio route (connected vs actually playing through earbuds)
        out.add(audio(ctx, s));

        if (s.otherAudioConnected) {
            out.add(new Item("Other audio devices", Sev.INFO,
                    s.otherAudioName + " is also connected. The app does not disconnect it."));
        }

        out.add(new Item("One earbud or both?", Sev.INFO,
                "Android can't tell whether one or both earbuds are connected - the earbuds "
                        + "handle that between themselves. The app does not claim to know whether "
                        + "they are in their case."));

        // Attempts
        Sev aSev = s.lastAttemptOk == null ? Sev.INFO : (s.lastAttemptOk ? Sev.OK : Sev.WARN);
        String attempt = s.lastAttemptTime > 0L
                ? "Last attempt: " + StatusText.when(ctx, s.lastAttemptTime)
                + (s.lastAttemptResult != null ? "\n" + s.lastAttemptResult : "")
                : "No connection attempt yet.";
        attempt += "\nLast confirmed connection: " + StatusText.when(ctx, s.lastSuccessTime);
        if (s.gaveUp) {
            attempt += "\nAutomatic retries are paused (" + s.failedAttempts + " tries).";
        } else if (s.nextAttemptAt > 0L) {
            attempt += "\nNext automatic try around " + StatusText.clock(ctx, s.nextAttemptAt) + ".";
        }
        out.add(new Item("Connection attempts", aSev, attempt));

        // Battery
        out.add(battery(s));

        addEnvironment(out, ctx, s, prefs);
        return out;
    }

    private static Item audio(Context ctx, Snapshot s) {
        if (!s.adapterOn || s.a2dpState != BluetoothProfile.STATE_CONNECTED) {
            if (s.hfpState == BluetoothProfile.STATE_CONNECTED) {
                return new Item("Music audio", Sev.WARN,
                        "Connected for calls only. Turn on Media audio for the earbuds in Bluetooth "
                                + "settings (tap the gear next to them).");
            }
            return new Item("Music audio", Sev.INFO, "Not applicable - music isn't connected.");
        }
        AudioRoute r = AudioRoute.check(ctx, s.deviceAddress);
        StringBuilder t = new StringBuilder();
        Sev sev = Sev.OK;
        if (r.addressComparable) {
            if (r.a2dpRouteForDevice) {
                t.append("Android has a music output for these earbuds.");
            } else if (r.anyA2dpRoute) {
                sev = Sev.WARN;
                t.append("Android shows music connected, but its active Bluetooth music output is "
                        + "for a different device.");
            } else {
                sev = Sev.WARN;
                t.append("Bluetooth says music is connected, but Android has no Bluetooth music "
                        + "output right now. Sound may be coming from the phone speaker.");
            }
        } else {
            t.append(r.anyA2dpRoute ? "A Bluetooth music output exists (this Android version can't "
                    + "say which device)." : "No Bluetooth music output found.");
            if (!r.anyA2dpRoute) {
                sev = Sev.WARN;
            }
        }
        if (sev == Sev.WARN) {
            t.append("\n\nTry: (1) pause and resume playback, (2) in Bluetooth settings tap the gear "
                    + "next to the earbuds and switch Media audio off and on, (3) put the earbuds in "
                    + "the case for 5 seconds and take them out, (4) check they aren't also "
                    + "connected to another phone.");
        }
        return new Item("Music audio", sev, t.toString());
    }

    private static Item battery(Snapshot s) {
        if (!s.isConnected()) {
            String last = s.lastBatLevel >= 0
                    ? "\nLast reading seen: " + s.lastBatLevel + "% (old - not shown as current)."
                    : "";
            return new Item("Battery data", Sev.INFO, "Not connected, so no live reading." + last);
        }
        if (s.hasAnyBattery()) {
            return new Item("Battery data", Sev.OK,
                    "A reading is available (" + s.batSource + ").");
        }
        String why;
        if (s.batProbeState == 2) {
            why = "The earbuds don't send a battery level to Android and don't offer a readable "
                    + "standard battery service. Their own app may show it, but this app can't read it.";
        } else if (s.batProbeState == 4) {
            why = "The earbuds don't send a battery level to Android, and a check over Bluetooth LE "
                    + "couldn't connect, so it's unknown whether they offer a battery service.";
        } else if (s.batProbeState == 1) {
            why = "Checking the earbuds for a standard battery service...";
        } else {
            why = "No battery level has been reported yet. Some earbuds only send it occasionally "
                    + "or never.";
        }
        return new Item("Battery data", Sev.WARN, why);
    }

    private static void addEnvironment(List<Item> out, Context ctx, Snapshot s, Prefs prefs) {
        boolean wantOn = prefs.monitoring();
        boolean running = MonitorService.running;
        if (wantOn && running) {
            out.add(new Item("Background monitoring", Sev.OK, "On and running."));
        } else if (wantOn) {
            out.add(new Item("Background monitoring", Sev.WARN,
                    "It is switched on but not running. Android or the phone's power manager may "
                            + "have stopped it. Open the app and turn it off and on."));
        } else {
            out.add(new Item("Background monitoring", Sev.INFO,
                    "Off. Auto-Connect then only works while this app is open."));
        }

        boolean ignoring = ignoringBatteryOptimizations(ctx);
        String m = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase();
        boolean xos = m.contains("infinix") || m.contains("tecno") || m.contains("itel")
                || m.contains("transsion");
        String bg = ignoring ? "Battery optimisation is off for this app."
                : "Battery optimisation is active for this app, so Android may pause it.";
        if (xos) {
            bg += "\nXOS also has its own app-freeze and autostart controls - see Settings > Keep it running.";
        }
        out.add(new Item("Background restrictions", ignoring ? Sev.OK : Sev.WARN, bg));

        out.add(new Item("Phone", Sev.INFO, Build.MANUFACTURER + " " + Build.MODEL
                + ", Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"));
    }

    public static String report(Context ctx, List<Item> items, List<Compat.Row> compat) {
        StringBuilder b = new StringBuilder("Earbuds Auto-Connect - diagnostics\n\n");
        for (Item i : items) {
            b.append("[").append(i.sev).append("] ").append(i.title).append("\n").append(i.text)
                    .append("\n\n");
        }
        b.append("Feature support\n");
        for (Compat.Row r : compat) {
            b.append("- ").append(r.title).append(": ").append(r.level.label).append(" - ")
                    .append(r.detail).append("\n");
        }
        return b.toString();
    }
}
