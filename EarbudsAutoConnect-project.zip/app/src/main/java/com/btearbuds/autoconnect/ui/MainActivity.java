package com.btearbuds.autoconnect.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.btearbuds.autoconnect.R;
import com.btearbuds.autoconnect.bt.AudioRoute;
import com.btearbuds.autoconnect.bt.BtController;
import com.btearbuds.autoconnect.bt.Diagnostics;
import com.btearbuds.autoconnect.bt.Snapshot;
import com.btearbuds.autoconnect.bt.StatusText;
import com.btearbuds.autoconnect.data.Prefs;
import com.btearbuds.autoconnect.service.MonitorService;

import java.util.ArrayList;
import java.util.List;

/** The dashboard: selected earbuds, real connection status, battery, and the main controls. */
public final class MainActivity extends Activity implements BtController.Listener {

    public static final String EXTRA_CONNECT = "connect";

    private static final long AUDIO_SETTLE_MS = 6000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private BtController controller;
    private Prefs prefs;
    private boolean holding;
    private boolean pendingConnect;

    // device card
    private LinearLayout deviceCard;
    private TextView deviceName;
    private LinearLayout statusRow;
    private View statusDot;
    private TextView statusText;
    private TextView deviceInfo;
    private TextView hintText;
    private Button hintButton;
    private Button pickButton;
    private Button clearButton;
    private StatusText.Hint currentHint;

    // audio warning
    private LinearLayout audioCard;

    // battery card
    private LinearLayout batteryCard;
    private TextView batBig;
    private BatteryBar batBar;
    private TextView batSub;
    private TextView batNote;
    private Button batCheck;

    // controls card
    private LinearLayout controlsCard;
    private Button connectButton;
    private Ui.SwitchRow autoRow;
    private Ui.SwitchRow monitorRow;
    private TextView autoWarn;

    // keep-running card
    private LinearLayout keepCard;

    // attempt card
    private LinearLayout attemptCard;
    private TextView attemptText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        controller = BtController.get(this);
        buildUi();
        pendingConnect = getIntent() != null && getIntent().getBooleanExtra(EXTRA_CONNECT, false);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra(EXTRA_CONNECT, false)) {
            intent.removeExtra(EXTRA_CONNECT);
            if (holding) {
                controller.connectNow();
            } else {
                pendingConnect = true;
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!holding) {
            holding = true;
            controller.addListener(this);
            controller.acquire(true);
        }
        render(controller.snapshot());
        if (pendingConnect) {
            pendingConnect = false;
            controller.connectNow();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (holding) {
            render(controller.snapshot());
        }
    }

    @Override
    protected void onStop() {
        handler.removeCallbacksAndMessages(null);
        if (holding) {
            holding = false;
            controller.removeListener(this);
            controller.release(true);
        }
        super.onStop();
    }

    @Override
    public void onSnapshot(Snapshot s) {
        render(s);
    }

    // ------------------------------------------------------------------ building the screen

    private void buildUi() {
        LinearLayout page = Ui.page(this, "Earbuds Auto-Connect");

        TextView title = Ui.title(this, "Earbuds");
        page.addView(title);

        LinearLayout nav = Ui.row(this);
        nav.addView(navButton("History", HistoryActivity.class), weight());
        nav.addView(navButton("Diagnostics", DiagnosticsActivity.class), weight());
        nav.addView(navButton("Settings", SettingsActivity.class), weight());
        Ui.add(page, nav, 4);

        // ---- device card
        deviceCard = Ui.card(this);
        deviceCard.addView(Ui.heading(this, "PREFERRED EARBUDS"));
        deviceName = Ui.text(this, "", 22, R.color.text_primary, true);
        Ui.add(deviceCard, deviceName, 4);
        statusRow = Ui.row(this);
        statusDot = Ui.dot(this, Ui.col(this, R.color.idle));
        statusRow.addView(statusDot);
        statusText = Ui.text(this, "", 16, R.color.text_primary, true);
        statusRow.addView(statusText);
        Ui.add(deviceCard, statusRow, 8);
        deviceInfo = Ui.small(this, "");
        Ui.add(deviceCard, deviceInfo, 4);
        hintText = Ui.body(this, "");
        Ui.add(deviceCard, hintText, 12);
        hintButton = Ui.button(this, "", Ui.BTN_TONAL, v -> {
            if (currentHint != null) {
                Ui.perform(this, currentHint.action);
            }
        });
        Ui.add(deviceCard, hintButton, 8);
        LinearLayout deviceButtons = Ui.row(this);
        pickButton = Ui.button(this, "Choose earbuds", Ui.BTN_TONAL,
                v -> startActivity(new Intent(this, PickDeviceActivity.class)));
        deviceButtons.addView(pickButton, weight());
        clearButton = Ui.button(this, "Clear", Ui.BTN_TEXT, v -> confirmClear());
        deviceButtons.addView(clearButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        Ui.add(deviceCard, deviceButtons, 12);
        Ui.addCard(page, deviceCard);

        // ---- audio warning
        audioCard = Ui.card(this);
        audioCard.setBackground(Ui.rect(this, Ui.col(this, R.color.surface), Ui.col(this, R.color.warn), 2, 20));
        audioCard.addView(Ui.text(this, "Connected, but is music reaching the earbuds?", 16,
                R.color.text_primary, true));
        Ui.add(audioCard, Ui.body(this, "Bluetooth says the earbuds are connected, but Android isn't "
                + "routing music to them right now. Sound may still be coming from the phone."), 6);
        Ui.add(audioCard, Ui.button(this, "Troubleshoot", Ui.BTN_TONAL,
                v -> startActivity(new Intent(this, DiagnosticsActivity.class))), 8);
        Ui.addCard(page, audioCard);

        // ---- battery card
        batteryCard = Ui.card(this);
        batteryCard.addView(Ui.heading(this, "EARBUD BATTERY"));
        batBig = Ui.text(this, "", 40, R.color.text_primary, true);
        Ui.add(batteryCard, batBig, 4);
        batBar = new BatteryBar(this);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 14));
        barLp.setMargins(0, Ui.dp(this, 8), 0, 0);
        batteryCard.addView(batBar, barLp);
        batSub = Ui.body(this, "");
        Ui.add(batteryCard, batSub, 10);
        batNote = Ui.small(this, "");
        Ui.add(batteryCard, batNote, 6);
        batCheck = Ui.button(this, "Check again", Ui.BTN_TEXT, v -> controller.checkBatteryNow());
        Ui.add(batteryCard, batCheck, 4);
        Ui.addCard(page, batteryCard);

        // ---- controls card
        controlsCard = Ui.card(this);
        connectButton = Ui.button(this, "Connect now", Ui.BTN_PRIMARY, v -> controller.connectNow());
        controlsCard.addView(connectButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        Ui.add(controlsCard, Ui.button(this, "Open Bluetooth settings", Ui.BTN_TEXT,
                v -> Ui.openBluetoothSettings(this)), 4);

        autoRow = Ui.switchRow(this, "Auto-Connect",
                "Reconnect to your earbuds when they become available.", checked -> {
                    prefs.setAutoConnect(checked);
                    controller.onSettingsChanged();
                });
        Ui.add(controlsCard, autoRow.view, 8);
        autoWarn = Ui.small(this, "Auto-Connect only works while this app is open. Turn on Background "
                + "Monitoring to keep it working with the screen off.");
        Ui.add(controlsCard, autoWarn, 0);

        monitorRow = Ui.switchRow(this, "Background Monitoring",
                "Keeps watching with the screen off. Shows a small notification.", checked -> {
                    if (checked) {
                        if (prefs.preferredAddress() == null) {
                            Ui.toast(this, "Choose your earbuds first.");
                            monitorRow.set(false);
                            return;
                        }
                        prefs.setMonitoring(true);
                        MonitorService.start(this);
                    } else {
                        prefs.setMonitoring(false);
                        MonitorService.stop(this);
                    }
                    controller.onSettingsChanged();
                });
        Ui.add(controlsCard, monitorRow.view, 4);
        Ui.addCard(page, controlsCard);

        // ---- keep running hint
        keepCard = Ui.card(this);
        keepCard.addView(Ui.text(this, "Keep monitoring alive", 16, R.color.text_primary, true));
        Ui.add(keepCard, Ui.body(this, "Android is allowed to pause this app when the screen is off. "
                + "If monitoring stops, allow background activity for it."), 6);
        Ui.add(keepCard, Ui.button(this, "Show me how", Ui.BTN_TONAL,
                v -> startActivity(new Intent(this, SettingsActivity.class))), 8);
        Ui.addCard(page, keepCard);

        // ---- last attempt
        attemptCard = Ui.card(this);
        attemptCard.addView(Ui.heading(this, "CONNECTION ATTEMPTS"));
        attemptText = Ui.body(this, "");
        Ui.add(attemptCard, attemptText, 6);
        Ui.addCard(page, attemptCard);
    }

    private Button navButton(String label, final Class<?> target) {
        return Ui.button(this, label, Ui.BTN_TEXT, v -> startActivity(new Intent(this, target)));
    }

    private static LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Clear preferred earbuds?")
                .setMessage("The app will stop watching them and Background Monitoring will turn off. "
                        + "Your history stays until you clear it.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear", (d, w) -> {
                    prefs.clearPreferred();
                    prefs.setMonitoring(false);
                    MonitorService.stop(this);
                    controller.onPreferredDeviceChanged();
                    render(controller.snapshot());
                })
                .show();
    }

    // ------------------------------------------------------------------ rendering

    private void render(Snapshot s) {
        final boolean hasDevice = s.deviceAddress != null;
        Snapshot.Status st = s.status();

        // device card
        deviceName.setText(hasDevice ? s.deviceName : "No earbuds selected");
        statusRow.setVisibility(hasDevice ? View.VISIBLE : View.GONE);
        if (hasDevice) {
            statusText.setText(StatusText.label(s));
            Ui.setDotColor(statusDot, Ui.col(this, dotColor(st)));
        }
        List<String> info = new ArrayList<String>();
        if (hasDevice && s.deviceType != null) {
            info.add(s.deviceType);
        }
        if (hasDevice && s.transport != null) {
            info.add(s.transport);
        }
        if (s.isConnected() && s.connectedSince > 0L) {
            info.add("connected since " + StatusText.clock(this, s.connectedSince));
        }
        deviceInfo.setVisibility(info.isEmpty() ? View.GONE : View.VISIBLE);
        deviceInfo.setText(join(info, " · "));

        currentHint = StatusText.hint(this, s);
        if (currentHint != null) {
            hintText.setVisibility(View.VISIBLE);
            hintText.setText(currentHint.text);
            boolean showAction = currentHint.action != StatusText.Action.NONE
                    && currentHint.action != StatusText.Action.PICK_DEVICE;
            hintButton.setVisibility(showAction ? View.VISIBLE : View.GONE);
            if (showAction) {
                hintButton.setText(currentHint.actionLabel);
            }
        } else {
            hintText.setVisibility(View.GONE);
            hintButton.setVisibility(View.GONE);
        }
        pickButton.setText(hasDevice ? "Change earbuds" : "Choose earbuds");
        clearButton.setVisibility(hasDevice ? View.VISIBLE : View.GONE);

        // sections only make sense once earbuds are chosen
        int vis = hasDevice ? View.VISIBLE : View.GONE;
        batteryCard.setVisibility(vis);
        controlsCard.setVisibility(vis);
        attemptCard.setVisibility(vis);

        renderAudioWarning(s);
        renderBattery(s);
        renderControls(s);
        renderAttempts(s);
    }

    private static int dotColor(Snapshot.Status st) {
        switch (st) {
            case CONNECTED:
                return R.color.ok;
            case CALLS_ONLY:
            case LINKED_NO_AUDIO:
            case CONNECTING:
                return R.color.warn;
            case BT_OFF:
            case BT_UNAVAILABLE:
            case NO_PERMISSION:
            case UNPAIRED:
                return R.color.error;
            default:
                return R.color.idle;
        }
    }

    private void renderAudioWarning(Snapshot s) {
        boolean show = false;
        if (s.status() == Snapshot.Status.CONNECTED) {
            long sinceConnect = System.currentTimeMillis() - s.connectedSince;
            if (s.connectedSince > 0L && sinceConnect < AUDIO_SETTLE_MS) {
                // Android needs a moment to publish the audio output; check again shortly.
                handler.removeCallbacks(recheck);
                handler.postDelayed(recheck, AUDIO_SETTLE_MS - sinceConnect + 500L);
            } else {
                AudioRoute r = AudioRoute.check(this, s.deviceAddress);
                show = r.addressComparable && !r.a2dpRouteForDevice;
            }
        }
        audioCard.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private final Runnable recheck = new Runnable() {
        @Override
        public void run() {
            if (holding) {
                render(controller.snapshot());
            }
        }
    };

    private void renderBattery(Snapshot s) {
        batCheck.setVisibility(View.GONE);
        if (s.isConnected() && s.batSingle != null) {
            batBig.setVisibility(View.VISIBLE);
            batBar.setVisibility(View.VISIBLE);
            batBig.setText(s.batSingle + "%");
            batBar.setLevel(s.batSingle.intValue());
            batSub.setText(s.batSource + "\nUpdated " + StatusText.when(this, s.batTime));
            batNote.setText("These earbuds give one battery value, not separate left and right "
                    + "levels. The charging case battery is never shown.");
        } else if (s.isConnected() && (s.batLeft != null || s.batRight != null)) {
            batBig.setVisibility(View.VISIBLE);
            batBar.setVisibility(View.GONE);
            StringBuilder b = new StringBuilder();
            if (s.batLeft != null) {
                b.append("L ").append(s.batLeft).append("%");
            }
            if (s.batRight != null) {
                b.append(b.length() > 0 ? "   " : "").append("R ").append(s.batRight).append("%");
            }
            batBig.setText(b.toString());
            batSub.setText("Updated " + StatusText.when(this, s.batTime));
            batNote.setText("The charging case battery is never shown.");
        } else if (s.isConnected()) {
            batBig.setVisibility(View.GONE);
            batBar.setVisibility(View.GONE);
            batSub.setText("Battery information unavailable for this device.");
            if (s.batProbeState == 1) {
                batNote.setText("Checking the earbuds for a battery level...");
            } else if (s.batProbeState == 2) {
                batNote.setText("The earbuds don't send a battery level to Android and don't offer "
                        + "a readable standard battery service. Their own app may show it, but this "
                        + "app can't read it.");
            } else if (s.batProbeState == 4) {
                batNote.setText("The earbuds don't send a battery level to Android, and a check over "
                        + "Bluetooth LE couldn't connect, so it's unknown whether they offer one. "
                        + "Nothing is estimated or guessed.");
            } else {
                batNote.setText("No battery level has been reported yet. Many earbuds never send one "
                        + "to the phone. Nothing is estimated or guessed.");
            }
            boolean canProbe = s.deviceTypeCode != android.bluetooth.BluetoothDevice.DEVICE_TYPE_CLASSIC
                    && s.batProbeState != 1;
            batCheck.setVisibility(canProbe ? View.VISIBLE : View.GONE);
        } else {
            batBig.setVisibility(View.GONE);
            batBar.setVisibility(View.GONE);
            batSub.setText("Battery is shown only while the earbuds are connected.");
            if (s.lastBatLevel >= 0 && s.lastBatTime > 0L) {
                batNote.setText("Last reading seen: " + s.lastBatLevel + "% at "
                        + StatusText.when(this, s.lastBatTime) + " (old - not current).");
            } else {
                batNote.setText("No reading has been received yet.");
            }
        }
    }

    private void renderControls(Snapshot s) {
        boolean canTry = s.adapterOn && s.permissionOk && s.bonded;
        if (s.isConnected()) {
            connectButton.setText("Connected");
            Ui.setEnabledLook(connectButton, false);
        } else if (s.attemptInFlight || s.status() == Snapshot.Status.CONNECTING) {
            connectButton.setText("Connecting...");
            Ui.setEnabledLook(connectButton, false);
        } else {
            connectButton.setText("Connect now");
            Ui.setEnabledLook(connectButton, canTry);
        }
        autoRow.set(s.autoConnect);
        monitorRow.set(prefs.monitoring());
        autoWarn.setVisibility(s.autoConnect && !prefs.monitoring() ? View.VISIBLE : View.GONE);
        keepCard.setVisibility(prefs.monitoring() && !Diagnostics.ignoringBatteryOptimizations(this)
                ? View.VISIBLE : View.GONE);
    }

    private void renderAttempts(Snapshot s) {
        StringBuilder b = new StringBuilder();
        if (s.lastAttemptTime > 0L) {
            b.append("Last attempt: ").append(StatusText.when(this, s.lastAttemptTime));
            if (s.lastAttemptResult != null) {
                b.append("\n").append(s.lastAttemptResult);
            }
        } else {
            b.append("No connection attempt yet.");
        }
        b.append("\n\nLast confirmed connection: ").append(StatusText.when(this, s.lastSuccessTime));
        attemptText.setText(b.toString());
    }

    private static String join(List<String> parts, String sep) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) {
                b.append(sep);
            }
            b.append(parts.get(i));
        }
        return b.toString();
    }
}
