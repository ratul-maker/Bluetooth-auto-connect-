package com.btearbuds.autoconnect.bt;

import android.bluetooth.BluetoothProfile;

/**
 * An immutable picture of everything the UI and notification need. Built by {@link BtController}.
 * Every value here comes from an Android API or event; nothing is assumed or invented.
 */
public final class Snapshot {

    public enum Status {
        NO_DEVICE,
        BT_UNAVAILABLE,
        BT_OFF,
        NO_PERMISSION,
        UNPAIRED,
        DISCONNECTED,
        CONNECTING,
        CONNECTED,
        CALLS_ONLY,
        LINKED_NO_AUDIO
    }

    public static final int ACL_UNKNOWN = 0;
    public static final int ACL_UP = 1;
    public static final int ACL_DOWN = 2;

    // adapter
    public boolean adapterPresent;
    public boolean adapterOn;
    public boolean permissionOk;

    // device
    public String deviceName;
    public String deviceAddress;
    public boolean bonded;
    public String deviceType;
    public String transport;
    public int deviceTypeCode;
    public Boolean advertisesA2dp;
    public Boolean advertisesHandsFree;

    // connection (profile states are BluetoothProfile.STATE_*)
    public int a2dpState = BluetoothProfile.STATE_DISCONNECTED;
    public int hfpState = BluetoothProfile.STATE_DISCONNECTED;
    public boolean a2dpProxyReady;
    public boolean hfpProxyReady;
    public int aclState = ACL_UNKNOWN;
    public long aclTime;
    public boolean linkedNoAudio;
    public long connectedSince;
    /**
     * true if the app saw this connection start happen live; false if the earbuds were already
     * connected when the app began watching (then connectedSince is only "first seen").
     */
    public boolean connectedSinceExact;
    /**
     * Android says audio is streaming to the earbuds right now. This is "sound is flowing", not
     * "music is playing": it cannot tell music from video or other sound, nor which app.
     */
    public boolean a2dpPlaying;
    public long playingSince;
    /** The app saw streaming start (false = it was already streaming when first seen). */
    public boolean playingSinceExact;
    public boolean otherAudioConnected;
    public String otherAudioName;

    // attempts
    public boolean attemptInFlight;
    public boolean attemptManual;
    public int failedAttempts;
    public boolean gaveUp;
    public long nextAttemptAt;
    public long lastAttemptTime;
    public String lastAttemptResult;
    public Boolean lastAttemptOk;
    public long lastSuccessTime;

    // battery
    public Integer batSingle;
    public Integer batLeft;
    public Integer batRight;
    public long batTime;
    public String batSource;
    /** true only while the device is connected and a reading arrived during this connection. */
    public boolean batLive;
    public int lastBatLevel = -1;
    public long lastBatTime;
    public String lastBatSource;
    /** 0 not tried, 1 running, 2 reached earbuds: no readable battery service, 3 value read,
     *  4 could not open a Bluetooth LE link (unknown whether a service exists) */
    public int batProbeState;

    // settings mirrored for convenience
    public boolean autoConnect;
    public boolean monitoring;

    public boolean isConnected() {
        return adapterOn && (a2dpState == BluetoothProfile.STATE_CONNECTED
                || hfpState == BluetoothProfile.STATE_CONNECTED);
    }

    public Status status() {
        if (deviceAddress == null) {
            return Status.NO_DEVICE;
        }
        if (!adapterPresent) {
            return Status.BT_UNAVAILABLE;
        }
        if (!permissionOk) {
            return Status.NO_PERMISSION;
        }
        if (!adapterOn) {
            return Status.BT_OFF;
        }
        if (!bonded) {
            return Status.UNPAIRED;
        }
        boolean a2dp = a2dpState == BluetoothProfile.STATE_CONNECTED;
        boolean hfp = hfpState == BluetoothProfile.STATE_CONNECTED;
        if (a2dp) {
            return Status.CONNECTED;
        }
        if (hfp) {
            return Status.CALLS_ONLY;
        }
        if (a2dpState == BluetoothProfile.STATE_CONNECTING
                || hfpState == BluetoothProfile.STATE_CONNECTING || attemptInFlight) {
            return Status.CONNECTING;
        }
        if (linkedNoAudio) {
            return Status.LINKED_NO_AUDIO;
        }
        return Status.DISCONNECTED;
    }

    public boolean hasAnyBattery() {
        return batSingle != null || batLeft != null || batRight != null;
    }
}
