package com.btearbuds.autoconnect.treble;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import com.btearbuds.autoconnect.service.Notifs;

/**
 * Keeps the app's process alive (with a visible notification) while Treble Lab is on, because an
 * audio effect only lives as long as the app that created it. It has nothing to do with Bluetooth.
 */
public final class TrebleService extends Service implements TrebleEngine.Listener {

    public static final String ACTION_START = "com.btearbuds.autoconnect.TREBLE_START";
    public static final String ACTION_STOP = "com.btearbuds.autoconnect.TREBLE_STOP";

    /** True while this service instance exists in this process. */
    public static volatile boolean running;

    private TrebleEngine engine;
    private TreblePrefs prefs;
    private NotificationManager nm;
    private String lastKey;

    public static void start(Context ctx) {
        try {
            Intent i = new Intent(ctx, TrebleService.class);
            i.setAction(ACTION_START);
            ctx.startForegroundService(i);
        } catch (RuntimeException e) {
            // Android refused to start a foreground service from the background. Nothing to do.
        }
    }

    public static void stop(Context ctx) {
        try {
            ctx.stopService(new Intent(ctx, TrebleService.class));
        } catch (RuntimeException e) {
            // ignore
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        Notifs.ensureChannels(this);
        prefs = new TreblePrefs(this);
        engine = TrebleEngine.get(this);
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Android requires startForeground() soon after startForegroundService(), every time.
        startForeground(Notifs.ID_TREBLE, Notifs.treblePlaceholder(this));
        lastKey = null;
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            prefs.setEnabled(false);
            shutDown();
            return START_NOT_STICKY;
        }
        if (!prefs.enabled()) {
            shutDown();
            return START_NOT_STICKY;
        }
        engine.addListener(this);
        engine.start();
        update(engine.status());
        return START_STICKY;
    }

    @Override
    public void onTrebleStatus(TrebleEngine.Status s) {
        update(s);
    }

    private void update(TrebleEngine.Status s) {
        if (nm == null) {
            return;
        }
        String key = s.headline() + "|" + s.db + "|" + s.appSessions + "|" + s.appSessionsVerified
                + "|" + s.globalVerified;
        if (key.equals(lastKey)) {
            return;
        }
        lastKey = key;
        nm.notify(Notifs.ID_TREBLE, Notifs.trebleNotification(this, s));
    }

    private void shutDown() {
        engine.removeListener(this);
        engine.stop();
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        engine.removeListener(this);
        engine.stop();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
