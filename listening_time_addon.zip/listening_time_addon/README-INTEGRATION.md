# Music listening-time tracker add-on (Android 8+, aimed at Android 11)

This is a **source add-on**, not a ready-to-install APK. It estimates daily Bluetooth-output playback time using Android media-session state. It deliberately does not read or save song titles, artists, notification text, or other media metadata.

## Files

Copy the `app/src/main/java/com/btearbuds/autoconnect/` files into the matching package folders in your extracted project. These are new class names; do not replace existing project classes.

## 1. Manifest

Open `app/src/main/AndroidManifest.xml`. Add the two declarations from `AndroidManifest-snippet.xml` **inside the existing `<application>` element**. Do not create another `<application>` or add extra permissions. Notification Access is granted by the user in Android Settings; it is not a runtime permission dialog.

## 2. Add navigation

Open `app/src/main/java/com/btearbuds/autoconnect/ui/MainActivity.java`. Add the import and button action from `MainActivity-button-snippet.java` beside the existing navigation actions. Replace `existingLayoutContainer` with the real layout variable already used by your screen. Do not paste the placeholder name literally, and do not create a second root layout. If your screen uses a helper for buttons, add the new action through that helper.

## 3. Build and enable

Build a release APK, install it as an update over your existing app, open **Music listening time**, choose **Enable / manage Notification Access**, and enable **Earbuds Auto-Connect** in Android Settings. Return to the app. The screen refreshes about every 10 seconds while it is open.

The service only samples while Android has connected the Notification Listener. Some Android vendors may delay background callbacks, so the result is an estimate and can undercount. It can also count playback routed to another Bluetooth audio device because public APIs do not reliably identify which Bluetooth device is truly selected for all audio sessions. Muted or inaudible playback may still count. Do not treat this as a hearing-safety measurement.

## 4. Keep updates installable without uninstalling

Your current project is configured for `applicationId 'com.btearbuds.autoconnect'` and a release key at `signing/btearbuds-release.jks`. To update over the installed APK, every build must use:

- the same `applicationId`;
- the exact same signing keystore file and alias/password;
- a `versionCode` equal to or greater than the installed app's version.

Do not regenerate the key or change the application ID. The key is not included in this add-on ZIP; preserve the existing keystore in your original project. If the keystore is lost, Android normally will not accept a newly signed APK as an update.

### Security warning about the existing key

Your repository was publicly readable and its Gradle configuration contains hard-coded signing passwords; the project README also says the key is bundled. If that repository truly includes the keystore, assume the signing key may be exposed. Make the repository private immediately and do not publish the APK/key. Moving signing to GitHub Actions secrets is better, but replacing an already-used signing key can require a one-time uninstall/reinstall for a sideloaded app. Keep a secure backup of whichever key signs future builds.

## 5. Test checklist

1. Build the project and install the APK as an update (do not uninstall first).
2. Open the tracker and grant Notification Access.
3. Play music over Bluetooth for at least 2–3 minutes; wait for the total to update.
4. Pause music and wait another minute; the total should stop increasing after the sampling delay.
5. Disconnect Bluetooth while music continues; the total should stop increasing after the sampling delay.
6. Reopen the screen to verify daily totals persist.

If compilation fails, the exact Gradle error and the full original project ZIP are needed to fix the integration precisely. This add-on has not been built or tested on your physical phone.
